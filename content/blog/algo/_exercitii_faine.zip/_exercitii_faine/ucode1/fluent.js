class person1 {
    age = 8;
    name = '';
    setAge(v) {
        this.age = v;
        return this;
    }
    setName(v) {
        this.name = v;
    }
}