function fact(a,b) {
	var x1,x2,y1,y2 = 0;
	x1 = a-1;
    x2 = 1;
	y1=b-1;
	y2=1;
while(x1>1) {
	var p = x1*y1;
	var s = x1*y2+x2*y1;
	var r = x2*y2;
	console.log(p, s, r);
	x1--;
	x2++;
	y1--;
	y2++; 
}


}