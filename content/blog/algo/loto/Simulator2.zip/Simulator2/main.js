var app = angular.module('myApp', []);
app.controller('myCtrl', function($scope) {

    var $scope = $scope;
    var utilsService = {
        uuid: function() {
            function _p8(s) {
                var p = (Math.random().toString(16) + "000000000").substr(2, 8);
                return s ? "-" + p.substr(0, 4) + "-" + p.substr(4, 4) : p;
            }
            return _p8() + _p8(true) + _p8(true) + _p8();
        }
    };

    $scope.numbers = {
        list: [],
        smallList: [],
        randoms: [],
        number: function(number) {
            this.n = number;
            this.id = null;
        },
        init: function(n) {
            this.list = [];
            smallList = [];
            for (var i = 1; i <= n; i++) {
                this.list.push(new this.number(i));
                this.smallList.push(i);
            }
        },
        generateNRandomNumbers: function(n) {
            var tempNumbers = [];
            for (var i = 0; i < this.list.length; i++) {
                this.list[i].id = utilsService.uuid();
            }

            tempNumbers = _.first(_.sortBy(this.list, function(patient) {
                return patient.id;
            }), n);

            tempNumbers = _.sortBy(tempNumbers, function(patient) {
                return patient.n;
            });


            var rez = [];
            for (var i = 0; i < tempNumbers.length; i++) {
                rez.push(tempNumbers[i].n);
            }
            return rez;
            // var rez = this.smallList.sort(function () { return Math.random() - 0.5; });
            // rez = _.first(rez, n);

            // return rez;
        },
        checkTicketNumbers: function(luckyNumbers, userNumbers) {
            var rez = [];
            for (var i = 0; i < userNumbers.length; i++) {
                var luckyNumber = _.find(luckyNumbers, function(num) {
                    return num == userNumbers[i];
                });
                if (luckyNumber) {
                    rez.push(luckyNumber);
                }
            }
            return rez;
        }
    }

    $scope.ticket = function(nChoises) {
        this.nChoises = nChoises;
        this.numbers = [];
        this.luckyNumbers = {
            count: 0,
            numbers: []
        };
        this.cost = 0;

        this.generateTicket = function() {
            this.numbers = $scope.numbers.generateNRandomNumbers(this.nChoises);
            this.calculateTicketCost();
        };
        this.calculateTicketCost = function() {
            switch (this.nChoises) {
                case 5:
                    {
                        this.cost = 5;
                        break;
                    }
                case 6:
                    {
                        this.cost = 5;
                        break;
                    }
                case 7:
                    {
                        this.cost = 10;
                        break;
                    }
                case 8:
                    {
                        this.cost = 20;
                        break;
                    }
                case 9:
                    {
                        this.cost = 40;
                        break;
                    }
                case 10:
                    {
                        this.cost = 80;
                        break;
                    }
                case 11:
                    {
                        this.cost = 160;
                        break;
                    }
                case 12:
                    {
                        this.cost = 320;
                        break;
                    }
                case 13:
                    {
                        this.cost = 640;
                        break;
                    }
                case 14:
                    {
                        this.cost = 1280;
                        break;
                    }
                case 15:
                    {
                        this.cost = 2560;
                        break;
                    }
                case 16:
                    {
                        this.cost = 5120;
                        break;
                    }
            }
        }

        this.checkLuckyNumbers = function() {
            this.luckyNumbers.numbers = $scope.numbers.checkTicketNumbers(this.numbers, $scope.extragere.luckynumbers);
            this.luckyNumbers.count = this.luckyNumbers.numbers.length;
        };
    };

    $scope.user = function(id) {
        this.id = id;
        this.tickets = []
    };

    $scope.loggedUser = null;
    $scope.calc1 = null;
    var users = function() {
        this.list = [];
        this.init = function(n) {
            this.list = [];
            var ticket = null;
            ticket = new $scope.ticket($scope.usersConfig.b);
            ticket.generateTicket();

            $scope.loggedUser = new $scope.user(utilsService.uuid());
            $scope.loggedUser.tickets.push(ticket);
            this.list.push($scope.loggedUser);

            for (var i = 1; i < n; i++) {
                ticket = new $scope.ticket($scope.noOfNumbersToBeExtracted.value);
                ticket.generateTicket();
                var user = new $scope.user(utilsService.uuid());
                user.tickets.push(ticket);
                this.list.push(user);
            }
        };
        this.calculateTicketsPrize = function() {
            var prize = 0;
            for (var i = 0; i < this.list.length; i++) {
                var user = this.list[i];

                for (var j = 0; j < user.tickets.length; j++) {
                    var ticket = user.tickets[j];
                    prize += ticket.cost;
                }
            }
            return prize;
        };
        this.checkLuckyNumbers = function(result) {
            for (var i = 0; i < this.list.length; i++) {
                var user = this.list[i];

                for (var j = 0; j < user.tickets.length; j++) {
                    var ticket = user.tickets[j];
                    ticket.checkLuckyNumbers();
                    switch (ticket.luckyNumbers.count) {
                        case 0:
                            {
                                result.results[0].count++;
                                result.results[0].list.push(ticket);
                                break;
                            }
                        case 1:
                            {
                                result.results[1].count++;
                                result.results[1].list.push(ticket);
                                break;
                            }
                        case 2:
                            {
                                result.results[2].count++;
                                result.results[2].list.push(ticket);
                                break;
                            }
                        case 3:
                            {
                                result.results[3].count++;
                                result.results[3].list.push(ticket);
                                break;
                            }
                        case 4:
                            {
                                result.results[4].count++;
                                result.results[4].list.push(ticket);
                                break;
                            }
                        case 5:
                            {
                                result.results[5].count++;
                                result.results[5].list.push(ticket);
                                break;
                            }
                        case 6:
                            {
                                result.results[6].count++;
                                result.results[6].list.push(ticket);
                                break;
                            }
                    }
                }
            }
            var calc = new $scope.amountCalculator1();
            calc.calculateAmount(result);
            $scope.calc1 = calc;
        };
        this.checkLuckyNumbers1 = function(result) {
            var w = result.results;
            this.step2(w[1]);
            this.step2(w[2]);
            this.step2(w[3]);
            this.step2(w[4]);
            this.step2(w[5]);
            this.step2(w[6]);
        }
        this.step2 = function(obj) {
            if(obj.count==0)
                return;

            obj.list1 = [];
            obj.amountCalculator2 = new $scope.amountCalculator2();
            obj.result1 = new $scope.result();
            obj.result1.init();

            for (var i = 0; i < obj.count; i++) {
                var ticket = new $scope.ticket($scope.noOfNumbersToBeExtracted.value);
                ticket.generateTicket();
                debugger;
                ticket.checkLuckyNumbers();

                obj.list1.push(ticket);


                switch (ticket.luckyNumbers.count) {
                    case 0:
                        {
                            obj.result1.results[0].count++;
                            obj.result1.results[0].list.push(ticket);
                            break;
                        }
                    case 1:
                        {
                            obj.result1.results[1].count++;
                            obj.result1.results[1].list.push(ticket);
                            break;
                        }
                    case 2:
                        {
                            obj.result1.results[2].count++;
                            obj.result1.results[2].list.push(ticket);
                            break;
                        }
                    case 3:
                        {
                            obj.result1.results[3].count++;
                            obj.result1.results[3].list.push(ticket);
                            break;
                        }
                    case 4:
                        {
                            obj.result1.results[4].count++;
                            obj.result1.results[4].list.push(ticket);
                            break;
                        }
                    case 5:
                        {
                            obj.result1.results[5].count++;
                            obj.result1.results[5].list.push(ticket);
                            break;
                        }
                    case 6:
                        {
                            obj.result1.results[6].count++;
                            obj.result1.results[6].list.push(ticket);
                            break;
                        }
                }
            }

            obj.amountCalculator2.calculateAmount(obj);
        }
    };

    $scope.result1 = null;
    $scope.extragere = {
        luckynumbers: [],
        luckynumbers1: [],
        simulate: function() {
            var result = new $scope.result();
            result.init();

            $scope.result1 = result;

            $scope.users.init($scope.usersConfig.selection);

            this.luckynumbers = $scope.numbers.generateNRandomNumbers($scope.noOfNumbersToBeExtracted.value);
            $scope.users.checkLuckyNumbers($scope.result1);


        },
        simulate2: function() {
            this.luckynumbers1 = $scope.numbers.generateNRandomNumbers($scope.noOfNumbersToBeExtracted.value);
            $scope.users.checkLuckyNumbers1($scope.result1);
        }
    };
    $scope.result = function() {
        this.results = {},
            this.init = function() {
                this.results[0] = {
                    n: 0,
                    amount: 0,
                    count: 0,
                    list: []
                };
                this.results[1] = {
                    n: 1,
                    amount: 0,
                    count: 0,
                    list: []
                };
                this.results[2] = {
                    n: 2,
                    amount: 0,
                    count: 0,
                    list: []
                };
                this.results[3] = {
                    n: 3,
                    amount: 0,
                    count: 0,
                    list: []
                };
                this.results[4] = {
                    n: 4,
                    amount: 0,
                    count: 0,
                    list: []
                };
                this.results[5] = {
                    n: 5,
                    amount: 0,
                    count: 0,
                    list: []
                };
                this.results[6] = {
                    n: 6,
                    amount: 0,
                    count: 0,
                    list: []
                };
            }


    };

    $scope.amountCalculator1 = function() {
        // this.amount = {
        //        totalTicketsAmount: 0,
        //        totalTicketsNo: 0,
        //        totalPrizeAmountAux: 0,
        //        totalPrizeAmount: 0,
        //        profit: 4,
        //    };
        this.calculateAmount = function(result) {

            this.totalTicketsNo =
                result.results[0].count +
                result.results[1].count +
                result.results[2].count +
                result.results[3].count +
                result.results[4].count +
                result.results[5].count +
                result.results[6].count;


            this.totalTicketsAmount = $scope.users.calculateTicketsPrize();
            //5 .. 100 
            //x .. 2.9
            //x= (2.9 * 5/100) =  
            this.totalPrizeAmountAux = this.totalTicketsAmount - this.totalTicketsAmount * 0.029;

            this.profit = (this.totalPrizeAmountAux * $scope.profit.value) / 100;

            this.totalPrizeAmount = this.totalPrizeAmountAux - this.profit;
            var prizeAmount = this.totalPrizeAmount; // - this.profit;
            if (result.results[6].count > 0) {
                result.results[6].amount = prizeAmount * 0.5;
                prizeAmount = prizeAmount - result.results[6].amount;
            }

            if (result.results[5].count > 0) {
                var isBelow = (
                    result.results[4].count > 0 ||
                    result.results[3].count > 0 ||
                    result.results[2].count > 0 ||
                    result.results[1].count > 0 
                );
                if (isBelow == true) {
                    result.results[5].amount = prizeAmount * 0.5;
                } else {
                    result.results[5].amount = prizeAmount;
                }

                prizeAmount = prizeAmount - result.results[5].amount;
            }

            if (result.results[4].count > 0) {
                var isBelow = (
                    result.results[3].count > 0 ||
                    result.results[2].count > 0 ||
                    result.results[1].count > 0 
                );
                if (isBelow == true) {
                    result.results[4].amount = prizeAmount * 0.5;
                } else {
                    result.results[4].amount = prizeAmount;
                }

                prizeAmount = prizeAmount - result.results[4].amount;
            }
            if (result.results[3].count > 0) {
                var isBelow = (
                    result.results[2].count > 0 ||
                    result.results[1].count > 0 
                );
                if (isBelow == true) {
                    result.results[3].amount = prizeAmount * 0.5;
                } else {
                    result.results[3].amount = prizeAmount;
                }

                prizeAmount = prizeAmount - result.results[3].amount;
            }
            if (result.results[2].count > 0) {
                var isBelow = (
                    result.results[1].count > 0 
                );
                if (isBelow == true) {
                    result.results[2].amount = prizeAmount * 0.6;
                } else {
                    result.results[2].amount = prizeAmount;
                }

                prizeAmount = prizeAmount - result.results[2].amount;
            }
            if (result.results[1].count > 0) {
                result.results[1].amount = prizeAmount; // * 0.6;
                //prizeAmount = prizeAmount -this.results[1].amount;      
            }

        }
    }

    $scope.amountCalculator2 = function() {
        // this.amount = {
        //        totalTicketsAmount: 0,
        //        totalTicketsNo: 0,
        //        totalPrizeAmountAux: 0,
        //        totalPrizeAmount: 0,
        //        profit: 4,
        //    };
        this.calculateAmount = function(result) {

            this.totalTicketsNo = result.count;

            this.totalTicketsAmount = result.amount;

            this.totalPrizeAmount = this.totalTicketsAmount;

            var prizeAmount = this.totalPrizeAmount; // - this.profit;
            if (result.result1.results[6].count > 0) {
                result.result1.results[6].amount = prizeAmount * 0.5;
                prizeAmount = prizeAmount - result.result1.results[6].amount;
            }

            if (result.result1.results[5].count > 0) {
                var isBelow = (
                    result.result1.results[4].count > 0 ||
                    result.result1.results[3].count > 0 ||
                    result.result1.results[2].count > 0 ||
                    result.result1.results[1].count > 0 
                );
                if (isBelow == true) {
                    result.result1.results[5].amount = prizeAmount * 0.5;
                } else {
                    result.result1.results[5].amount = prizeAmount;
                }

                prizeAmount = prizeAmount - result.result1.results[5].amount;
            }

            if (result.result1.results[4].count > 0) {
                var isBelow = (
                    result.result1.results[3].count > 0 ||
                    result.result1.results[2].count > 0 ||
                    result.result1.results[1].count > 0 
                );
                if (isBelow == true) {
                    result.result1.results[4].amount = prizeAmount * 0.5;
                } else {
                    result.result1.results[4].amount = prizeAmount;
                }



                prizeAmount = prizeAmount - result.result1.results[4].amount;
            }
            if (result.result1.results[3].count > 0) {
                var isBelow = (
                    result.result1.results[2].count > 0 ||
                    result.result1.results[1].count > 0 
                );
                if (isBelow == true) {
                    result.result1.results[3].amount = prizeAmount * 0.5;
                } else {
                    result.result1.results[3].amount = prizeAmount;
                }

                prizeAmount = prizeAmount - result.result1.results[3].amount;
            }
            if (result.result1.results[2].count > 0) {
                var isBelow = (
                    result.result1.results[1].count > 0
                );
                if (isBelow == true) {
                    result.result1.results[2].amount = prizeAmount * 0.6;
                } else {
                    result.result1.results[2].amount = prizeAmount;
                }

                prizeAmount = prizeAmount - result.result1.results[2].amount;
            }
            if (result.result1.results[1].count > 0) {
                result.result1.results[1].amount = prizeAmount; // * 0.6;
                //prizeAmount = prizeAmount -this.results[1].amount;      
            }

        }
    }

    $scope.usersConfig = {
        list: [],
        selection: 10,
        blist: [],
        b: 6,
        init: function() {
            this.list.push(2);
            this.list.push(3);
            this.list.push(4);

            this.list.push(10);
            this.list.push(50);
            this.list.push(100);
            this.list.push(200);
            this.list.push(500);
            this.list.push(700);
            this.list.push(1000);
            this.list.push(2000);
            this.list.push(3000);
            this.list.push(4000);
            this.list.push(5000);
            this.list.push(6000);
            this.list.push(7000);
            this.list.push(8000);
            this.list.push(9000);
            this.list.push(10000);
            this.list.push(15000);
            this.list.push(20000);
            this.list.push(25000);
            this.list.push(30000);
            this.list.push(40000);
            this.list.push(50000);



            this.blist.push(5);
            this.blist.push(6);
            this.blist.push(7);
            this.blist.push(8);
            this.blist.push(9);
            this.blist.push(10);
            this.blist.push(11);
            this.blist.push(12);
            this.blist.push(13);
            this.blist.push(14);
            this.blist.push(15);
            this.blist.push(16);
        },
        userConfigChanged: function() {
            //$scope.users.init($scope.usersConfig.selection);
            $scope.extragere.simulate();
        },

        ticketNumbersChanged: function() {
            $scope.extragere.simulate();
        }
    };

    $scope.profit = {
        list: [],
        value: 30,
        init: function() {
            this.list.push(10);
            this.list.push(15);
            this.list.push(20);
            this.list.push(25);
            this.list.push(30);
            this.list.push(35);
            this.list.push(40);
            this.list.push(45);
            this.list.push(50);
        },
        profitChanged: function() {
            $scope.extragere.simulate();
        }
    }

    $scope.bollNumbers = {
        list: [],
        value: 16,
        init: function() {
            this.list.push(16);
            this.list.push(17);
            this.list.push(18);
            this.list.push(19);
            this.list.push(20);
            this.list.push(21);
            this.list.push(22);
            this.list.push(23);
            this.list.push(24);
            this.list.push(25);
            this.list.push(26);
            this.list.push(27);
            this.list.push(28);
            this.list.push(29);
            this.list.push(30);
            this.list.push(31);
            this.list.push(32);
            this.list.push(33);
            this.list.push(34);
            this.list.push(35);
            this.list.push(36);
            this.list.push(37);
            this.list.push(38);
            this.list.push(39);
            this.list.push(40);
            this.list.push(41);
        },
        changed: function() {
            $scope.numbers.init(this.value);
            $scope.extragere.simulate();
        }
    }
    $scope.noOfNumbersToBeExtracted = {
        list: [],
        value: 6,
        init: function() {
            this.list.push(5);
            this.list.push(6);
        },
        changed: function() {
            $scope.extragere.simulate();
        }
    }

    $scope.users = null;

    function init() {
        $scope.users = new users();
        $scope.noOfNumbersToBeExtracted.init();
        $scope.profit.init();
        $scope.bollNumbers.init();

        $scope.numbers.init(16);
        $scope.usersConfig.init();

        $scope.extragere.simulate();

    }

    init();


});