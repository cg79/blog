const chalk = require('chalk');

console.log(chalk
            .underline
            .bgGreenBright
            .black('¡Hola Globant!'));
