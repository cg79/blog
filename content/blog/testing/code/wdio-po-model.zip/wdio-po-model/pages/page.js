class Page {
    
    get pageHeading() { return $('article h1'); }

    open(path) {
        path = path || '';
        browser.url('/' + path);
    }

    getTitle() {
        return browser.getTitle();
    }

    getUrl() {
        return browser.getUrl();
    }
}

export default Page;