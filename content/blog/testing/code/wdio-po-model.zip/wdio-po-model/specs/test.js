
describe ('Navigate through the WDIO web page', () => {

    before(() => {
        browser.url('/');
    });

    it('should access Developer Guide page', () => {
        browser.pause(5000);
        expect(browser.checkFullPageScreen('examplePaged')).to.equal(0);
    });
});