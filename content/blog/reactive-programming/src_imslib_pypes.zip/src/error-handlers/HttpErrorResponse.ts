import { IHttpErrorResponse } from "./IHttpErrorResponse";

/**
 * class used to create a IHttpErrorResponse object in case the code is != 200
 */
class HttpErrorResponse {
    
    verify (exception: any): IHttpErrorResponse | null {
        if ( !exception ) {
            return null;
        }
        let errorInfo = exception.response ? exception.response: exception.request;
            /* if exception.response
             * The request was made and the server responded with a
             * status code that falls out of the range of 2xx
             */

             /*
             * if exception.request
             * The request was made but no response was received, `error.request`
             * is an instance of XMLHttpRequest in the browser and an instance
             * of http.ClientRequest in Node.js
             */

        errorInfo = errorInfo || exception;     

        const status = errorInfo.status || null;
        if ( !status ) {
            return {
                error: 'networkError',
                message: errorInfo.message || '',
                code: 0
            }
        }

        if ( status === 429 )
            return {
                error: 'rate_limited',
                retryAfter: errorInfo.header ? parseInt( errorInfo.headers.retryAfter ) : 10,
                code: status
            }

        if ( status.toString().match( /5\d{2}/g ) ) {
            return {
                error: 'server_error',
                code: status
            }
        }

        return null;

    }
}

export default new HttpErrorResponse();
