
/**
 * interface used to pass the http errors to external applications
 */
export interface IHttpErrorResponse {
    code: number;

    error?: string;

    retryAfter?: number;

    message?: string;

}