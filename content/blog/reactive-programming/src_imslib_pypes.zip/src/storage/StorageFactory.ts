import { MemoryStorage } from './MemoryStorage';
import { STORAGE_MODE } from '../constants/ImsConstants';

/**
 * A cross-browser way to use `sessionStorage`
 *
 * @exports storage
 * @requires MemoryStorage
 */
class StorageFactory {

  memoryStorageInstance: MemoryStorage | null = null;
  get memoryStorage(): MemoryStorage {
    if(!this.memoryStorageInstance) {
      this.memoryStorageInstance = new MemoryStorage();
    }
    return this.memoryStorageInstance;
  }
  
  /**
  * 
  * @param storageName represents the storage name
  * @returns the local or session storage; in case there is a problem with storage, the memory storage is returned
  */
  getStorageByName ( storageName: STORAGE_MODE ): Storage {
    if(storageName === STORAGE_MODE.MemoryStorage) {
      return this.memoryStorage;
    }
    
    const storageInstance =
      storageName === STORAGE_MODE.LocalStorage ? window.localStorage : window.sessionStorage;

    if ( !storageInstance ) {
      return this.memoryStorage;
    }
    const storageIsWorkingAsExpected = this.verifyStorage( storageInstance );
    if ( !storageIsWorkingAsExpected ) {
      return this.memoryStorage;
    }

    return storageInstance;
  }

  /**
   * returns the available storage; the priority is local storage and after that the session storage
   * if no local or session storage is available, the Memory Storage is returned
   */
  getAvailableStorage(): Storage {
    const storage = this.getStorageByName(STORAGE_MODE.LocalStorage);
    if(storage instanceof MemoryStorage) {
      return this.getStorageByName(STORAGE_MODE.SessionStorage);
    }
    return storage;
  }

  /**
   * 
   * @param storage represents the storage instance
   * @returns true if storage is working as expected otherwise false
   */
  verifyStorage ( storage: Storage ): boolean {
    if ( !storage || !storage.setItem ) {
      return false;
    }
    const storageKey = 'test';

    try {
      storage.setItem( storageKey, 'true' );
      const storageValue = storage.getItem( storageKey );

      if ( storageValue !== 'true' ) {
        return false;
      }
      storage.removeItem( storageKey );

      return true;
    }
    catch ( ex ) {
      return false;
    }
  }

}

export default new StorageFactory();