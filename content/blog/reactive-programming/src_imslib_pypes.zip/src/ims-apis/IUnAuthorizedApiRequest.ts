export interface IUnAuthorizedApiRequest {
    client_id: string;

    scope? : string;
}