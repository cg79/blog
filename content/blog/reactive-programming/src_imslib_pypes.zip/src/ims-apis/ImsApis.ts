import { IDictionary } from './../facade/IDictionary';
import { IAuthorizedApiRequest } from './IAuthorizedApiRequest';
import { IUnAuthorizedApiRequest } from './IUnAuthorizedApiRequest';
import { HEADERS } from './../constants/ImsConstants';
import Build from '../config/Build';
import { AxiosResponse, AxiosRequestConfig, AxiosInstance } from 'axios';
import set from 'lodash/set';
import UrlHelper from '../url/UrlHelper';
import ApiHelpers from '../api-helpers/ApiHelpers';

/**
 * class used as a entry point for Ims api's
 * @todo discuss rate limit --> code 429 on http response. 
 */

export class ImsApis {

  private CONTENT_FORM_ENCODED = 'application/x-www-form-urlencoded;charset=utf-8';
  axios: AxiosInstance;

  apiParameters: any;
  /**
   * imsApis constructor; 
   * sets the axios to use credentials
   */
  constructor ( axiosInstance: AxiosInstance, apiParameters: any = {} ) {
    this.axios = axiosInstance;
    this.apiParameters = apiParameters;
    axiosInstance.defaults.withCredentials = true;

  }

  /**
   * validate the input token
   * @param request IAuthorizedApiRequest contains clientId and token information
   */
  validateToken ( request: IAuthorizedApiRequest ): Promise<AxiosResponse<any>> {

    const { token, client_id } = request;

    const additionalParams = {
      type: 'access_token',
      ...ApiHelpers.getCustomApiParameters( this.apiParameters, 'validate_token' )
    };

    const config: AxiosRequestConfig = this.createAuthorizationHeader( token );

    const url = `${ Build.baseUrlAdobe }/ims/validate_token/v1?client_id=${ client_id }`;

    return this.axios.post(
      url,
      {
        token,
        ...additionalParams,
      },
      config );
  }

  /**
   * retreive the profile based on the input token
   * @param request IAuthorizedApiRequest contains clientId and token information
   */
  getProfile ( request: IAuthorizedApiRequest ): Promise<any> {

    const { token, client_id } = request;

    const additionalParams = {
      ...ApiHelpers.getCustomApiParameters( this.apiParameters, 'profile' )
    };

    const config: AxiosRequestConfig = this.createAuthorizationHeader( token );

    const queryStrings = UrlHelper.uriEncodeData( {
      client_id,
      ...additionalParams,
    } );

    const url = `${ Build.baseUrlAdobe }/ims/profile/v1?${ queryStrings }`;

    return this.axios.get( url, config );
  }

  /**
   * @returns the user info based on the input token
   * @param request IAuthorizedApiRequest contains clientId and token information
   */
  getUserInfo ( request: IAuthorizedApiRequest ): Promise<any> {

    const { token, client_id } = request;
    const additionalParams = {
      ...ApiHelpers.getCustomApiParameters( this.apiParameters, 'userinfo' )
    };

    const config: AxiosRequestConfig = this.createAuthorizationHeader( token );

    const queryStrings = UrlHelper.uriEncodeData( {
      client_id,
      ...additionalParams,
    } );

    const url = `${ Build.baseUrlAdobe }/ims/userinfo/v1?${ queryStrings }`;

    return this.axios.get( url, config );
  }

  /**
    * invalidate the input token
    * @param request IAuthorizedApiRequest contains clientId and token information
    */
  logoutToken ( apiRequest: IAuthorizedApiRequest ): Promise<AxiosResponse<any>> {
    const { client_id, token: access_token } = apiRequest;
    const additionalParams = {
      ...ApiHelpers.getCustomApiParameters( this.apiParameters, 'logout_token' )
    };

    const url = `${ Build.baseUrlServices }/ims/logout/v1`;

    return this.axios.post( url,
      {
        client_id,
        access_token,
        ...additionalParams,
      } );
  }

  /**
   * Does an API to check the cookie status of the browser.
   */
  checkStatus (): Promise<any> {
    const url = `${ Build.baseUrlServices }/ims/check/v1/status`;
    return this.axios.get( url );
  }

  /**
   * @returns a new token
   * @param request IUnAuthorizedApiRequest contains clientId information
   * @param scope string contains the scope used for check token api
   * @todo We will probably need also check token v5
   */
  checkToken ( apiRequest: IUnAuthorizedApiRequest, externalParameters: IDictionary, scope: string ): Promise<AxiosResponse<any>> {
    const { client_id } = apiRequest;
    const additionalParams = {
      ...ApiHelpers.mergeExternalParameters( externalParameters, this.apiParameters, 'check_token' )
    };

    const url = `${ Build.baseUrlServices }/ims/check/v4/token`;

    const data = UrlHelper.uriEncodeData( {
      ...additionalParams,
      client_id,
      scope
    } );

    return this.axios.post(
      url,
      data,
      this.formEncoded()
    );
  }

  /**
   * @returns list of api providers
   * @param request IUnAuthorizedApiRequest contains clientId information
   */
  listSocialProviders ( apiRequest: IUnAuthorizedApiRequest ): Promise<any> {
    const { client_id } = apiRequest;

    const additionalParams = {
      ...ApiHelpers.getCustomApiParameters( this.apiParameters, 'providers' )
    };

    const queryStrings = UrlHelper.uriEncodeData( {
      client_id,
      ...additionalParams
    } );

    const url = `${ Build.baseUrlServices }/ims/social/v1/providers?${ queryStrings }`
    return this.axios.get( url );
  }

  /**
  * @see {@link https://wiki.corp.adobe.com/display/ims/Implicit+Jump+Tokens |Implicit Jump Tokens}
  * @param request IUnAuthorizedApiRequest contains clientId and token information
  * @param ijt {string}
  */
  exchangeIjt ( apiRequest: IUnAuthorizedApiRequest, ijt: string ): Promise<AxiosResponse<any>> {

    const { client_id } = apiRequest;
    const additionalParams: any = {
      ...ApiHelpers.getCustomApiParameters( this.apiParameters, 'ijt' )
    };

    const url = `${ Build.baseUrlServices }/ims/jump/implicit/${ ijt }`;

    let queryStrings = UrlHelper.uriEncodeData( {
      client_id,
      ...additionalParams
    } );

    let apiUrl = `${ url }?${ queryStrings }`;
    if ( apiUrl.length > 2048 ) {
      delete additionalParams[ 'redirect_uri' ];
      queryStrings = UrlHelper.uriEncodeData( additionalParams );
      apiUrl = `${ url }?${ queryStrings }`;
    }

    return this.axios.get( apiUrl );

  }

  /**
   * Returns the URL to the avatar of a user
   * @param {UserId} userId
   * @returns {String}
   */
  avatarUrl ( userId: string ): string {
    return `${ Build.baseUrlAdobe }/ims/avatar/download/${ userId }`;
  }

  /**
   * create the authorization header in case the accesToken exists
   * @param accessToken {string}; 
   * @returns {string}
   */
  private createAuthorizationHeader ( accessToken: string ): AxiosRequestConfig {
    const headers = {};
    if ( accessToken ) {
      set( headers, HEADERS.AUTHORIZATION, `Bearer ${ accessToken }` );
    }
    return {
      headers
    }
  }

  /**
   * 
   * @param headers the header which will be sent to ims server on API request
   */
  private formEncoded ( headers: IDictionary = {} ): IDictionary {
    set( headers, 'content-type', this.CONTENT_FORM_ENCODED );
    return headers;
  }

}
