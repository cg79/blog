
/**
 * interface used to pass only the necessary properties to manin functionalities
 */
export interface IAdobeDataRequest {
    clientId: string;
    scope: string;
}