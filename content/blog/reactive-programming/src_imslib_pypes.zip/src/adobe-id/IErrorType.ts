
/**
 * Enumeration values used for ims error types
 */
export enum IErrorType {

    /**
     * http exception type
     */
    HTTP = 'http',

    /**
     * fragment exception type
     */
    FRAGMENT = 'fragment',

    /**
     * csrf exception type
     */
    CSRF = 'csrf',

    /**
     * error triggered when get token method is called using a different api than authorize
     */
    NOT_AUTHORIZE = 'not_authorize',

    /**
     * exception triggered when the profile api throws exception
     */
    PROFILE_EXCEPTION = 'profile_exception',

}