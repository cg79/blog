import { IDictionary } from './../facade/IDictionary';
import get from 'lodash/get';
import { IAdobeIdData } from './IAdobeIdData';
import { IAdobeHandlers } from './IAdobeHandlers';
import { IRedirectRequest } from '../adobe-ims/facade/IRedirectRequest';
import Build from '../config/Build';
import { AdobeIdKey, DEFAULT_LANGUAGE } from '../constants/ImsConstants';
import { IErrorType } from './IErrorType';

/**
 *  Class used to store the adobe data values. 
 * 
 *  Ims library will use these values for all operations
 */
export class AdobeIdData implements IAdobeIdData {

  /** 
    @property Object containing various custom parameters for IMS.
    This object is used in case a custom API parameter is desired to be sent to the back-end.

    E.G. { logout: 'your_custom_value' }

    The list of api's which can be customized are: authorize, validate_token, profile, userinfo, logout, logout_token, check, providers, ijt
  */
  api_parameters?= {};

  /**
    @property {string} Localization value used by ims library. 
    
    Default value is `en_US`
  */
  locale = '';

  /**
   * @property {string} - The scopes used to acquire access tokens. A comma separated list of client scopes.
   * if empty the one from Build it will be used 
   * No whitespace.
   * Default scopes: AdobeID
   */
  scope = '';

  /**
  * @property {string} - The client id used by ims library
  */
  client_id = '';

  /** @function {adobeid.onAccessTokenHasExpired} onAccessTokenHasExpired
   *  Function to be executed if the 'access_token' is invalid.
   */
  onAccessTokenHasExpired: Function | null = null;

  /** @function {adobeid.onReady} [onReady] - Function to be executed once imslib.js has been fully
   * initialized.
   */
  onReady: Function | null = null;

  /**  @function {adobeid.onProfile} - Function to be executed when a user Profile has been
  * received.
  */
  onProfile: Function | null = null;

  /**  @function {adobeid.onAccessToken} - Function to be executed once imslib.js has acquired
  * an `access_token`.
  */
  onAccessToken: Function | null = null;

  /**
   * @function {adobeid.onReauthAccessToken} Function used to trigger the reauth access token
   */
  onReauthAccessToken: Function | null = null;

  /**
   * @function {adobeid.onError}
   * Function used to notify external libraries for ims errors
   */
  onError: Function | null = null;

  /**
   * @property {string} Used as redirect url
   * 
   * The redirect uri value is used for signin, signout operations and the used value is the one from external parameters or adobe id data or window.location.href
   */
  redirect_uri: string;

  /**
   * @constructor Create the adobeIdData object with all necessary properties from adobeData input paramater
   * 
   * It uses the input adobeData parameter or the object stored in window.adobeid
   */
  constructor ( adobeData: IAdobeIdData | null = null ) {

    const adobeid = adobeData ? adobeData : get( window, AdobeIdKey );
    if ( !adobeid ) {
      throw new Error( 'Please provide adobeId information' );
    }
    const {
      api_parameters,
      client_id,
      locale,
      scope,
      redirect_uri,
      onProfile,
      onAccessToken,
      onReauthAccessToken,
      onAccessTokenHasExpired,
      onReady,
      onError,
    } = adobeid;
    this.api_parameters = api_parameters ? api_parameters : {};
    this.client_id = client_id;
    this.locale = locale || DEFAULT_LANGUAGE;
    this.scope = scope;
    this.redirect_uri = redirect_uri;
    this.onProfile = onProfile ? onProfile : null;
    this.onAccessToken = onAccessToken ? onAccessToken : null;
    this.onReauthAccessToken = onReauthAccessToken ? onReauthAccessToken : null;
    this.onAccessTokenHasExpired = onAccessTokenHasExpired ? onAccessTokenHasExpired : null;
    this.onReady = onReady ? onReady : null;
    this.onError = onError ? onError : null;
  }

  /**
   * Handlers object is used to invoke the adobe id data events.
   * 
   * When a token, profile is aquired, or token is expired and library is fully intialized, an event is triggered
   */
  handlers: IAdobeHandlers = {
    triggerOnAccessToken: ( token: string | null ): void => {
      this.onAccessToken && this.onAccessToken( token,  this.client_id );
    },
    triggerOnReauthAccessToken: ( token: string | null ): void => {
      this.onReauthAccessToken && this.onReauthAccessToken( token, this.client_id);
    },
    triggerOnAccessTokenHasExpired: (): void => {
      this.onAccessTokenHasExpired && this.onAccessTokenHasExpired(this.client_id);
    },
    triggerOnProfileReceived: ( profile: IDictionary | null ): void => {
      this.onProfile && this.onProfile( profile, this.client_id );
    },
    triggerOnReady: (): void => {
      this.onReady && this.onReady(this.client_id);
    },
    triggerOnError: (errorType: IErrorType, error: any ) => {
      this.onError && this.onError(errorType,  error, this.client_id );
    }
  };

  /**
   * Function used by ims to use only the neccesarry properties from AdobeIdData on sign in and reauth methods
   * @param externalParameters {Object} the external parameters used for signin and reauth methods
   */
  createRedirectRequest(externalParameters: IDictionary): IRedirectRequest {
    const { api_parameters: apiParameters = { }, client_id: clientId, redirect_uri: adobeIdRedirectUri, scope, locale } = this;

    const redirectRequest: IRedirectRequest = {
      adobeIdRedirectUri,
      apiParameters,
      clientId,
      externalParameters,
      jslibver: Build.version,
      scope,
      locale,
      response_type: 'token',
    };

    return redirectRequest;
  }

}
