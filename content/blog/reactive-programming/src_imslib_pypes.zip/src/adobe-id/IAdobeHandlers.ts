
import { ErrorFunction } from './CustomTypes';

/**
 * Interface used by AdobeIdData to trigger adobeid functions
 */
export interface IAdobeHandlers {

      /**
       * Event triggered when a new access token is aquired
       */
      triggerOnAccessToken: Function;

      /**
       * Event triggered when a reauth token has aquired
       */
      triggerOnReauthAccessToken: Function;

      /**
       * Event triggered when an access token is invalid;
       * NOTE: the developers should consider that the access token is not available; Same as triggerOnAccessToken(null)
       */
      triggerOnAccessTokenHasExpired: Function;

      /**
       * Event triggered when the profile is aquired
       */
      triggerOnProfileReceived: Function;

      /**
       * Event triggered when the ims library is fully intialized
       */
      triggerOnReady: Function;

      /**
       * Event trigered when an unexpected error occured in imslib
       */
      triggerOnError: ErrorFunction;
}