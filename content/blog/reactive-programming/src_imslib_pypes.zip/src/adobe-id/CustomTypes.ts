
import { IErrorType } from './IErrorType';

/**
 * Custom function type used to trigger the error handler
 * Every call of the error handler should contain the error type and the associated message
 * @param type {IErrorType} - represents the error type used to trigger the error handler
 * @param message {any} - represents the custom error message or exception object
 */
export type ErrorFunction = ( type: IErrorType, message: any ) => void;
