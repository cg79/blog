import { IDictionary } from './../facade/IDictionary';

export interface IAdobeIdData {
  /** 
   {Object.<string, Object>} [api_parameters] - An object containing various custom parameters for IMS
  */
  api_parameters?: IDictionary | undefined;

  client_id: string;
  /**
   * The scopes used to acquire access tokens
   */
  scope: string;
  /**
    will default to `en_US` if none is set
  */
  locale: string;

  /**
   * The redirect uri value is used for signin, signout operations and the used value is the one from external parameters or adobe id data or window.location.href
   */
  redirect_uri?: string | undefined;

  /**
   * Handler used for profile notifications
   */
  onProfile: Function | null;

  /**
   * Handler used for access token notification
   */
  onAccessToken: Function | null;

  /**
   * handler used for token expiration notifications
   */
  onAccessTokenHasExpired: Function | null;

  /**
   * handler used for token reauth notifications
   */
  onReauthAccessToken: Function | null;

  /**
   * handler used to notify that the library is initialized
   */
  onReady: Function | null;

  /**
   * handler used to notify about any errors
   */
  onError: Function | null;

}