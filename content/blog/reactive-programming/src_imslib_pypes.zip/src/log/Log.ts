import Build from '../config/Build';

/**
 * Wrapper for <code>console</code>. Checks <code>console</code> is available and <code>debug</code> Mode is enabled.
 *
 * @exports log
 *
 */
class Log {
  /**
   * Wrapper function.
   *
   * @param {String} method - Which <code>console</code> method to use.
   * @param {*} args - Arguments object
   *
   * @private
   */
  print = ( method: Function, args: any ): void => {
    if (
      !Build.logEnabled ||
      // IE8 & IE9 only support console functions when developer tools are open.
      // Otherwise the console object is `undefined` and any calls will throw errors.
      !( window.console && typeof window.console.log === 'function' )
    ) {
      return;
    }
    method(...args );
  };

  /**
   * Writes an error to the console when the evaluated expression is false.
   *
   * @example
   * log.assert(1 == 2, "Counting is hard.");
   *
   * @param {Boolean} expression - Expression to evaluate.
   * @param {String} message - Message to print if <code>epxression</code> is <code>false</code>.
   *
   * @static
   */
  assert = ( val: boolean | string, message: string | any ): void => {
    this.print( console.assert, [ val, message ] );
  };

  /**
   * Writes an error to the console when the evaluated expression is false.
   *
   * @example
   * log.assert(1 == 2, "Counting is hard.");
   *
   * @param {Boolean} expression - Expression to evaluate.
   * @param {String} message - Message to print if <code>epxression</code> is <code>false</code>.
   *
   * @static
   */
  assertCondition = ( condition: Function, message: string | any ): void => {
    if ( !condition() ) {
      this.print( console.error, [ message ] );
    }
  };

  /**
   * Prints a message similar to <code>console.log()</code>, styles the message like an error, and includes a stack
   * trace from where the method wasval, called.
   *
   * @see {@link https://developers.google.com/web/tools/chrome-devtools/console/#filtering_the_console_output | Filtering the Console output}
   *
   * @example
   * log.error("Define window.adobeid", "would you?!");
   * @param {String} message - Message to print.
   */
  error = ( ...args: any[] ): void => {
    this.print( console.error, args );
  };

  /**
   * logs a warnig message
   */
  warn = ( ...args: any[] ): void => {
    this.print( console.warn, args );
  };

  /**
   * Prints a message like <code>console.log()</code> but also shows an icon (blue circle with white "i") next to the
   * output.
   *
   * <code>console.info()</code> can be filtered in the Console, whereas <code>console.log()</code> can not.
   *
   * @example
   * log.info("Imslib.js Ready", "to Rumble");
   *
   * @param {String} message - Message to print.
   *
   * @static
   */
  info = ( ...args: any[] ): void => {
    this.print( console.info, args );
  };

  /**
   * Toggle logging ON or OFF.
   *
   * Logging can also be enabled by setting <code>window.adobeid.debug = true</code>.
   *
   * @example
   * adobeIMS.toggleLogging(true);
   *
   * @param {Boolean} mode - Enable / disable logging.
   *
   * @memberof module:log
   * @public
   * @see adobeid
   * @static
   */
  toggleLogging = ( mode: string ): void => {
    if ( typeof mode === 'boolean' ) {
      Build.logEnabled = mode;
    }
  };
}

export default new Log();
