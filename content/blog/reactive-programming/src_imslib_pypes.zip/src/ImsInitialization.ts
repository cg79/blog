import { AdobeIMS } from './adobe-ims/AdobeIMS';

import { AdobeIMSKey, AdobeImsFactory, AdobeIdKey } from "./constants/ImsConstants";
import { IAdobeIdData } from './adobe-id/IAdobeIdData';
import get from 'lodash/get';
import set from 'lodash/set';

/**
 * singleton class which is created on the same time when library is injected into the page.
 * it is used to provide the possibility to an external library to create a new instance of AdobeIMS
 * also, if the window contains a value for adobeId, it will create a new instance of AdobeIMS
 */
class ImsInitialization {

  /**
   * create a new instance of ims lib based on adobe id data
   */
  initAdobeIms(): void {
    set( window, AdobeImsFactory, {
      createIMSLib: this.createIMSLib
    } );

    const adobeIMS: AdobeIMS | null = get( window, AdobeIMSKey );

    if ( !adobeIMS ) {
      const adobeIdData = get( window, AdobeIdKey );
      if ( !adobeIdData ) {
        return;
      }
      this.createIMSLib(adobeIdData);
    }
  }

  /**
   * 
   * @param adobeData represents the custom adobeData
   * @returns a new instance of the AdobeIms library based on input adobeIdData
   */
  private createIMSLib = ( adobeData: IAdobeIdData | null = null, adobeImsWindowKey = AdobeIMSKey ): AdobeIMS => {
    const adobeIMS = new AdobeIMS( adobeData );
    set( window, adobeImsWindowKey, adobeIMS );

    adobeIMS.initialize();

    return adobeIMS;
  };

}

export default new ImsInitialization();
