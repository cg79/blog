import { AdobeIMSKey, AdobeImsFactory, AdobeIdKey } from "./constants/ImsConstants";
import { IAdobeIdData } from './adobe-id/IAdobeIdData';
import get from 'lodash/get';
import set from 'lodash/set';
import { AdobeIMSThin } from './adobe-ims/AdobeIMSThin';

/**
 * singleton class which is created on the same time when library is injected into the page.
 * it is used to provide the possibility to an external library to create a new instance of AdobeIMS
 * also, if the window contains a value for adobeId, it will create a new instance of AdobeIMS
 */
class ImsThinInitialization {

  /**
   * create a new instance of ims lib based on adobe id data
   */
  initAdobeIms(): void {
    set( window, AdobeImsFactory, {
      createIMSLib: this.createIMSThinLib
    } );

    const adobeIMS: AdobeIMSThin | null = get( window, AdobeIMSKey );

    if ( !adobeIMS ) {
      const adobeIdData = get( window, AdobeIdKey );
      if ( !adobeIdData ) {
        return;
      }

      this.createIMSThinLib(adobeIdData);
    }
  }

  /**
   * 
   * @param adobeData represents the custom adobeData
   * @returns a new instance of the AdobeIms library based on input adobeIdData
   */
  private createIMSThinLib = ( adobeData: IAdobeIdData | null = null, adobeImsWindowKey = AdobeIMSKey ): AdobeIMSThin => {
    const adobeIMSThin = new AdobeIMSThin( adobeData );
    set( window, adobeImsWindowKey, adobeIMSThin );

    adobeIMSThin.initialize();

    return adobeIMSThin;
  };

}

export default new ImsThinInitialization();
