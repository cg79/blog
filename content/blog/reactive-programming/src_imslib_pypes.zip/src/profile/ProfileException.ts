

/**
 * class used to trigger profile errors
 */
export class ProfileException  {

    message = null;
    constructor(message: any) {
        this.message = message;
    }
}