import { IDictionary } from './../facade/IDictionary';
import { IServiceRequest } from '../adobe-ims/facade/IServiceRequest';
import StorageFactory from './../storage/StorageFactory';
import { STORAGE_MODE, TOKEN_STORAGE_KEY } from '../constants/ImsConstants';
import { TokenFields } from './TokenFields';
import { NoTokenException } from './NoTokenException';
import { IRefreshTokenResponse } from './IRefreshTokenResponse';
import FragmentHelper from '../url/FragmentHelper';
import { FragmentException } from './FragmentException';
import { CsrfService } from '../adobe-ims/csrf/CsrfService';
import { IFragmentExceptionType } from './IFragmentExceptionType';

const API_AUTHORIZE = 'authorize';

/**
 * class used to store the specific token methods
 */
export class TokenService {

       /**
        * local storage instance used to manage with the tokens
        */
       storage: Storage;
       tokenServiceRequest: IServiceRequest;

       private csrfService: CsrfService;
       constructor ( tokenServiceRequest: IServiceRequest, csrfService: CsrfService ) {
              this.csrfService = csrfService;
              this.tokenServiceRequest = tokenServiceRequest;
              this.storage = StorageFactory.getStorageByName( STORAGE_MODE.LocalStorage );
       }

       /**
        * 
        * @param tokenRequest Token request object
        * @returns {string} representing the token from local or session storage
        */
       getToken = (): Promise<TokenFields> => {
              return new Promise( ( resolve, reject ): Promise<string> | void => {
                     const { clientId, scope, imsApis } = this.tokenServiceRequest;
                     let token = '';

                     const fragmentResult: TokenFields | FragmentException | null = this.getTokenFromFragment();

                     if ( fragmentResult instanceof FragmentException ) {
                            return reject( fragmentResult );
                     }

                     if ( fragmentResult && fragmentResult.validate( clientId, scope ) ) {
                            this.addTokenToStorage( fragmentResult );
                            return resolve( fragmentResult );
                     }

                     token = this.getTokenFromStorage() || '';
                     if ( !token ) {
                            throw new NoTokenException();
                     }

                     imsApis.validateToken( { client_id: clientId, token } )
                            .then( ( tokenResponse: any ) => {
                                   const tokenResponseData = tokenResponse.data;
                                   const tokenFields = new TokenFields( {
                                          ...tokenResponseData,
                                          tokenValue: token
                                   } );

                                   if ( tokenFields.validate( clientId, scope ) ) {
                                          this.addTokenToStorage( tokenFields );
                                          return resolve( tokenFields );
                                   }
                                   throw new Error( 'storage token is invalid' );
                            } )
                            .catch( ( ex: any ) => {
                                   this.removeTokenFromLocalStorage();
                                   reject( ex );
                            } )

              } );
       }

       /**
        * @returns the object values from the url fragment
        */
       private getTokenFromFragment (): TokenFields | FragmentException | null {
              const fragmentValues: IDictionary | null = FragmentHelper.fragmentToObject();

              if ( !fragmentValues ) {
                     return null;
              }
              const { access_token: token, scope, error, nonce, api, ...other } = fragmentValues;

              if ( error ) {
                     return new FragmentException( IFragmentExceptionType.FRAGMENT, error as string );
              }

              if ( api !== API_AUTHORIZE ) {
                     return new FragmentException( IFragmentExceptionType.NOT_AUTHORIZE, `api should be authorize and ${ api } is used` );
              }

              const validCsrf = this.csrfService.verify( nonce as string );

              if ( !validCsrf ) {
                     return new FragmentException( IFragmentExceptionType.CSRF, 'CSRF exception' );
              }

              return token ? new TokenFields(
                     {
                            scope,
                            tokenValue: token as string,
                            valid: true,
                            other
                     }
              ) : null;

       }

       /**
        * @returns the TokenFields structure from local storage or null
        * @isReauth boolean value; true if token is for reauthentification
        */
       getTokenFieldsFromStorage ( isReauth = false ): TokenFields | null {
              const tokenStorageKey = this.getAccessTokenKey( isReauth );
              const tokenData = this.storage.getItem( tokenStorageKey );

              if ( !tokenData ) {
                     return null;
              }

              const parsedToken = JSON.parse( tokenData );

              return new TokenFields( parsedToken );
       }


       /**
        * @returns the validated token information from local storage
        * @isReauth boolean value; true if token is for reauthentification
        */
       getTokenFromStorage (): string | null {
              const { clientId, scope } = this.tokenServiceRequest;

              const tokenFields = this.getTokenFieldsFromStorage();
              if ( !tokenFields ) {
                     return null;
              }
              return tokenFields.validate( clientId, scope ) ? tokenFields.tokenValue : null;
       }

       /**
        * @returns the validated token information from local storage for reauth
        */
       getReauthTokenFromStorage (): string | null {
              const { clientId, scope } = this.tokenServiceRequest;

              const tokenFields = this.getTokenFieldsFromStorage( true );
              if ( !tokenFields ) {
                     return null;
              }
              return tokenFields.validate( clientId, scope ) ? tokenFields.tokenValue : null;
       }

       /**
        * private method used to compose the key used for storage
        * @param clientId 
        * @param scope 
        * @param isReAuth default false; true means that the key is for re-authentification
        */
       private getAccessTokenKey ( isReauth = false ): string {
              const { clientId, scope } = this.tokenServiceRequest;
              return `${ TOKEN_STORAGE_KEY }/${ clientId }/${ isReauth }/${ scope }`;
       }

       /**
        * save the token into local storage
        * @param tokenFragment - object with the values from fragment
        */
       addTokenToStorage ( tokenFields: TokenFields ): void {
              if ( !tokenFields.token ) {
                     return;
              }
              const isReauth = tokenFields.isReauth();

              const tokenStorageKey = this.getAccessTokenKey( isReauth );

              this.storage.setItem( tokenStorageKey, JSON.stringify( tokenFields ) );

       }


       /**
        * remove the token from local storage
        */
       removeTokenFromLocalStorage (): void {
              const tokenStorageKey = this.getAccessTokenKey();

              this.storage.removeItem( tokenStorageKey );
       }

       /**
        * remove the reauth token from local storage
        */
       removeReauthTokenFromLocalStorage (): void {
              const tokenStorageKey = this.getAccessTokenKey( true );

              this.storage.removeItem( tokenStorageKey );
       }

       /**
        * 
        * @param externalParameters external parameters received outside of the library
        * @returns IRefreshTokenResponse containing the refresh token information
        */
       refreshToken ( externalParameters: IDictionary = {} ): Promise<IRefreshTokenResponse> {
              return new Promise( ( resolve, reject ): Promise<string> | void => {
                     const { clientId, imsApis, scope } = this.tokenServiceRequest;

                     imsApis.checkToken( {
                            client_id: clientId,
                     }, externalParameters, scope )
                            .then( ( response: any ) => {
                                   if ( !response || !response.data ) {
                                          throw new Error( 'refresh token --> no response' );
                                   }
                                   const { data } = response;
                                   if ( data.error ) {
                                          throw new Error( `refresh token --> error: ${ JSON.stringify( data ) }` );
                                   }
                                   const tokenResponse: IRefreshTokenResponse = data;

                                   this.updateTokenAfterRefresh( tokenResponse );

                                   resolve( tokenResponse );
                            } )
                            .catch( ( ex: any ) => {
                                   this.removeTokenFromLocalStorage();

                                   reject( ex );
                            } )

              } );
       }

       /**
        * update the token into local storage after a refresh action
        * @param tokenResponse {IRefreshTokenResponse}
        * 
        */
       updateTokenAfterRefresh ( tokenResponse: IRefreshTokenResponse ): void {
              const tokenFields: TokenFields = new TokenFields( {
                     tokenValue: tokenResponse.access_token,
              } );
              if ( !tokenFields ) {
                     return;
              }
              const { access_token, expires_in } = tokenResponse;
              tokenFields.tokenValue = access_token;
              tokenFields.token.expires_in = expires_in;

              this.addTokenToStorage( tokenFields );
       }

       /**
        * remove the tokens from the local storage
        */
       purge (): void {
              this.removeTokenFromLocalStorage();
              this.removeReauthTokenFromLocalStorage();
       }

}
