
/**
 * represents the api token response after calling the check method
 */
export interface IRefreshTokenResponse {
    access_token: string;
    expires_in: string;

    token_type: string;

    profile: any;
}