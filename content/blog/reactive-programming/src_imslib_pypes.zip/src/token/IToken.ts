
/**
 * interface used to map the necssary token fields
 */
export interface IToken {
    created_at: string;
    client_id: string;
    user_id: string;
    expires_in: string;
    scope: string;
}