import { IToken } from './IToken';
import Log from '../log/Log';

/**
 * class used to store the token fields obtained during validation and validate the token against values from adobeIdData
 */
export class TokenFields {

       private REAUTH_SCOPE = 'reauthenticated';
       valid?= false;

       isReauth = (): boolean => this.token.scope.indexOf( this.REAUTH_SCOPE ) >= 0;

       expires_at?: Date;

       token: IToken = {
              created_at: '0',
              client_id: '',
              scope: '',
              expires_in: '0',
              user_id: ''
       };

       tokenValue = '';

       other?: any;

       /**
        * 
        * @param tokenProps {object} represents the server answer for a validation token request
        */
       constructor ( tokenProps: any ) {

              const { valid, tokenValue, other } = tokenProps;

              const parsedToken: any = this.parseJwt( tokenValue );
              if ( !parsedToken ) {
                     throw new Error( `token cannot be decoded ${ tokenValue }` );
              }

              const { client_id, user_id, scope: tokenScope, created_at, expires_in } = parsedToken;
              this.token = {
                     client_id, user_id, scope: tokenScope, created_at, expires_in
              };

              this.valid = valid;
              this.expires_at = new Date( parseFloat( created_at ) + parseFloat( expires_in ) * 1000 );

              this.tokenValue = tokenValue;
              this.other = other;

       }

       /**
        * parse the token value
        */
       private parseJwt ( token: string ): object | null {
              try {
                     return JSON.parse( atob( token.split( '.' )[ 1 ] ) );
              } catch ( ex ) {
                     Log.error( 'error on decoding token ', token, ex );
                     return null;
              }
       }

       /**
        * 
        * @param adobeClientId client id provided on adobe id
        * @param adobeIdScope scope value provided in adobe id
        * @returns {boolean} true if token is valid otherwise false
        */
       validate ( adobeClientId: string, adobeIdScope: string ): boolean {
              const { valid, expires_at, token } = this;
              const { client_id, scope } = token;

              // check if is expired
              if ( !expires_at || expires_at < new Date() ) {
                     Log.error( 'token invalid  --> expires_at', expires_at );
                     return false;
              }

              if ( valid != undefined && !valid ) {
                     Log.error( 'token invalid  --> valid' );
                     return false;
              }

              if ( client_id !== adobeClientId ) {
                     Log.error( 'token invalid  --> client id', client_id, adobeClientId );
                     return false;
              }

              if ( !this.isReauth() ) {
                     if ( scope !== adobeIdScope ) {
                            Log.error( 'token invalid  --> scope', ' token scope =', scope, 'vs adobeIdScope =', adobeIdScope, '.' );
                            return false;
                     }
              } else {
                     const scopeToValidate = scope.split(',').filter(el => el !== this.REAUTH_SCOPE ).join(',');
                     if ( scopeToValidate !== adobeIdScope ) {
                            Log.error( 'reauth token invalid  --> scope', ' token scope =', scopeToValidate, 'vs adobeIdScope =', adobeIdScope, '.' );
                            return false;
                     }
              }

              return true;
       }
}