
/**
 * class used to trigger no token message
 */
export class NoTokenException {
}