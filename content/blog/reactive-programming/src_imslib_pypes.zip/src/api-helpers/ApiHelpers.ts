import { IDictionary } from './../facade/IDictionary';
import get from 'lodash/get';
import set from 'lodash/set';

/**
 * class used to store the helper functions
 */
class ApiHelpers {

    /**
   * Checks [adobeid.api_parameters]{@link adobeid} for custom parameters for an API.
   * @param apiName - represents the used api name
   * @param apiParameters - represents the parameters set from outside for api endpoints read from adobeId
   * @returns {!Object}
   */

  getCustomApiParameters = (apiParameters: any, apiName: string ): IDictionary => {
    return Object.keys( apiParameters ).reduce( ( acumulator, key ) => {
      if ( key.indexOf( apiName ) > -1 ) {
        set( acumulator, key, get( apiParameters, key, null ) );
      }
      return acumulator;
    }, {} )
  };

  /**
   * 
   * @param externalParameters external parameters received outside of the library
   * @param apiParameters the api parameters from AdobeId data
   * @param apiName api name
   * @returns IDictionary representing the merged properties
   */
  mergeExternalParameters ( externalParameters: IDictionary, apiParameters: any, apiName: string ): IDictionary {
    return {
      ...this.getCustomApiParameters( apiParameters, apiName ),
      ...externalParameters,
    };
    
  }

}

export default new ApiHelpers();
