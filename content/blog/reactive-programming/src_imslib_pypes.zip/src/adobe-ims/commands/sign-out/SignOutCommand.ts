import { RedirectHelper } from './../../helpers/RedirectHelper';

import UrlHelper from '../../../url/UrlHelper';
import Build from '../../../config/Build';
import { IRedirectSignoutRequest } from '../../facade/IRedirectSignoutRequest';

/**
 * command responsable for user sign out
 */
class SignOutCommand {
  /**
   * @param {IRedirectRequest} redirectRequest. contains all the necessary properties necessary for sign out
   */
  execute = ( redirectRequest: IRedirectSignoutRequest ): void => {

    const apiName = 'logout';

    // eslint-disable-next-line @typescript-eslint/camelcase
    const { access_token, apiParameters, externalParameters, adobeIdRedirectUri = '', clientId } = redirectRequest;

    const apiExternalParams = RedirectHelper.mergeApiParamsWithExternalParams( apiParameters, externalParameters, apiName );
    const redirectUrl = RedirectHelper.createDefaultRedirectUrl( adobeIdRedirectUri, clientId, apiExternalParams, apiName );

    const parameters =
    {
      ...apiExternalParams,
      client_id: clientId,
      redirect_uri: redirectUrl,
      access_token,
    };

    const queryStrings = UrlHelper.uriEncodeData( parameters );

    const url = `${ Build.baseUrlAdobe }/ims/logout/v1?${ queryStrings }`;

    UrlHelper.replaceUrl( url );
  };

}

export default new SignOutCommand();
