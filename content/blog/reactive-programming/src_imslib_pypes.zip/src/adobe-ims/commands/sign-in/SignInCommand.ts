import { RedirectHelper } from './../../helpers/RedirectHelper';
import UrlHelper from '../../../url/UrlHelper';
import { IRedirectRequest } from '../../facade/IRedirectRequest';
import Build from '../../../config/Build';
import get from 'lodash/get';
import { IDictionary } from '../../../facade/IDictionary';

/**
 * command responsable for user sign in
 */

class SignInCommand {

  /**
   * @param {IRedirectRequest} redirectRequest. contains all the adobeId necessary properties necessary for sign in
   * @param {String} nonce represents the nonce value used for csrf
   */
  execute = ( redirectRequest: IRedirectRequest, nonce: string ): void => {

    const apiName = 'authorize';

    const { apiParameters, externalParameters, adobeIdRedirectUri = '', clientId } = redirectRequest;

    const { scope = get( externalParameters, 'scope', get( apiParameters, 'scope', '' ) ) as string } = redirectRequest;

    const redirectUrl = RedirectHelper.createRedirectUrl( adobeIdRedirectUri, clientId, externalParameters, apiName, scope, nonce );

    const apiExternalParams = RedirectHelper.mergeApiParamsWithExternalParams( apiParameters, externalParameters, apiName );

    const { jslibver = get( apiExternalParams, 'jslibver', '' ) as string } = redirectRequest;
    const { locale = get( apiExternalParams, 'locale', '' ) as string } = redirectRequest;
    // eslint-disable-next-line @typescript-eslint/camelcase
    const { response_type = get( apiExternalParams, 'response_type', '' ) as string } = redirectRequest;

    const parameters: IDictionary =
    {
      ...apiExternalParams,
      client_id: clientId,
      redirect_uri: redirectUrl,
      scope,
      jslibver,
      locale,
      response_type
    };

    const queryStrings = UrlHelper.uriEncodeData( parameters );

    const url = `${ Build.baseUrlAdobe }/ims/authorize/v1?${ queryStrings }`;

    UrlHelper.replaceUrl( url );
  };

}

export default new SignInCommand();
