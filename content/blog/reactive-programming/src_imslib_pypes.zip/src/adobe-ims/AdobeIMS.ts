import { CsrfService } from './csrf/CsrfService';
import axios, { AxiosInstance } from 'axios';
import HttpErrorResponse from '../error-handlers/HttpErrorResponse';
import Log from '../log/Log';
import SignInCommand from './commands/sign-in/SignInCommand';
import SignOutCommand from './commands/sign-out/SignOutCommand';
import { AdobeIdData } from './../adobe-id/AdobeIdData';
import { IAdobeIdData } from "../adobe-id/IAdobeIdData";
import { IDictionary } from './../facade/IDictionary';
import { IHttpErrorResponse } from '../error-handlers/IHttpErrorResponse';
import { ImsApis } from './../ims-apis/ImsApis';
import { IReauth } from './facade/IReauth';
import { IRefreshTokenResponse } from '../token/IRefreshTokenResponse';
import { IServiceRequest } from './facade/IServiceRequest';
import { NoTokenException } from '../token/NoTokenException';
import { ProfileException } from '../profile/ProfileException';
import { ProfileService } from '../profile/ProfileService';
import { TokenFields } from './../token/TokenFields';
import { TokenService } from '../token/TokenService';
import UrlHelper from '../url/UrlHelper';
import { IRedirectSignoutRequest } from './facade/IRedirectSignoutRequest';
import FragmentHelper from '../url/FragmentHelper';
import { FragmentException } from '../token/FragmentException';
import { IErrorType } from '../adobe-id/IErrorType';
import { IAdobeHandlers } from '../adobe-id/IAdobeHandlers';
import { PipeException } from './PipeException';

/**
 * Class used as a facade for ims library in order to provide public access to library functionalities
 * 
 */
export class AdobeIMS {

  /**
   * AdobeIdData
   * the values for adobeId are read from window.adobeid or passed by using the constructor
  */
  private adobeIdData: AdobeIdData;

  /**
   * Instance of axios used for this instance of AdobeIms
  */
  private axiosInstance: AxiosInstance;

  /**
   * Token Service instance used for token management
   */
  private tokenService: TokenService;

  /**
   * Profile service instance used for profile management
   */
  private profileService: ProfileService;

  /**
   * Service Request object used for token and profile services. 
   * contains the clientId, scope and imsApis instance
   */
  private serviceRequest: IServiceRequest;

  /**
   * instance of CsrfService
   */
  private csrfService: CsrfService;

  /**
   * Represents the class used to call the back-end methods;
   * it is visible ONLY because this is the only way t mock the api calls during functional tests
  */
  imsApis: ImsApis;

  /**
   * @constructor adobeData {AdobeIdData} 
   * If adobeData is not null, the adobeIdData instance will be created based on these values
   * 
   * if no adobeData, the imsLibrary try to read these values from window.adobeid
   * 
   * After this AdobeIms class is created, it can be accessed by window[{adobeData.clientId}]
  */
  constructor ( adobeData: IAdobeIdData | null = null ) {
    this.adobeIdData = new AdobeIdData( adobeData );
    const { api_parameters: apiParameters = {}, client_id: clientId, scope } = this.adobeIdData;

    this.axiosInstance = axios.create( {} );
    this.imsApis = new ImsApis( this.axiosInstance, apiParameters );

    this.csrfService = new CsrfService( clientId );

    this.serviceRequest = {
      clientId,
      scope,
      imsApis: this.imsApis
    };

    this.tokenService = new TokenService( this.serviceRequest, this.csrfService );
    this.profileService = new ProfileService( this.serviceRequest );

    this.axiosInstance.interceptors.response.use( ( response ) => {
      return response;
    }, ( error ) => {
      const err: IHttpErrorResponse | null = HttpErrorResponse.verify( error );
      if ( err ) {
        return Promise.reject( err );
      }
      return Promise.reject( error );
    } );

  }

  /**
   * Method used to redirect the user to signin url
   *
   * <uml>
   * start
   * :SignIn;
   * :Create the redirect url;
   * :user must enter the credentials and after that is redirected to initial uri;
   * :initialize method is used which will trigger the token and profile; 
   * end
   * </uml>
   * @param externalParameters {Object} object sent from outside in order to have the possibility to override the default values when the redirect uri is created
   *  
  */
  signIn = ( externalParameters: IDictionary = {} ): void => {
    const { adobeIdData, csrfService } = this;

    const authorizeRequestData = adobeIdData.createRedirectRequest( externalParameters );
    const nonce = csrfService.initialize();

    SignInCommand.execute( authorizeRequestData, nonce );
  };

  /**
   * Method used to reAuthenticate the user
   * 
   * <uml>
   * start
   * :SignIn;
   * :Create the redirect url;
   * :user must enter the credentials and after that is redirected to initial uri;
   * :initialize method is used which will trigger the token and profile; 
   * end
   * 
   * </uml>
   * 
   * @param requestedParameters object sent from outside in order to use diferent values for reAuthenticate
   * 
  */
  reAuthenticate = ( requestedParameters: IDictionary = {}, reauth = IReauth.check ): void => {
    const { adobeIdData, csrfService } = this;

    const params = {
      reauth
    };

    const reauthParms = {
      ...requestedParameters,
      ...params,
    };

    const redirectRequest = adobeIdData.createRedirectRequest( reauthParms );
    const nonce = csrfService.initialize();

    SignInCommand.execute( redirectRequest, nonce );

  };

  /**
   * @function Method used to check if the user is signed in or not. 
   * if local storage contains a token and is validated (only against expiration), the result is true
   * returns {boolean}
  */
  isSignedInUser (): boolean {
    return this.getAccessToken() ? true : false;
  }

  /**
   * @function Method used to read the existent profile in case the user is logged.
   * returns {IDictionary | null}  representing the user profile or null
  */
  getProfile (): IDictionary | null {
    return this.profileService.getProfileFromStorage();
  }

  /**
   *  Method used for sign out the user
   *
   * <uml>
   * start
   * :Signout;
   * :Create the redirect url;
   * :remove the token and profile from storage;
   * :initialize method is used which will redirect the app to initial url; 
   * end
   * </uml>
   * 
   * @param externalParameters {Object} object sent from outside in order to have the possibility to override the default values when the redirect uri is created
   * 
  */
  signOut = ( externalParameters: IDictionary = {} ): void => {

    const token = this.getAccessToken() || '';

    this.tokenService.purge();
    this.profileService.removeProfile();

    const { api_parameters: apiParameters = {}, client_id: clientId, redirect_uri: adobeIdRedirectUri } = this.adobeIdData;

    const redirectRequest: IRedirectSignoutRequest = {
      adobeIdRedirectUri,
      apiParameters,
      clientId,
      externalParameters,
      access_token: token,
    };

    SignOutCommand.execute( redirectRequest );
  };

  /**
   * @function Returns the URL of the user avatar
   * @param {UserId} userId
  */
  avatarUrl ( userId: string ): string {
    return this.imsApis.avatarUrl( userId );
  }

  /**
    * 
    * Returns the access token value from the local storage
    * 
    * <uml>
    * start
    * :getAccessToken;
    * :check the local storage;
    * :if token exists, it is validated agains expiration;
    * :if valid the token is returned otherwise an empty token; 
    * end
    * </uml>
    * 
  */
  getAccessToken (): string | null {
    return this.tokenService.getTokenFromStorage();
  }

  /**
   * 
   * Returns the reauth access token value from the local storage
   * 
   * <uml>
   * start
   * :getReauthAccesToken;
   * :check the local storage;
   * :if token exists, it is validated agains expiration;
   * :if valid the token is returned otherwise an empty token; 
   * end
   * </uml>
   * 
 */
  getReauthAccesToken (): string | null {
    return this.tokenService.getReauthTokenFromStorage();
  }

  /**
   * Refresh the existing token
   * 
   * <uml>
   * start
   * :refreshToken;
   * :call backend: ims/check/v4/token?client_id;
   * :read the token and profile;
   * :triggerOnAccessToken; 
   * if (profile) then (yes)
   * :triggerOnProfileReceived(profile);
   * else (nothing)
   * :call backend to get the profile ;
   * endif
   * end
   * </uml>
   * 
   * @param externalParameters {Object} external parameters sent from outside of the library
   * Note: if refresh token API fails, the triggerOnAccessTokenHasExpired will be triggered
  */
  refreshToken ( externalParameters: IDictionary = {} ): Promise<any> {

    const { handlers } = this.adobeIdData;

    return new Promise( ( resolve, reject ) => {

      this.tokenService.refreshToken( externalParameters )
        .then( ( tokenResponse: IRefreshTokenResponse ) => {
          const { access_token: token, profile } = tokenResponse;
          Log.info( 'token', token );
          handlers.triggerOnAccessToken( token );

          if ( profile ) {
            this.profileService.profileReceived( profile );
            return Promise.resolve( profile );
          }
          return this.profileService.getProfile( token );
        } )
        .then( ( profile: any ) => {
          if ( !profile ) {
            Log.warn( 'refresh token --> profile', profile );
            throw new ProfileException( 'refresh token --> profile --> no data' );
          }

          Log.info( 'refresh token --> profile', profile );

          this.onProfileReceived( profile );

          return resolve( 'refresh token success' );
        } )
        .catch( ex => {
          if ( ex instanceof ProfileException ) {
            Log.warn( 'profile warning', ex );
            handlers.triggerOnError( IErrorType.PROFILE_EXCEPTION, ex.message )
            return reject( ex );
          }

          Log.error( 'refresh token error', ex );

          this.onTokenExpired();

          this.removeProfile();

          reject( ex );
        } )
    } );

  }

  /**
   * method used to process the new user profile
   */
  onProfileReceived ( profile: any ): void {
    // const { adobeIdData } = this;
    // if ( !adobeIdData ) {
    //   throw new Error( 'Please provide the adobe Id data' );
    // }
    const { handlers } = this.adobeIdData;

    this.profileService.profileReceived( profile );
    handlers.triggerOnProfileReceived( profile );
  }

  /**
   * method used in case the existent token has expired
   */
  onTokenExpired (): void {
    // const { adobeIdData } = this;
    // if ( !adobeIdData ) {
    //   throw new Error( 'Please provide the adobe Id data' );
    // }
    const { handlers } = this.adobeIdData;

    this.tokenService.purge();
    handlers.triggerOnAccessTokenHasExpired();
  }

  /**
   * method used to remove the existent profile
   */
  removeProfile (): void {
    const { handlers } = this.adobeIdData;

    this.profileService.removeProfile();
    handlers.triggerOnProfileReceived( null );
  }
  /**
   * Method called on library initialization or page reloading
   * <uml>
   * start
   * :initialize method;
   * :get token; 
   * if (fragment) then (yes)
   * :returns the token from fragment;
   * else (check local storage)
   * :returns the token from local storage;
   * endif
   * :if no token: return triggerOnAccessTokenHasExpired; 
   * :triggerOnAccessToken;
   * :back-end: calls getProfile ;
   * :triggerOnProfileReceived ;
   * :triggerOnReady ;
   * end
   * </uml>
   * 
   * Note: this method is automatically called on every page reload; 
  */
  initialize (): void {//
    const { handlers } = this.adobeIdData;

    const initializeFlow = [
      {
        func: this.tokenService.getToken,
        onError: {
          func: {
            func: ( val ) => this.processInitializeException( val ),
            onError: ( ex ) => { debugger; Log.info( 'processInitializeException ended with exception', ex ); throw new Error( 'this goes to onError from id 12' ) },
            id: 123
          },
          onError: ( val ) => { debugger; console.log( val ); throw new PipeException( val ); },
          id: 12,
        },
        id: 1,
      },
      {
        func: ( val ) => {
          debugger;
          console.log( ' on 2 func', val );
          return this.decorateMethodWithPipeException( this.processGetTokenResponse, val )
        },
        id: 2,
      },
      {
        func: ( profile ) => {
          debugger;
          return this.decorateMethodWithPipeException( handlers.triggerOnProfileReceived, profile )
        },
        id: 3,
      }
    ];

    this.pipeAsyncFunctions( initializeFlow )( 2 )
      .catch( ex => {
        console.log( 'initialize exception ', ex );
      } )
      .finally( ( response ) => {
        Log.info( 'onReady initialization ', response );
        handlers.triggerOnReady();
      } );

    return;

    this.tokenService.getToken()
      .then( ( tokenFields: TokenFields ) => {
        return this.processGetTokenResponse( tokenFields );
      } )
      .then( profile => {
        handlers.triggerOnProfileReceived( profile );
      } )
      .catch( ex => {
        return this.processInitializeException( ex );
      } )
      .then( ( promiseValue ) => {
        Log.info( 'processInitializeException ended', promiseValue );
      } )
      .catch( ex => {
        Log.info( 'processInitializeException ended with exception', ex );
      } )
      .finally( () => {
        Log.info( 'onReady initialization' );
        handlers.triggerOnReady();
      } );
  }

  private pipeAsyncFunctions = ( fns ) => initialInput => {
    return fns.reduce( ( acc, el ) => {
      return acc
        .then( ( result ) => {
          debugger;
          if ( result instanceof PipeException ) {
            return Promise.reject( result );
          }
          const next = el[ 'func' ] ? el[ 'func' ] : el;
          return this.composePromise( next, result )
        } )
        .catch( ( exception ) => {
          debugger;
          if ( exception instanceof PipeException ) {
            return Promise.reject( exception );
          }

          const next = el[ 'onError' ] ? el[ 'onError' ] : el;
          if ( !el ) {
            return Promise.reject( exception );
          }
          return this.composePromise( next, exception );
        } )
    }, Promise.resolve( initialInput ) );
  }

  decorateMethodWithPipeException = ( method, val ) => {
    if ( val instanceof PipeException ) {
      return Promise.reject( val );
    }
    return method( val );
  }


  processGetTokenResponse  = ( tokenFields: TokenFields ) => {

    const { handlers } = this.adobeIdData;

    const { tokenValue: token, other = {} } = tokenFields;

    if ( tokenFields.isReauth() ) {
      handlers.triggerOnReauthAccessToken( token );
    } else {
      handlers.triggerOnAccessToken( token );
    }

    Log.info( 'token', token );

    UrlHelper.setHash( other.old_hash || '' );

    return this.profileService.getProfile( token );
  }

  /**
   * process the initialize exception
   * @param ex represent the exception received during the initialize
   */
  processInitializeException = ( ex: any ): Promise<any> => {
    const { handlers } = this.adobeIdData;

    if ( !ex ) {
      return Promise.reject( new Error( 'null exception received on initialize' ) );
    }

    return new Promise( ( resolve, reject ) => {
      if ( ex instanceof FragmentException ) {
        const errorType = ex.type as IErrorType;
        handlers.triggerOnError( errorType, ex.message );

        this.restoreHash();

        if ( errorType === IErrorType.CSRF ) {
          this.signOut();
        }

        return reject( ex );
      }

      this.restoreHash();

      Log.error( 'initialize', ex );

      if ( ex instanceof ProfileException ) {
        handlers.triggerOnError( IErrorType.PROFILE_EXCEPTION, ex.message );

        return reject( ex );
      }

      if ( ex instanceof NoTokenException ) {
        return resolve( this.refreshToken() );
      }

      reject( ex );
    } )
  }

  /**
   * restore the window hash value to the initial one
   */
  private restoreHash (): void {
    const fragmentValues = FragmentHelper.fragmentToObject();
    if ( fragmentValues ) {
      UrlHelper.setHash( fragmentValues.old_hash as string || '' );
    }
  }


  private isFunction = ( el ) => typeof el === "function";

  private composePromise = ( propValue, value ): Promise<void> => {
    if ( this.isFunction( propValue ) ) {
      return Promise.resolve( propValue( value ) );
    }

    const { func, onError } = propValue;
    if ( !func && !onError ) {
      return Promise.resolve( value );
    }

    if ( !func ) {
      return this.composePromise( onError, value );
    }

    if ( !onError ) {
      return this.composePromise( func, value );
    }

    return Promise.resolve( this.composePromise( func, value ).catch( ( cEx ) => this.composePromise( onError, cEx ) ) )
  }


}
