
/**
 * class used to trigger the initialize errors and are used on pipes
 */
export class PipeException {
    exception = null;
    constructor(exception) {
        this.exception = exception;
    }
}