
/**
 * Enumeration values used for ims actions
 */
export enum ImsActions {

    NONE = '',
    /**
     * http exception type
     */
    SIGN_OUT = 'signout',

    /**
     * fragment exception type
     */
    REFRESH_TOKEN = 'refreshToken',

    
}