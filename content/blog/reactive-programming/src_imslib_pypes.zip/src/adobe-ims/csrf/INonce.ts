
/**
 * interface used to store the nonce key value pair
 */
export interface INonce {
    value: string;
    expiry: string;
}