import get from 'lodash/get';
import { IDictionary } from "../../facade/IDictionary";
import ApiHelpers from "../../api-helpers/ApiHelpers";

export class RedirectHelper {
    /**
        * returns the initial redirect url; the priority value is redirect_uri from external parameters, adobeId and finally the href value from browsers  
        * @param externalParameters 
        * @param adobeIdRedirectUri 
        */
    static getInitialRedirectUri ( externalParameters: IDictionary, adobeIdRedirectUri: string | undefined ): string {
        const redirectValue = get( externalParameters, 'redirect_uri', '' ) as string;
        return redirectValue 
            ? redirectValue 
            : ( adobeIdRedirectUri || window.location.href.split('#')[0]);
    }

     /**
     * create the return url which it will be passed to logout endpoint
     * @param redirectUri {string} - represents the base url href value
     * @param clientId {string} - represents the client id
     * @param externalParameters {Object} external parameters passed to library
     * @param apiName {string} api name
     * @returns {string} final redirect url used for sign in
     */
    static createDefaultRedirectUrl ( adobeIdRedirectUri: string, clientId: string, apiExternalParams: IDictionary, apiName: string): string {

        const initialRedirectUri = this.getInitialRedirectUri( apiExternalParams, adobeIdRedirectUri );
        //encode the hash in case that exists
        let redirectUri = this.encodeHash( initialRedirectUri );

        //append scope property from external parameters
        redirectUri = `${ redirectUri }&client_id=${ clientId }&api=${ apiName }`;

        const encodedProps = Object.keys( apiExternalParams ).length ? encodeURIComponent( JSON.stringify( apiExternalParams ) ) : null;
        if ( encodedProps ) {
            redirectUri = `${ redirectUri }&rctx=${ encodedProps }`;
        }

        return redirectUri;
    }

    /**
     * create the return url which it will be passed to authorization endpoint
     * @param redirectUri {string} - represents the base url href value
     * @param clientId {string} - represents the client id
     * @param externalParameters {Object} external parameters passed to library
     * @param apiName {string} api name
     * @parm scope {string} scope of sign in
     * @parm nonce {string} nonce used during csrf 
     * @returns {string} final redirect url used for sign in
     */
    static createRedirectUrl ( adobeIdRedirectUri: string, clientId: string, apiExternalParams: IDictionary, apiName: string, scope = '', nonce = '' ): string {

        let redirectUri = this.createDefaultRedirectUrl(adobeIdRedirectUri, clientId, apiExternalParams, apiName);

        scope = scope || get(apiExternalParams, 'scope', '') as string;

        if ( scope ) {
            redirectUri = `${ redirectUri }&scope=${ encodeURIComponent( scope ) }`;
        }

        const reauth = get(apiExternalParams, 'reauth', '') as string;
        if ( reauth ) {
            redirectUri = `${ redirectUri }&reauth=${ encodeURIComponent( reauth ) }`;
        }

        if ( nonce ) {
            redirectUri = `${ redirectUri }&nonce=${ encodeURIComponent( nonce ) }`;
        }

        return redirectUri;
    }

    /**
     * @param source {string} represent the url value with hash which will be encoded
     * @returns {string} the same url but the hash is encoded
     */
    static encodeHash ( source: string ): string {
        const index = source.indexOf( "#" );
        if ( index < 0 ) {
            return `${ source }#from_ims=true`;
        }
        const baseUrl = source.substring( 0, index );
        const hash = source.substring( index + 1 );

        return `${ baseUrl }#from_ims=true&old_hash=${ encodeURIComponent( hash ) }`;
    }

    static mergeApiParamsWithExternalParams ( apiParameters: IDictionary, externalParameters: IDictionary, apiName: string ): IDictionary {
        return {
            ...ApiHelpers.getCustomApiParameters( apiParameters, apiName ),
            ...externalParameters,
        };
    }

}
