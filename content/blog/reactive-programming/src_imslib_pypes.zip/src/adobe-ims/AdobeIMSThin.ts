import SignInCommand from './commands/sign-in/SignInCommand';
import SignOutCommand from './commands/sign-out/SignOutCommand';
import { AdobeIdData } from '../adobe-id/AdobeIdData';
import { IAdobeIdData } from "../adobe-id/IAdobeIdData";
import { IDictionary } from '../facade/IDictionary';
import { IRedirectSignoutRequest } from './facade/IRedirectSignoutRequest';
import FragmentHelper from '../url/FragmentHelper';
import get from 'lodash/get';

/**
 * Class used as a facade for ims library in order to provide public access only to a part of the main library functionalities
 * 
 */
export class AdobeIMSThin {

  /**
   * AdobeIdData
   * the values for adobeId are read from window.adobeid or passed by using the constructor
   */
  private adobeIdData: AdobeIdData | null = null;

  /**
   * 
   * @param adobeData {IAdobeData} if not null, the adobeIdData instance will be created based on this values
   */
  constructor ( adobeData: IAdobeIdData | null = null ) {
    this.adobeIdData = new AdobeIdData( adobeData );
  }

  /**
 * Method used to redirect the user to signin url
 *
 * <uml>
 * start
 * :SignIn;
 * :Create the redirect url;
 * :user must enter the credentials and after that is redirected to initial uri;
 * :developer should use the fragmentValues method and implement the token mangement; 
 * end
 * </uml>
 * @param externalParameters {Object} object sent from outside in order to have the possibility to override the default values when the redirect uri is created
 * @param nonce {string} string value used for csrf
 * 
*/
  signIn = ( externalParameters: IDictionary = {}, nonce = '' ): void => {
    const { adobeIdData } = this;
    if ( !adobeIdData ) {
      throw new Error( 'no adobeId on sign in' );
    }

    const authorizeRequestData = adobeIdData.createRedirectRequest( externalParameters );

    SignInCommand.execute( authorizeRequestData, nonce );
  };

  /**
   * token {string} represents the token used for sign out
   * externalParameters {object} - external parameters passed to sign out
   * 
   * <uml>
   * start
   * :Signout;
   * :Create the redirect url;
   * :remove the token and profile from storage;
   * :developer should implement his scenario after signout 
   * end
   * </uml>
   */
  signOut = ( token: string, externalParameters: IDictionary = {} ): void => {
    const adobeIdData = this.adobeIdData;
    if ( !adobeIdData ) {
      throw new Error( 'no adobeId on sign out' );
    }

    const { api_parameters: apiParameters = {}, client_id: clientId, redirect_uri: adobeIdRedirectUri } = adobeIdData;

    const redirectRequest: IRedirectSignoutRequest = {
      adobeIdRedirectUri,
      apiParameters,
      clientId,
      externalParameters,
      access_token: token,
    };

    SignOutCommand.execute( redirectRequest );
  };

  /**
   * method used to notify that the library has been initialized
   */
  initialize(): void {
    const { adobeIdData } = this;
    if ( !adobeIdData ) {
      throw new Error( 'Please provide the adobe Id data' );
    }
    adobeIdData.handlers.triggerOnReady();
  }
  /**
   * Helper function used to transform fragment values into a json object
   */
  fragmentValues (): IDictionary | null {
    return FragmentHelper.fragmentToObject();
  }

  /**
   * Helper function used to return the nonce value from fragment
   */
  getNonce (): string | null {
    const fragment: IDictionary | null = this.fragmentValues();
    if ( !fragment ) {
      return null;
    }
    return get( fragment.redirectParams, 'nonce', null );
  }

}
