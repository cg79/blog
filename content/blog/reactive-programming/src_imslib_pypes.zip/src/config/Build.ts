
declare let __version: string;
declare let __log_enabled: boolean;
declare let __baseUrlAdobe: string;
declare let __baseUrlServices: string;

/**
 * Class used to keep the configuration values when the library is built
 * 
 * rollup (library used for transpiling) is injecting these values by reading the values from config/{ENV}.js file
 * 
 * Basically, this class contains the configuration values and these values are filled on the time of transpiling
 */
class Build {

  /**
   * @property {string} Represents the jslibver; 
   * 
   * this parameter is passed to redirect uri during a sign in or sign out operation
   */
  version = '';

  /**
   * @property Loging mechanism is not enabled by default;
   * The log mechanism (if enabled) write the information to the console.
   */
  logEnabled = false;

  /**
   * @property {boolean} Represents the base url used on api (back-end) call in case of getProfile, getUserInfo and validateToken; 
   * 
   * The value of this url depends by environment and the value is: https://ims-na1-{ENV}.adobelogin.com
   * 
   * Currently the available environments are: stg1, qa2 and prod
   */
  baseUrlAdobe = '';
  
  /**
   * @property {string} Represents the base url used on api (back-end) call in case of logoutToken, checkStatus checkToken,listSocialProviders and exchangeIjt; 
   * 
   * The value of this url depends by environment and the value is: https://adobeid-na1-{ENV}.services.adobe.com
   * 
   * Currently the available environments are: stg1, qa2 and prod
   */
  baseUrlServices = '';

  /**
   * @constructor here is the place where rollup is injecting the configuration values
   * used to set the Build values read from external configuration file during the build process.
   * This is made automatically by rollup at the moment when the bundle is created for a specific environment.
   * The injected values are read from ./config/${ENV} file 
   */
  constructor () {
    try {
      this.version = __version || '';

      this.logEnabled = __log_enabled || false;
      this.baseUrlAdobe = __baseUrlAdobe;
      this.baseUrlServices = __baseUrlServices;
    }
    catch ( ex ) {
      // eslint-disable-next-line no-console
      console.error( 'error creating the Build object ', ex );
    }
  }
  
}

export default new Build();
