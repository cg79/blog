

export { AdobeIMS as AdobeIMSPolyfill } from './adobe-ims/AdobeIMSPolyfill';
