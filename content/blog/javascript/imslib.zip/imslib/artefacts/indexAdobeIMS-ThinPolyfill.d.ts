
export { AdobeIMSThin as AdobeIMSThinPolyfill } from './adobe-ims/AdobeIMSThinPolyfill';
