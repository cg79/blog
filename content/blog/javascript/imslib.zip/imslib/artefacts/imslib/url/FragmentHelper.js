"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
/**
 * class used to implement the main functions used for fragment
 */
var FragmentHelper = /** @class */ (function () {
    function FragmentHelper() {
    }
    FragmentHelper.prototype.fragmentToObject = function () {
        var currentHash = this.getHashFromURL();
        if (!currentHash) {
            return null;
        }
        var url = this.processHashUrl(currentHash);
        var oldHash = this.getOldHash(url);
        // fragment values should contain only values starting with old_hash
        //this is in case when hash route is used: e.g.: https://localhost.corp.adobe.com:9000/#/cdn#old_hash=...
        //#/cdn# should be ignored when getQueryParamsAsMap is called;
        var urlWithoutRoute = oldHash ? url.slice(url.indexOf('old_hash')) : url;
        var urlWithoutOldHash = this.removeOldHash(urlWithoutRoute);
        var imsResponseAsMap = this.getQueryParamsAsMap(urlWithoutOldHash);
        if (oldHash) {
            imsResponseAsMap['old_hash'] = oldHash;
        }
        return imsResponseAsMap;
    };
    /**
     * function used to determine the old_hash value contained into the source
     * @param source {String} represents the input source used to determine the old_hash
     * @returns {String}
     */
    FragmentHelper.prototype.getOldHash = function (source) {
        if (!source) {
            return '';
        }
        var match = source.match('old_hash=(.*?)&from_ims=true');
        if (!match) {
            return '';
        }
        return match[1];
    };
    /**
     * remove the old hash value from the input string
     * @param source {String} represents the input source
     */
    FragmentHelper.prototype.removeOldHash = function (source) {
        if (!source) {
            return source;
        }
        return source.replace(/old_hash=(.*?)&from_ims=true/gi, 'from_ims=true');
    };
    /**
   * Gets the hash from an url.
   * @param {string=} url The URL from which to get the hash.
   *                      If missing use the current page's URL.
   * @Note: the # is not returned from url
   * @returns {string}
   */
    FragmentHelper.prototype.getHashFromURL = function (url) {
        if (url === void 0) { url = window.location.href; }
        var index = url.indexOf("#");
        return index !== -1 ? url.substring(index + 1) : "";
    };
    /**
   * Parses a query string to a JSON.
   * @NOTE Sometimes, the query string is actually a hash, due to inconsistent servers
   * @param source {String}; represents the inpt strring value wich will be transformed to object
   * @returns {!Object}
   */
    FragmentHelper.prototype.getQueryParamsAsMap = function (source) {
        if (!source) {
            return {};
        }
        var paramMap = {};
        //in case the source starts with #, ? or &, the first character is removed. 
        source = source.replace(/^(#\/|\/|#|\?|&)/, "");
        source.split("&").forEach(function (keyValuePair) {
            if (keyValuePair.length) {
                var arr = keyValuePair.split("=");
                paramMap[arr[0]] = decodeURIComponent(arr[1]);
            }
        });
        return paramMap;
    };
    /**
   * @param source {string} represent the input source wich will be processed
   * The backend appends a second "#" sign to redirect_uri, even if it already contains one.
   * @see https://jira.corp.adobe.com/browse/IMSB-4107554
   */
    FragmentHelper.prototype.processHashUrl = function (source) {
        return decodeURIComponent(source)
            .replace("?error", "#error")
            .replace(/#/gi, '&')
            .replace('from_ims=true?', 'from_ims=true&');
    };
    return FragmentHelper;
}());
exports.default = new FragmentHelper();
