"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
/**
 * class used to implement the main functions used for query strings
 */
var UrlHelper = /** @class */ (function () {
    function UrlHelper() {
    }
    /**
   * Encodes data as a query string.
   * @param {Object} data - The data.
   * @returns {string} - The encoded string.
    * @example
    * encoded = uriEncodeData({
    *   first: true,
    *   foo: {
    *     bar: 'foobar'
    *   }
    * }) // -> first=true&foo=%7B%22bar%22%3A%22foobar%22%7D
    */
    UrlHelper.prototype.uriEncodeData = function (data) {
        if (typeof data !== 'object') {
            return '';
        }
        var encodings = [];
        var encodedValue = '';
        var keyValue;
        for (var key in data) {
            keyValue = data[key];
            if (keyValue === undefined) {
                continue;
            }
            encodedValue = this.encodeValue(keyValue);
            encodings.push(encodeURIComponent(key) + "=" + encodedValue);
        }
        return encodings.join("&");
    };
    /**
   * @param value : any; represents the value which will be encoded
   * @returns string.
   */
    UrlHelper.prototype.encodeValue = function (value) {
        if (value === null) {
            return 'null';
        }
        if (typeof value === 'object') {
            return encodeURIComponent(JSON.stringify(value));
        }
        return encodeURIComponent(value);
    };
    /**
   * Opens the URL in the current page
   *
   * @param {!string} url
   */
    UrlHelper.prototype.replaceUrl = function (url) {
        if (!url) {
            return;
        }
        window.location.replace(url);
    };
    /**
  * Change the hash from url to a new value without reloading the page
  * @param hash {String} represents the new hash value
  *
  */
    UrlHelper.prototype.setHash = function (hash) {
        if (hash === void 0) { hash = ''; }
        window.location.hash = hash;
    };
    return UrlHelper;
}());
exports.default = new UrlHelper();
