/**
 * class used to implement the main functions used for query strings
 */
declare class UrlHelper {
    /**
   * Encodes data as a query string.
   * @param {Object} data - The data.
   * @returns {string} - The encoded string.
    * @example
    * encoded = uriEncodeData({
    *   first: true,
    *   foo: {
    *     bar: 'foobar'
    *   }
    * }) // -> first=true&foo=%7B%22bar%22%3A%22foobar%22%7D
    */
    uriEncodeData(data: any): string;
    /**
   * @param value : any; represents the value which will be encoded
   * @returns string.
   */
    private encodeValue;
    /**
   * Opens the URL in the current page
   *
   * @param {!string} url
   */
    replaceUrl(url: string): void;
    /**
  * Change the hash from url to a new value without reloading the page
  * @param hash {String} represents the new hash value
  *
  */
    setHash(hash?: string): void;
}
declare const _default: UrlHelper;
export default _default;
