import { IDictionary } from '../facade/IDictionary';
/**
 * class used to implement the main functions used for fragment
 */
declare class FragmentHelper {
    fragmentToObject(): IDictionary | null;
    /**
     * function used to determine the old_hash value contained into the source
     * @param source {String} represents the input source used to determine the old_hash
     * @returns {String}
     */
    getOldHash(source: string): string;
    /**
     * remove the old hash value from the input string
     * @param source {String} represents the input source
     */
    removeOldHash(source: string): string;
    /**
   * Gets the hash from an url.
   * @param {string=} url The URL from which to get the hash.
   *                      If missing use the current page's URL.
   * @Note: the # is not returned from url
   * @returns {string}
   */
    getHashFromURL(url?: string): string;
    /**
   * Parses a query string to a JSON.
   * @NOTE Sometimes, the query string is actually a hash, due to inconsistent servers
   * @param source {String}; represents the inpt strring value wich will be transformed to object
   * @returns {!Object}
   */
    getQueryParamsAsMap(source: string): IDictionary;
    /**
   * @param source {string} represent the input source wich will be processed
   * The backend appends a second "#" sign to redirect_uri, even if it already contains one.
   * @see https://jira.corp.adobe.com/browse/IMSB-4107554
   */
    private processHashUrl;
}
declare const _default: FragmentHelper;
export default _default;
