import { IPasswordGrantTypeRequest } from './IPasswordGrantTypeRequest';
/**
 * the interface used to send the parameters to /ims/token/v1
 */
export interface IPasswordGrantType extends IPasswordGrantTypeRequest {
    /**
     * represents the client id used for password grant
     */
    client_id: string;
}
