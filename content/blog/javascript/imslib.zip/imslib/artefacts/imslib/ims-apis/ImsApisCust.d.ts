import { IDictionary } from '../facade/IDictionary';
import { IAuthorizedApiRequest } from './IAuthorizedApiRequest';
import { IUnAuthorizedApiRequest } from './IUnAuthorizedApiRequest';
/**
 * class used as a entry point for Ims api's
 * @todo discuss rate limit --> code 429 on http response.
 */
export declare class ImsApisCust {
    private CONTENT_FORM_ENCODED;
    apiParameters: any;
    /**
     * imsApis constructor;
     * sets the axios to use credentials
     */
    constructor(apiParameters?: any);
    /**
     * check if the cache contains data for the same url and parameters value;
     * if true, returns the cached value otherwise make the http call
     * @param url - url used to make a POST http request
     * @param data - dat passed to the back-end
     * @param config - http configuration
     */
    private post;
    /**
     * check if the cache contains data for the input url
     * if true, returns the cached value otherwise make the http call
     * @param url - url used to make a POST http request
     * @param config - axios configuration
     */
    private get;
    /**
     * validate the input token
     * @param request IAuthorizedApiRequest contains clientId and token information
     */
    validateToken(request: IAuthorizedApiRequest): Promise<any>;
    /**
     * retreive the profile based on the input token
     * @param request IAuthorizedApiRequest contains clientId and token information
     */
    getProfile(request: IAuthorizedApiRequest): Promise<any>;
    /**
     * @returns the user info based on the input token
     * @param request IAuthorizedApiRequest contains clientId and token information
     */
    getUserInfo(request: IAuthorizedApiRequest): Promise<any>;
    /**
      * invalidate the input token
      * @param request IAuthorizedApiRequest contains clientId and token information
      */
    logoutToken(apiRequest: IAuthorizedApiRequest): Promise<any>;
    /**
     * Does an API to check the cookie status of the browser.
     */
    checkStatus(): Promise<any>;
    /**
     * @returns a new token
     * @param request IUnAuthorizedApiRequest contains clientId information
     * @param scope string contains the scope used for check token api
     * @todo We will probably need also check token v5
     */
    checkToken(apiRequest: IUnAuthorizedApiRequest, externalParameters: IDictionary, scope: string): Promise<any>;
    /**
     * @returns list of api providers
     * @param request IUnAuthorizedApiRequest contains clientId information
     */
    listSocialProviders(apiRequest: IUnAuthorizedApiRequest): Promise<any>;
    /**
    * @see {@link https://wiki.corp.adobe.com/display/ims/Implicit+Jump+Tokens |Implicit Jump Tokens}
    * @param request IUnAuthorizedApiRequest contains clientId and token information
    * @param ijt {string}
    */
    exchangeIjt(apiRequest: IUnAuthorizedApiRequest, ijt: string): Promise<any>;
    /**
     * Returns the URL to the avatar of a user
     * @param {UserId} userId
     * @returns {String}
     */
    avatarUrl(userId: string): string;
    /**
     * create the authorization header in case the accesToken exists
     * @param accessToken {string};
     * @returns {string}
     */
    private createAuthorizationHeader;
    /**
     *
     * @param headers the header which will be sent to ims server on API request
     */
    private formEncoded;
}
