import { IDictionary } from '../facade/IDictionary';
import { IAuthorizedApiRequest } from './IAuthorizedApiRequest';
import { IUnAuthorizedApiRequest } from './IUnAuthorizedApiRequest';
import { ITransitoryAuthorizationRequest } from '../adobe-ims/facade/ITransitoryAuthorizationRequest';
/**
 * class used as a entry point for Ims api's
 * @todo discuss rate limit --> code 429 on http response.
 */
export declare class ImsApis {
    private CONTENT_FORM_ENCODED;
    apiParameters: any;
    /**
     * imsApis constructor;
     */
    constructor(apiParameters?: any);
    /**
     * validate the input token
     * @param request IAuthorizedApiRequest contains clientId and token information
     */
    validateToken(request: IAuthorizedApiRequest): Promise<any>;
    /**
     * retrieve the profile based on the input token
     * @param request IAuthorizedApiRequest contains clientId and token information
     */
    getProfile(request: IAuthorizedApiRequest): Promise<any>;
    /**
     * @returns the user info based on the input token
     * @param request IAuthorizedApiRequest contains clientId and token information
     */
    getUserInfo(request: IAuthorizedApiRequest): Promise<any>;
    /**
      * invalidate the input token
      * @param request IAuthorizedApiRequest contains clientId and token information
      */
    logoutToken(apiRequest: IAuthorizedApiRequest): Promise<any>;
    /**
     * Does an API to check the cookie status of the browser.
     */
    checkStatus(): Promise<any>;
    /**
     * @returns a new token
     * @param request IUnAuthorizedApiRequest contains clientId information
     * @param scope string contains the scope used for check token api
     * @todo We will probably need also check token v5
     */
    checkToken(apiRequest: IUnAuthorizedApiRequest, externalParameters: IDictionary, scope: string): Promise<any>;
    /**
     * @returns a new token and profile for the existing user
     * @param request IUnAuthorizedApiRequest contains clientId information
     * @param userId contains the user id of the logged user
     * https://wiki.corp.adobe.com/display/ims/IMS+API+-+check+token#IMSAPIchecktoken-Version6
     */
    switchProfile(apiRequest: IUnAuthorizedApiRequest, externalParameters: IDictionary, userId?: string): Promise<any>;
    /**
     * @returns list of api providers
     * @param request IUnAuthorizedApiRequest contains clientId information
     */
    listSocialProviders(apiRequest: IUnAuthorizedApiRequest): Promise<any>;
    /**
    * @see {@link https://wiki.corp.adobe.com/display/ims/Implicit+Jump+Tokens |Implicit Jump Tokens}
    * @param request IUnAuthorizedApiRequest contains clientId and token information
    * @param ijt {string}
    */
    exchangeIjt(apiRequest: IUnAuthorizedApiRequest, ijt: string): Promise<any>;
    /**
     * Returns the URL to the avatar of a user
     * @param {UserId} userId
     * @returns {String}
     */
    avatarUrl(userId: string): string;
    /**
     * Makes a request to IMS to get the Floodgate release flags.
     * Optionally accepts an access token from which to decode the release flags.
     * @param request IAuthorizedApiRequest contains clientId and token information
     */
    getReleaseFlags(request: IAuthorizedApiRequest): Promise<any>;
    /**
     * Exchange the user's access_token for a Transitory Access Code (TAC) for target client and scope
     * @param tacRequest {ITransitoryAuthorizationRequest} - contains the request parameters
     * @param externalParameters {object} - contains the possible parameters used to override the api parameters
     * @param clientId {string} - the adobeid.client_id value
     */
    getTransitoryAuthorizationCode(tacRequest: ITransitoryAuthorizationRequest, externalParameters: IDictionary | undefined, clientId: string): Promise<any>;
    /**
     * create the authorization header in case the accesToken exists
     * @param accessToken {string};
     * @returns {string}
     */
    private createAuthorizationHeader;
    /**
     *
     * @param headers the header which will be sent to ims server on API request
     */
    private formEncoded;
}
