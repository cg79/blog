/**
 * the interface used to send the parameters to /ims/token/v1
 */
export interface IPasswordGrantTypeRequest {
    /**
     * represents the client id used for password grant
     */
    username: string;
    /**
     * represents the password used for password grant
     */
    password: string;
    /**
     * represents the client secret used for password grant
     */
    client_secret: string;
    /**
     * represents the scope used for password grant
     */
    scope?: string;
    /**
     * represents the state sent to the server
     */
    state: any;
}
