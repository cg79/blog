"use strict";
var __assign = (this && this.__assign) || function () {
    __assign = Object.assign || function(t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
            s = arguments[i];
            for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p))
                t[p] = s[p];
        }
        return t;
    };
    return __assign.apply(this, arguments);
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
var ImsConstants_1 = require("../constants/ImsConstants");
var UrlHelper_1 = __importDefault(require("../url/UrlHelper"));
var ApiHelpers_1 = __importDefault(require("../api-helpers/ApiHelpers"));
var Environment_1 = __importDefault(require("../adobe-ims/environment/Environment"));
var ImsXhr_1 = __importDefault(require("./xhr/ImsXhr"));
/**
 * class used as a entry point for Ims api's
 * @todo discuss rate limit --> code 429 on http response.
 */
var ImsApis = /** @class */ (function () {
    /**
     * imsApis constructor;
     */
    function ImsApis(apiParameters) {
        if (apiParameters === void 0) { apiParameters = {}; }
        this.CONTENT_FORM_ENCODED = 'application/x-www-form-urlencoded;charset=utf-8';
        this.apiParameters = apiParameters;
    }
    /**
     * validate the input token
     * @param request IAuthorizedApiRequest contains clientId and token information
     */
    ImsApis.prototype.validateToken = function (request) {
        var token = request.token, client_id = request.client_id;
        var data = UrlHelper_1.default.uriEncodeData(__assign(__assign({}, ApiHelpers_1.default.getCustomApiParameters(this.apiParameters, 'validate_token')), { type: 'access_token', client_id: client_id,
            token: token }));
        var url = Environment_1.default.baseUrlAdobe + "/ims/validate_token/v1?jslVersion=" + Environment_1.default.jslibver;
        return ImsXhr_1.default.post(url, data, this.formEncoded());
    };
    /**
     * retrieve the profile based on the input token
     * @param request IAuthorizedApiRequest contains clientId and token information
     */
    ImsApis.prototype.getProfile = function (request) {
        var token = request.token, client_id = request.client_id;
        var additionalParams = __assign({}, ApiHelpers_1.default.getCustomApiParameters(this.apiParameters, 'profile'));
        var config = this.createAuthorizationHeader(token);
        var queryStrings = UrlHelper_1.default.uriEncodeData(__assign({ client_id: client_id }, additionalParams));
        var url = Environment_1.default.baseUrlAdobe + "/ims/profile/v1?" + queryStrings + "&jslVersion=" + Environment_1.default.jslibver;
        return ImsXhr_1.default.get(url, config);
    };
    /**
     * @returns the user info based on the input token
     * @param request IAuthorizedApiRequest contains clientId and token information
     */
    ImsApis.prototype.getUserInfo = function (request) {
        var token = request.token, client_id = request.client_id;
        var additionalParams = __assign({}, ApiHelpers_1.default.getCustomApiParameters(this.apiParameters, 'userinfo'));
        var config = this.createAuthorizationHeader(token);
        var queryStrings = UrlHelper_1.default.uriEncodeData(__assign({ client_id: client_id }, additionalParams));
        var url = Environment_1.default.baseUrlAdobe + "/ims/userinfo/v1?" + queryStrings + "&jslVersion=" + Environment_1.default.jslibver;
        return ImsXhr_1.default.get(url, config);
    };
    /**
      * invalidate the input token
      * @param request IAuthorizedApiRequest contains clientId and token information
      */
    ImsApis.prototype.logoutToken = function (apiRequest) {
        var client_id = apiRequest.client_id, access_token = apiRequest.token;
        var additionalParams = __assign({}, ApiHelpers_1.default.getCustomApiParameters(this.apiParameters, 'logout_token'));
        var url = Environment_1.default.baseUrlServices + "/ims/logout/v1?jslVersion=" + Environment_1.default.jslibver;
        return ImsXhr_1.default.post(url, __assign({ client_id: client_id,
            access_token: access_token }, additionalParams));
    };
    /**
     * Does an API to check the cookie status of the browser.
     */
    ImsApis.prototype.checkStatus = function () {
        var url = Environment_1.default.baseUrlServices + "/ims/check/v1/status";
        return ImsXhr_1.default.get(url);
    };
    /**
     * @returns a new token
     * @param request IUnAuthorizedApiRequest contains clientId information
     * @param scope string contains the scope used for check token api
     * @todo We will probably need also check token v5
     */
    ImsApis.prototype.checkToken = function (apiRequest, externalParameters, scope) {
        var client_id = apiRequest.client_id;
        var additionalParams = __assign({}, ApiHelpers_1.default.mergeExternalParameters(externalParameters, this.apiParameters, 'check_token'));
        var url = Environment_1.default.baseUrlServices + "/ims/check/v4/token?jslVersion=" + Environment_1.default.jslibver;
        var data = UrlHelper_1.default.uriEncodeData(__assign(__assign({}, additionalParams), { client_id: client_id,
            scope: scope }));
        return ImsXhr_1.default.post(url, data, this.formEncoded());
    };
    /**
     * @returns a new token and profile for the existing user
     * @param request IUnAuthorizedApiRequest contains clientId information
     * @param userId contains the user id of the logged user
     * https://wiki.corp.adobe.com/display/ims/IMS+API+-+check+token#IMSAPIchecktoken-Version6
     */
    ImsApis.prototype.switchProfile = function (apiRequest, externalParameters, userId) {
        if (userId === void 0) { userId = ''; }
        var client_id = apiRequest.client_id, _a = apiRequest.scope, scope = _a === void 0 ? '' : _a;
        var additionalParams = __assign({}, ApiHelpers_1.default.mergeExternalParameters(externalParameters, this.apiParameters, 'check_token'));
        var url = Environment_1.default.baseUrlServices + "/ims/check/v6/token?jslVersion=" + Environment_1.default.jslibver;
        var data = UrlHelper_1.default.uriEncodeData(__assign(__assign({}, additionalParams), { client_id: client_id,
            scope: scope, user_id: userId }));
        return ImsXhr_1.default.post(url, data, this.formEncoded());
    };
    /**
     * @returns list of api providers
     * @param request IUnAuthorizedApiRequest contains clientId information
     */
    ImsApis.prototype.listSocialProviders = function (apiRequest) {
        var client_id = apiRequest.client_id;
        var additionalParams = __assign({}, ApiHelpers_1.default.getCustomApiParameters(this.apiParameters, 'providers'));
        var queryStrings = UrlHelper_1.default.uriEncodeData(__assign({ client_id: client_id }, additionalParams));
        var url = Environment_1.default.baseUrlServices + "/ims/social/v1/providers?" + queryStrings + "&jslVersion=" + Environment_1.default.jslibver;
        return ImsXhr_1.default.get(url);
    };
    /**
    * @see {@link https://wiki.corp.adobe.com/display/ims/Implicit+Jump+Tokens |Implicit Jump Tokens}
    * @param request IUnAuthorizedApiRequest contains clientId and token information
    * @param ijt {string}
    */
    ImsApis.prototype.exchangeIjt = function (apiRequest, ijt) {
        var client_id = apiRequest.client_id;
        var additionalParams = __assign({}, ApiHelpers_1.default.getCustomApiParameters(this.apiParameters, 'ijt'));
        var url = Environment_1.default.baseUrlServices + "/ims/jump/implicit/" + ijt;
        var queryStrings = UrlHelper_1.default.uriEncodeData(__assign({ client_id: client_id }, additionalParams));
        var apiUrl = url + "?" + queryStrings + "&jslVersion=" + Environment_1.default.jslibver;
        if (apiUrl.length > 2048) {
            delete additionalParams['redirect_uri'];
            queryStrings = UrlHelper_1.default.uriEncodeData(additionalParams);
            apiUrl = url + "?" + queryStrings;
        }
        return ImsXhr_1.default.get(apiUrl);
    };
    /**
     * Returns the URL to the avatar of a user
     * @param {UserId} userId
     * @returns {String}
     */
    ImsApis.prototype.avatarUrl = function (userId) {
        return Environment_1.default.baseUrlAdobe + "/ims/avatar/download/" + userId;
    };
    /**
     * Makes a request to IMS to get the Floodgate release flags.
     * Optionally accepts an access token from which to decode the release flags.
     * @param request IAuthorizedApiRequest contains clientId and token information
     */
    ImsApis.prototype.getReleaseFlags = function (request) {
        var token = request.token, client_id = request.client_id;
        var additionalParams = __assign({}, ApiHelpers_1.default.getCustomApiParameters(this.apiParameters, 'fg_value'));
        var config = this.createAuthorizationHeader(token);
        var queryStrings = UrlHelper_1.default.uriEncodeData(__assign({ client_id: client_id }, additionalParams));
        var url = Environment_1.default.baseUrlAdobe + "/ims/fg/value/v1?" + queryStrings + "&jslVersion=" + Environment_1.default.jslibver;
        return ImsXhr_1.default.get(url, config);
    };
    /**
     * Exchange the user's access_token for a Transitory Access Code (TAC) for target client and scope
     * @param tacRequest {ITransitoryAuthorizationRequest} - contains the request parameters
     * @param externalParameters {object} - contains the possible parameters used to override the api parameters
     * @param clientId {string} - the adobeid.client_id value
     */
    ImsApis.prototype.getTransitoryAuthorizationCode = function (tacRequest, externalParameters, clientId) {
        if (externalParameters === void 0) { externalParameters = {}; }
        var additionalParams = __assign({}, ApiHelpers_1.default.mergeExternalParameters(externalParameters, this.apiParameters, 'check_token'));
        var url = Environment_1.default.baseUrlServices + "/ims/check/v6/token?client_id=" + clientId + "&jslVersion=" + Environment_1.default.jslibver;
        var data = UrlHelper_1.default.uriEncodeData(__assign(__assign({}, additionalParams), tacRequest));
        return ImsXhr_1.default.post(url, data, this.formEncoded());
    };
    /**
     * create the authorization header in case the accesToken exists
     * @param accessToken {string};
     * @returns {string}
     */
    ImsApis.prototype.createAuthorizationHeader = function (accessToken) {
        var headers = {};
        if (accessToken) {
            headers[ImsConstants_1.HEADERS.AUTHORIZATION] = "Bearer " + accessToken;
        }
        return headers;
    };
    /**
     *
     * @param headers the header which will be sent to ims server on API request
     */
    ImsApis.prototype.formEncoded = function (headers) {
        if (headers === void 0) { headers = {}; }
        headers["content-type"] = this.CONTENT_FORM_ENCODED;
        return headers;
    };
    return ImsApis;
}());
exports.ImsApis = ImsApis;
