"use strict";
var __assign = (this && this.__assign) || function () {
    __assign = Object.assign || function(t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
            s = arguments[i];
            for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p))
                t[p] = s[p];
        }
        return t;
    };
    return __assign.apply(this, arguments);
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.ImsApisCust = void 0;
var ImsConstants_1 = require("../constants/ImsConstants");
var UrlHelper_1 = __importDefault(require("../url/UrlHelper"));
var ApiHelpers_1 = __importDefault(require("../api-helpers/ApiHelpers"));
var Debouncer_1 = __importDefault(require("../debounce/Debouncer"));
var Environment_1 = __importDefault(require("../adobe-ims/environment/Environment"));
var Xhr_1 = __importDefault(require("./xhr/Xhr"));
/**
 * class used as a entry point for Ims api's
 * @todo discuss rate limit --> code 429 on http response.
 */
var ImsApisCust = /** @class */ (function () {
    /**
     * imsApis constructor;
     * sets the axios to use credentials
     */
    function ImsApisCust(apiParameters) {
        if (apiParameters === void 0) { apiParameters = {}; }
        this.CONTENT_FORM_ENCODED = 'application/x-www-form-urlencoded;charset=utf-8';
        this.apiParameters = apiParameters;
    }
    /**
     * check if the cache contains data for the same url and parameters value;
     * if true, returns the cached value otherwise make the http call
     * @param url - url used to make a POST http request
     * @param data - dat passed to the back-end
     * @param config - http configuration
     */
    ImsApisCust.prototype.post = function (url, data, config) {
        if (config === void 0) { config = {}; }
        var cachedData = Debouncer_1.default.getCachedApiResponse(url, data);
        if (cachedData) {
            var status_1 = cachedData.status, data_1 = cachedData.data;
            return status_1 === 200 ? Promise.resolve(data_1) : Promise.reject(data_1);
        }
        return config ? Xhr_1.default.post(url, data, config) : Xhr_1.default.post(url, data);
    };
    /**
     * check if the cache contains data for the input url
     * if true, returns the cached value otherwise make the http call
     * @param url - url used to make a POST http request
     * @param config - axios configuration
     */
    ImsApisCust.prototype.get = function (url, config) {
        if (config === void 0) { config = {}; }
        var cachedData = Debouncer_1.default.getCachedApiResponse(url);
        if (cachedData) {
            var status_2 = cachedData.status, data = cachedData.data;
            return status_2 === 200 ? Promise.resolve(data) : Promise.reject(data);
        }
        return config ? Xhr_1.default.get(url, config) : Xhr_1.default.get(url);
    };
    /**
     * validate the input token
     * @param request IAuthorizedApiRequest contains clientId and token information
     */
    ImsApisCust.prototype.validateToken = function (request) {
        var token = request.token, client_id = request.client_id;
        var data = UrlHelper_1.default.uriEncodeData(__assign(__assign({}, ApiHelpers_1.default.getCustomApiParameters(this.apiParameters, 'validate_token')), { type: 'access_token', client_id: client_id,
            token: token }));
        var url = Environment_1.default.baseUrlAdobe + "/ims/validate_token/v1";
        return this.post(url, data, this.formEncoded());
    };
    /**
     * retreive the profile based on the input token
     * @param request IAuthorizedApiRequest contains clientId and token information
     */
    ImsApisCust.prototype.getProfile = function (request) {
        var token = request.token, client_id = request.client_id;
        var additionalParams = __assign({}, ApiHelpers_1.default.getCustomApiParameters(this.apiParameters, 'profile'));
        var config = this.createAuthorizationHeader(token);
        var queryStrings = UrlHelper_1.default.uriEncodeData(__assign({ client_id: client_id }, additionalParams));
        var url = Environment_1.default.baseUrlAdobe + "/ims/profile/v1?" + queryStrings;
        return this.get(url, config);
    };
    /**
     * @returns the user info based on the input token
     * @param request IAuthorizedApiRequest contains clientId and token information
     */
    ImsApisCust.prototype.getUserInfo = function (request) {
        var token = request.token, client_id = request.client_id;
        var additionalParams = __assign({}, ApiHelpers_1.default.getCustomApiParameters(this.apiParameters, 'userinfo'));
        var config = this.createAuthorizationHeader(token);
        var queryStrings = UrlHelper_1.default.uriEncodeData(__assign({ client_id: client_id }, additionalParams));
        var url = Environment_1.default.baseUrlAdobe + "/ims/userinfo/v1?" + queryStrings;
        return this.get(url, config);
    };
    /**
      * invalidate the input token
      * @param request IAuthorizedApiRequest contains clientId and token information
      */
    ImsApisCust.prototype.logoutToken = function (apiRequest) {
        var client_id = apiRequest.client_id, access_token = apiRequest.token;
        var additionalParams = __assign({}, ApiHelpers_1.default.getCustomApiParameters(this.apiParameters, 'logout_token'));
        var url = Environment_1.default.baseUrlServices + "/ims/logout/v1";
        return this.post(url, __assign({ client_id: client_id,
            access_token: access_token }, additionalParams));
    };
    /**
     * Does an API to check the cookie status of the browser.
     */
    ImsApisCust.prototype.checkStatus = function () {
        var url = Environment_1.default.baseUrlServices + "/ims/check/v1/status";
        return this.get(url);
    };
    /**
     * @returns a new token
     * @param request IUnAuthorizedApiRequest contains clientId information
     * @param scope string contains the scope used for check token api
     * @todo We will probably need also check token v5
     */
    ImsApisCust.prototype.checkToken = function (apiRequest, externalParameters, scope) {
        var client_id = apiRequest.client_id;
        var additionalParams = __assign({}, ApiHelpers_1.default.mergeExternalParameters(externalParameters, this.apiParameters, 'check_token'));
        var url = Environment_1.default.baseUrlServices + "/ims/check/v4/token";
        var data = UrlHelper_1.default.uriEncodeData(__assign(__assign({}, additionalParams), { client_id: client_id,
            scope: scope }));
        return this.post(url, data, this.formEncoded());
    };
    /**
     * @returns list of api providers
     * @param request IUnAuthorizedApiRequest contains clientId information
     */
    ImsApisCust.prototype.listSocialProviders = function (apiRequest) {
        var client_id = apiRequest.client_id;
        var additionalParams = __assign({}, ApiHelpers_1.default.getCustomApiParameters(this.apiParameters, 'providers'));
        var queryStrings = UrlHelper_1.default.uriEncodeData(__assign({ client_id: client_id }, additionalParams));
        var url = Environment_1.default.baseUrlServices + "/ims/social/v1/providers?" + queryStrings;
        return this.get(url);
    };
    /**
    * @see {@link https://wiki.corp.adobe.com/display/ims/Implicit+Jump+Tokens |Implicit Jump Tokens}
    * @param request IUnAuthorizedApiRequest contains clientId and token information
    * @param ijt {string}
    */
    ImsApisCust.prototype.exchangeIjt = function (apiRequest, ijt) {
        var client_id = apiRequest.client_id;
        var additionalParams = __assign({}, ApiHelpers_1.default.getCustomApiParameters(this.apiParameters, 'ijt'));
        var url = Environment_1.default.baseUrlServices + "/ims/jump/implicit/" + ijt;
        var queryStrings = UrlHelper_1.default.uriEncodeData(__assign({ client_id: client_id }, additionalParams));
        var apiUrl = url + "?" + queryStrings;
        if (apiUrl.length > 2048) {
            delete additionalParams['redirect_uri'];
            queryStrings = UrlHelper_1.default.uriEncodeData(additionalParams);
            apiUrl = url + "?" + queryStrings;
        }
        return this.get(apiUrl);
    };
    /**
     * Returns the URL to the avatar of a user
     * @param {UserId} userId
     * @returns {String}
     */
    ImsApisCust.prototype.avatarUrl = function (userId) {
        return Environment_1.default.baseUrlAdobe + "/ims/avatar/download/" + userId;
    };
    /**
     * create the authorization header in case the accesToken exists
     * @param accessToken {string};
     * @returns {string}
     */
    ImsApisCust.prototype.createAuthorizationHeader = function (accessToken) {
        var headers = {};
        if (accessToken) {
            headers[ImsConstants_1.HEADERS.AUTHORIZATION] = "Bearer " + accessToken;
        }
        return {
            headers: headers
        };
    };
    /**
     *
     * @param headers the header which will be sent to ims server on API request
     */
    ImsApisCust.prototype.formEncoded = function (headers) {
        if (headers === void 0) { headers = {}; }
        headers["content-type"] = this.CONTENT_FORM_ENCODED;
        return headers;
    };
    return ImsApisCust;
}());
exports.ImsApisCust = ImsApisCust;
