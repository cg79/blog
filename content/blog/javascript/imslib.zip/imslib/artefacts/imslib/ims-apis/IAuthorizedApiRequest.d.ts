export interface IAuthorizedApiRequest {
    token: string;
    client_id: string;
}
