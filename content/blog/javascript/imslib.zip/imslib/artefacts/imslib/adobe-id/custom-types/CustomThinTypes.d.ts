export declare type OnReadyFunction = (applicationState: any) => void;
