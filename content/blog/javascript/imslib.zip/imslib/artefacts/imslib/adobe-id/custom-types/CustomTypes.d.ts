import { IAdobeIMS } from '../../adobe-ims/facade/IAdobeIMS';
import { IAdobeIMSThin } from '../../adobe-ims/facade/IAdobeIMSThin';
import { IErrorType } from '../IErrorType';
/**
 * Custom function type used to trigger the error handler
 * Every call of the error handler should contain the error type and the associated message
 * @param type {IErrorType} - represents the error type used to trigger the error handler
 * @param message {any} - represents the custom error message or exception object
 */
export declare type OnErrorFunction = (type: IErrorType, message: any) => void;
export declare type OnImsInstanceFunction = (imsInstance: IAdobeIMS | IAdobeIMSThin) => void;
export declare type OnAccessTokenFunction = (data: ITokenInformation) => void;
export declare type OnProfileFunction = (profile: any) => void;
export declare type OnAccessTokenHasExpiredFunction = () => void;
export interface ITokenInformation {
    token: string;
    expire: Date;
    /**
     * represents the session identifier
     */
    sid: string;
    token_type?: string;
}
export interface IImsInstance {
    clientId: string;
    instance: IAdobeIMS | IAdobeIMSThin;
}
