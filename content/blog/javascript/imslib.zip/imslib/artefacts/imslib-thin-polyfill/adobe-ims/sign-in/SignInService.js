"use strict";
var __assign = (this && this.__assign) || function () {
    __assign = Object.assign || function(t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
            s = arguments[i];
            for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p))
                t[p] = s[p];
        }
        return t;
    };
    return __assign.apply(this, arguments);
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
var RedirectHelper_1 = require("../helpers/RedirectHelper");
var UrlHelper_1 = __importDefault(require("../../url/UrlHelper"));
var Environment_1 = __importDefault(require("../environment/Environment"));
/**
 * command responsable for user sign in
 */
var SignInService = /** @class */ (function () {
    function SignInService() {
        var _this = this;
        /**
         * execute the sign in method which redirects the user to the login page
         * <uml>
         * start
         * :CreateRedirectUrl;
         * :merge api parameters with external parameters
         * :encode the merged parameters and call the /ims/authorize/v1/${encodedParameters} url
         * end
         * </uml>
         *
         * @param {IRedirectRequest} redirectRequest. contains all the adobeId necessary properties necessary for sign in
         */
        this.signIn = function (redirectRequest) {
            var url = _this.createRedirectUrl(redirectRequest);
            UrlHelper_1.default.replaceUrl(url);
        };
        /**
         *
         * @param token { String } value used to authorize a user based on this token value
         * @param redirectRequest { IRedirectRequest } contains the object properties which are passed to the authorize api
         */
        this.authorizeToken = function (token, redirectRequest) {
            var parameters = _this.composeRedirectUrl(redirectRequest);
            if (token) {
                parameters.user_assertion = token;
                parameters.user_assertion_type = 'urn:ietf:params:oauth:client-assertion-type:jwt-bearer';
            }
            var postForm = _this.createAuthorizeForm(parameters);
            postForm.submit();
        };
        /**
         * execute the sign in method which redirects the user to the login page
         * <uml>
         * start
         * :CreateRedirectUrl;
         * :merge api parameters with external parameters
         * :encode the merged parameters and call the /ims/authorize/v1/${encodedParameters} url
         * end
         * </uml>
         *
         * @param {IRedirectRequest} redirectRequest. contains all the adobeId necessary properties necessary for sign in
         */
        this.composeRedirectUrl = function (redirectRequest) {
            var apiName = "authorize";
            var apiParameters = redirectRequest.apiParameters, _a = redirectRequest.externalParameters, externalParameters = _a === void 0 ? {} : _a, _b = redirectRequest.adobeIdRedirectUri, adobeIdRedirectUri = _b === void 0 ? "" : _b, clientId = redirectRequest.clientId, localeAdobeId = redirectRequest.locale, _c = redirectRequest.state, state = _c === void 0 ? {} : _c;
            var _d = redirectRequest.scope, scope = _d === void 0 ? externalParameters["scope"] || apiParameters["scope"] || "" : _d;
            var apiExternalParams = RedirectHelper_1.RedirectHelper.mergeApiParamsWithExternalParams(apiParameters, externalParameters, apiName);
            var redirectUrl = RedirectHelper_1.RedirectHelper.createRedirectUrl(adobeIdRedirectUri, clientId, apiExternalParams, apiName, scope);
            var locale = externalParameters.locale || localeAdobeId || '';
            var 
            // eslint-disable-next-line @typescript-eslint/camelcase
            _e = redirectRequest.response_type, 
            // eslint-disable-next-line @typescript-eslint/camelcase
            response_type = _e === void 0 ? apiExternalParams["response_type"] || '' : _e;
            var parameters = __assign(__assign({}, apiExternalParams), { client_id: clientId, scope: scope,
                locale: locale,
                response_type: response_type, jslVersion: Environment_1.default.jslibver, redirect_uri: redirectUrl });
            if (state) {
                parameters["state"] = state;
            }
            return parameters;
        };
        /**
         * execute the sign in method which redirects the user to the login page
         * <uml>
         * start
         * :CreateRedirectUrl;
         * :merge api parameters with external parameters
         * :encode the merged parameters and call the /ims/authorize/v1/${encodedParameters} url
         * end
         * </uml>
         *
         * @param {IRedirectRequest} redirectRequest. contains all the adobeId necessary properties necessary for sign in
         */
        this.createRedirectUrl = function (redirectRequest) {
            var parameters = _this.composeRedirectUrl(redirectRequest);
            var queryStrings = UrlHelper_1.default.uriEncodeData(parameters);
            var url = Environment_1.default.baseUrlAdobe + "/ims/authorize/v1?" + queryStrings;
            return url;
        };
    }
    /**
     * returns a html form containing all the properties from the parameter object
     * @param parameters {object} contains the properties which will be passed to authorize api (as form submit post action)
     */
    SignInService.prototype.createAuthorizeForm = function (parameters) {
        var formAction = Environment_1.default.baseUrlAdobe + "/ims/authorize/v1";
        var form = document.createElement("form");
        form.setAttribute("method", "post");
        form.setAttribute("action", formAction);
        var formEl = null;
        var paramValue = null;
        var paramValueAsString = '';
        for (var propertyName in parameters) {
            paramValue = parameters[propertyName];
            if (typeof paramValue === 'object') {
                if (Object.keys(paramValue).length === 0) {
                    continue;
                }
                paramValueAsString = JSON.stringify(paramValue);
            }
            else {
                paramValueAsString = paramValue;
            }
            if (paramValueAsString !== '') {
                formEl = this.createFormElement('input', 'text', propertyName, paramValueAsString);
                form.appendChild(formEl);
            }
        }
        document.getElementsByTagName("body")[0]
            .appendChild(form);
        return form;
    };
    /**
     * create a new html form element; this element will be added to the form
     * @param inputType {String} input html element type
     * @param type {String} type of the input element
     * @param name {String} name of the input element
     * @param value {String} value for the element
     */
    SignInService.prototype.createFormElement = function (inputType, type, name, value) {
        var formElement = document.createElement(inputType);
        formElement.setAttribute("type", type);
        formElement.setAttribute("name", name);
        formElement.setAttribute("value", value);
        return formElement;
    };
    return SignInService;
}());
exports.SignInService = SignInService;
