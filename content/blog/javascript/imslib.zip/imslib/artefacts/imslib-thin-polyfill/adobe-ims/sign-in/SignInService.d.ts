import { IRedirectRequest } from "../facade/IRedirectRequest";
/**
 * command responsable for user sign in
 */
export declare class SignInService {
    /**
     * execute the sign in method which redirects the user to the login page
     * <uml>
     * start
     * :CreateRedirectUrl;
     * :merge api parameters with external parameters
     * :encode the merged parameters and call the /ims/authorize/v1/${encodedParameters} url
     * end
     * </uml>
     *
     * @param {IRedirectRequest} redirectRequest. contains all the adobeId necessary properties necessary for sign in
     */
    signIn: (redirectRequest: IRedirectRequest) => void;
    /**
     *
     * @param token { String } value used to authorize a user based on this token value
     * @param redirectRequest { IRedirectRequest } contains the object properties which are passed to the authorize api
     */
    authorizeToken: (token: string, redirectRequest: IRedirectRequest) => void;
    /**
     * returns a html form containing all the properties from the parameter object
     * @param parameters {object} contains the properties which will be passed to authorize api (as form submit post action)
     */
    private createAuthorizeForm;
    /**
     * create a new html form element; this element will be added to the form
     * @param inputType {String} input html element type
     * @param type {String} type of the input element
     * @param name {String} name of the input element
     * @param value {String} value for the element
     */
    private createFormElement;
    /**
     * execute the sign in method which redirects the user to the login page
     * <uml>
     * start
     * :CreateRedirectUrl;
     * :merge api parameters with external parameters
     * :encode the merged parameters and call the /ims/authorize/v1/${encodedParameters} url
     * end
     * </uml>
     *
     * @param {IRedirectRequest} redirectRequest. contains all the adobeId necessary properties necessary for sign in
     */
    composeRedirectUrl: (redirectRequest: IRedirectRequest) => any;
    /**
     * execute the sign in method which redirects the user to the login page
     * <uml>
     * start
     * :CreateRedirectUrl;
     * :merge api parameters with external parameters
     * :encode the merged parameters and call the /ims/authorize/v1/${encodedParameters} url
     * end
     * </uml>
     *
     * @param {IRedirectRequest} redirectRequest. contains all the adobeId necessary properties necessary for sign in
     */
    createRedirectUrl: (redirectRequest: IRedirectRequest) => string;
}
