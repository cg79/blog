import { TokenFields } from "../token/TokenFields";
import { IDictionary } from "../facade/IDictionary";
export declare class TokenProfileResponse {
    tokenFields: TokenFields;
    profile: IDictionary | null;
    constructor(tokenFields: TokenFields);
}
