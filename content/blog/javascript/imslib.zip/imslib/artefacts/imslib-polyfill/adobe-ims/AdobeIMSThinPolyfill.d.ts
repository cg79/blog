import 'ts-polyfill/lib/es2018-promise';
export { AdobeIMSThin } from './AdobeIMSThin';
