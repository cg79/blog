"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var IEnvironment_1 = require("../../adobe-id/IEnvironment");
/**
 * class used to store the variables used for ims flow
 */
var Environment = /** @class */ (function () {
    function Environment() {
        /**
       * @property {String} Represents the base url used on api (back-end) call in case of getProfile, getUserInfo and validateToken;
       */
        this.baseUrlAdobe = '';
        /**
       * @property {string} Represents the base url used on api (back-end) call in case of logoutToken, checkStatus checkToken,listSocialProviders and exchangeIjt;
       */
        this.baseUrlServices = '';
        /**
       * @property {string} this parameter is passed to redirect uri during a sign in or sign out operation
       */
        this.jslibver = 'v2-v0.14.0-7-g14ae821';
    }
    Environment.prototype.loadEnvironment = function (environment) {
        if (environment === IEnvironment_1.IEnvironment.STAGE) {
            this.baseUrlAdobe = 'https://ims-na1-stg1.adobelogin.com';
            this.baseUrlServices = 'https://adobeid-na1-stg1.services.adobe.com';
            return;
        }
        this.baseUrlAdobe = 'https://ims-na1.adobelogin.com';
        this.baseUrlServices = 'https://adobeid-na1.services.adobe.com';
    };
    return Environment;
}());
exports.default = new Environment();
