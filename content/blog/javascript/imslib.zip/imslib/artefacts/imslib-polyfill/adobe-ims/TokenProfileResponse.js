"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var TokenProfileResponse = /** @class */ (function () {
    function TokenProfileResponse(tokenFields) {
        this.profile = null;
        this.tokenFields = tokenFields;
    }
    return TokenProfileResponse;
}());
exports.TokenProfileResponse = TokenProfileResponse;
