import { IRedirectSignoutRequest } from '../facade/IRedirectSignoutRequest';
/**
 * command responsable for user sign out
 */
export declare class SignOutService {
    /**
     * @param {IRedirectRequest} redirectRequest. contains all the necessary properties necessary for sign out
     */
    signOut: (redirectRequest: IRedirectSignoutRequest) => void;
}
