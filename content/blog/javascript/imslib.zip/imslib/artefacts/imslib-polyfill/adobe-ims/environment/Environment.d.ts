import { IEnvironment } from "../../adobe-id/IEnvironment";
/**
 * class used to store the variables used for ims flow
 */
declare class Environment {
    /**
   * @property {String} Represents the base url used on api (back-end) call in case of getProfile, getUserInfo and validateToken;
   */
    baseUrlAdobe: string;
    /**
   * @property {string} Represents the base url used on api (back-end) call in case of logoutToken, checkStatus checkToken,listSocialProviders and exchangeIjt;
   */
    baseUrlServices: string;
    /**
   * @property {string} this parameter is passed to redirect uri during a sign in or sign out operation
   */
    jslibver: string;
    loadEnvironment(environment: IEnvironment): void;
}
declare const _default: Environment;
export default _default;
