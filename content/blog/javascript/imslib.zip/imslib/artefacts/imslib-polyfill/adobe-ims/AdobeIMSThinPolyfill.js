"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
require("ts-polyfill/lib/es2018-promise");
var AdobeIMSThin_1 = require("./AdobeIMSThin");
exports.AdobeIMSThin = AdobeIMSThin_1.AdobeIMSThin;
