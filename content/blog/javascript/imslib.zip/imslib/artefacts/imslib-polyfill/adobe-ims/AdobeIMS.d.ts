import { IAdobeIdData } from "../adobe-id/IAdobeIdData";
import { IDictionary } from './../facade/IDictionary';
import { ImsApis } from './../ims-apis/ImsApis';
import { IReauth } from './facade/IReauth';
import { StandaloneToken } from '../token/StandaloneToken';
import { IAdobeIMS } from './facade/IAdobeIMS';
import { ITokenInformation } from '../adobe-id/custom-types/CustomTypes';
import { ITransitoryAuthorizationRequest } from './facade/ITransitoryAuthorizationRequest';
import { ITransitoryAuthorizationResponse } from './facade/ITransitoryAuthorizationResponse';
/**
 * Class used as a facade for ims library in order to provide public access to library functionalities
 *
 */
export declare class AdobeIMS implements IAdobeIMS {
    /**
     * AdobeIdData
     * the values for adobeId are read from window.adobeid or passed by using the constructor
    */
    private adobeIdData;
    /**
     * Token Service instance used for token management
     */
    private tokenService;
    /**
     * Profile service instance used for profile management
     */
    private profileService;
    /**
     * Service Request object used for token and profile services.
     * contains the clientId, scope and imsApis instance
     */
    private serviceRequest;
    /**
     * instance of CsrfService
     */
    private csrfService;
    /**
     * Represents the class used to call the back-end methods;
     * it is visible ONLY because this is the only way t mock the api calls during functional tests
    */
    imsApis: ImsApis;
    /**
     * represents the adobe ims library version
     */
    get version(): string;
    /**
     * AdobeIdData
     * the values for adobeId are read from window.adobeid or passed by using the constructor
    */
    get adobeid(): IAdobeIdData;
    /**
     * @constructor adobeData {AdobeIdData}
     * If adobeData is not null, the adobeIdData instance will be created based on these values
     *
     * if no adobeData, the imsLibrary try to read these values from window.adobeid
     *
     * After this AdobeIms class is created, it can be accessed by window[{adobeData.clientId}]
    */
    constructor(adobeData?: IAdobeIdData | null);
    /**
     * enable the logging mechanism
     */
    enableLogging(): void;
    /**
     * disable the logging mechanism
     */
    disableLogging(): void;
    /**
     * Method used to redirect the user to signin url
     *
     * <uml>
     * start
     * :SignIn;
     * :Create the state object by using appCode, appVersion (used on server side) from adobeId.analytics and contextToBePassedOnRedirect;
     * :Create the redirect url using external parameters. state object will be part of redirect url;
     * :user must enter the credentials and after that is redirected to initial uri;
     * :initialize method is used which will trigger the onAccessToken;
     * end
     * </uml>
     *
     *
     * @param externalParameters {Object} object sent from outside in order to have the possibility to override the default values when the redirect uri is created
     * @param contextToBePassedOnRedirect {any | undefined} represents the context which is passed during redirect
     *
    */
    signIn: (externalParameters?: IDictionary, contextToBePassedOnRedirect?: any) => void;
    /**
     * method used to sign in using an external token
     * @param token { String } token used for authorize; if the token is empty, the user will be redirected to the sign in screen
     * @param externalParameters {Object} object sent from outside in order to have the possibility to override the default values when the redirect uri is created
     * @param contextToBePassedOnRedirect {any | undefined} represents the context which is passed during redirect
     */
    authorizeToken: (token?: string, externalParameters?: IDictionary, contextToBePassedOnRedirect?: any) => void;
    /**
     * Method used to reAuthenticate the user
     *
     * <uml>
     * start
     * :Create the state object by using appCode, appVersion (used on server side) from adobeId.analytics and contextToBePassedOnRedirect;
     * :Create the redirect url using external parameters. state object will be part of redirect url;
     * :SignIn;
     * :user must enter the credentials and after that is redirected to initial uri;
     * :initialize method is used which will trigger the token and profile;
     * end
     *
     * </uml>
     *
     * @param requestedParameters object sent from outside in order to use diferent values for reAuthenticate
     * @param contextToBePassedOnRedirect {Object | undefined} represents the context which is passed during redirect
     * @param reauth {string}; represents the re authenticate value. available values are: check and force. default value is "check"
     *
    */
    reAuthenticate: (requestedParameters?: IDictionary, reauth?: IReauth, contextToBePassedOnRedirect?: any) => void;
    /**
     * Method used to redirect the user to the signup screen
     *
     * <uml>
     * start
     * :Create the state object by using appCode, appVersion (used on server side) from adobeId.analytics and contextToBePassedOnRedirect;
     * :Create the redirect url using external parameters. state object will be part of redirect url;
     * :SignUp;
     * :initialize method is used which will trigger the token and profile;
     * end
     *
     * </uml>
     *
     * @param requestedParameters object sent from outside in order to use diferent values for signUp
     * @param contextToBePassedOnRedirect {any | undefined} represents the context which is passed during redirect
     *
    */
    signUp(requestedParameters?: IDictionary, contextToBePassedOnRedirect?: any): void;
    /**
     * sign in with social providers
     * @param providerName provider name used for sign in
     * @param externalParameters external parameters sent by developer
     * @param contextToBePassedOnRedirect {Object} state of the application
     */
    signInWithSocialProvider: (providerName: any, externalParameters?: IDictionary, contextToBePassedOnRedirect?: any) => void;
    /**
     * @function Method used to check if the user is signed in or not.
     * if local storage contains a token and is validated (only against expiration), the result is true
     * returns {boolean}
    */
    isSignedInUser(): boolean;
    /**
     * @function Method used to get the user profile in case the user is logged)
     * returns {IDictionary | null}  representing the user profile or null
    */
    getProfile(): Promise<any>;
    /**
     *  Method used for sign out the user
     *
     * <uml>
     * start
     * :Signout;
     * :Create the redirect url;
     * :remove the token and profile from storage;
     * :initialize method is used which will redirect the app to initial url;
     * end
     * </uml>
     *
     * @param externalParameters {Object} object sent from outside in order to have the possibility to override the default values when the redirect uri is created
     *
    */
    signOut: (externalParameters?: IDictionary) => void;
    /**
     * @function Returns the URL of the user avatar
     * @param {UserId} userId
    */
    avatarUrl(userId: string): string;
    /**
      * method used to retrieve the token release flags
    */
    getReleaseFlags(): Promise<any>;
    /**
      *
      * Returns the access token value from the local storage
      *
      * <uml>
      * start
      * :getAccessToken;
      * :check the local storage;
      * :if token exists, it is validated agains expiration;
      * :if valid the token is returned otherwise an empty token;
      * end
      * </uml>
      *
    */
    getAccessToken(): ITokenInformation | null;
    /**
     *
     * Returns the reauth access token value from the local storage
     *
     * <uml>
     * start
     * :getReauthAccessToken;
     * :check the local storage;
     * :if token exists, it is validated agains expiration;
     * :if valid the token is returned otherwise an empty token;
     * end
     * </uml>
     *
   */
    getReauthAccessToken(): ITokenInformation | null;
    /**
     * method used to get the social providers.
     * returns Promise - can be used to determine when the call has been ended and read the social providers response
     */
    listSocialProviders(): Promise<any>;
    /**
     *
     * @param token {string} represents the access token
     * @param expire {Date} the date when the token will expire
     */
    private tokenReceived;
    /**
     * Refresh the existing token.
     *
     * <uml>
     * start
     * :refreshToken;
     * :call backend: ims/check/v4/token?client_id;
     * :read the token and profile;
     * :triggerOnAccessToken;
     * if (profile) then (yes)
     * else (nothing)
     * :call backend to get the profile ;
     * endif
     * end
     * </uml>
     *
     * @param externalParameters {Object} external parameters sent from outside of the library
     * Note: if refresh token API fails, the triggerOnAccessTokenHasExpired will be triggered
    */
    refreshToken: (externalParameters?: IDictionary) => Promise<any>;
    /**
     * retreive a new token and profile for the input user id
     * @param externalParameters {Object} external parameters sent from outside of the library
     * @param userId {String} represents the user id used to get the new token and profile
     */
    switchProfile: (userId: string, externalParameters?: IDictionary) => Promise<any>;
    /**
     * method used to process the token and profile
     * @param tokenResponse {IRefreshTokenResponse} represents the token and profile received from back-end
     */
    private onTokenProfileReceived;
    /**
     * @returns a promise which is resolved as true in case the token is valid otherwise false
     * validate the existing token;
     */
    validateToken(): Promise<boolean>;
    /**
     * method used in case the existent token has expired
     */
    private onTokenExpired;
    /**
     * set a new token into the local storage
     * @param tokenInfo {tokenInfo} represents the token/ expire information used by library
     */
    setStandAloneToken(standaloneToken: StandaloneToken): boolean;
    /**
     * Method called on library initialization or page reloading
     * <uml>
     * start
     * :initialize method;
     * :get token;
     * if (fragment) then (yes)
     * :returns the token from fragment;
     * else (check local storage)
     * :returns the token from local storage;
     * endif
     * :if no token: return triggerOnAccessTokenHasExpired;
     * :triggerOnAccessToken;
     * :back-end: calls getProfile ;
     * :triggerOnReady ;
     * end
     * </uml>
     *
     * Note: this method is automatically called on every page reload;
    */
    initialize(): Promise<any>;
    /**
     *
     * @param instance { AdobeIMS } instance of AdobeIMS
     */
    private triggerOnImsInstance;
    /**
       * process the initialize exception;
       * this method is the first method called in case there was an error during initialize flow;
       * check if the exception type is TokenExpiredException and pass the flow to the verifyCsrfException
       * @param initializeException represent the exception received during the initialize
       */
    private processInitializeException;
    /**
     * method called in case of exception on initialize.  if error is RideError, ir redirects to the jump url from RideException.jump
     */
    private verifyRideErrorException;
    /**
     * method called in case of exception on initialize.  if error type is CSRF, it calls the signOut methods
     */
    private verifyCsrfException;
    /**
     * method called after a successful call to the getTokenAndProfile method in order to process the token response
     * tokenProfile: TokenProfileResponse - contains the token fields and eventually the user profile
     * @returns Promise
     */
    private processTokenResponse;
    /**
     * restore the window hash value to the initial one
     */
    private restoreHash;
    /**
     * Exchange the user's access_token for a Transitory Access Code (TAC) for target client and scope
     * @see {@link https://wiki.corp.adobe.com/display/ims/Transitory+Authorization+Codes |Transitory Authorization Codes}
     * @param tacRequest {ITransitoryAuthorizationRequest}
     * @param externalParameters {IDictionary}
     */
    getTransitoryAuthorizationCode(tacRequest: ITransitoryAuthorizationRequest, externalParameters?: IDictionary): Promise<ITransitoryAuthorizationResponse>;
}
