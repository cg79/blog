"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
require("ts-polyfill/lib/es2018-promise");
var AdobeIMS_1 = require("./AdobeIMS");
exports.AdobeIMS = AdobeIMS_1.AdobeIMS;
