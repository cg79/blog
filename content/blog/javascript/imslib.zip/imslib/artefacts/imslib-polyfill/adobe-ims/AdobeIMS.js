"use strict";
var __assign = (this && this.__assign) || function () {
    __assign = Object.assign || function(t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
            s = arguments[i];
            for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p))
                t[p] = s[p];
        }
        return t;
    };
    return __assign.apply(this, arguments);
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
var CsrfService_1 = require("./csrf/CsrfService");
var Log_1 = __importDefault(require("../log/Log"));
var SignInService_1 = require("./sign-in/SignInService");
var SignOutService_1 = require("./sign-out/SignOutService");
var AdobeIdData_1 = require("./../adobe-id/AdobeIdData");
var ImsApis_1 = require("./../ims-apis/ImsApis");
var IReauth_1 = require("./facade/IReauth");
var ProfileException_1 = require("../profile/ProfileException");
var ProfileService_1 = require("../profile/ProfileService");
var TokenService_1 = require("../token/TokenService");
var UrlHelper_1 = __importDefault(require("../url/UrlHelper"));
var FragmentHelper_1 = __importDefault(require("../url/FragmentHelper"));
var IErrorType_1 = require("../adobe-id/IErrorType");
var TokenExpiredException_1 = require("../token/TokenExpiredException");
var RideException_1 = require("../token/RideException");
var HttpErrorResponse_1 = require("../error-handlers/HttpErrorResponse");
var TokenAutoRefresh_1 = __importDefault(require("./token-auto-refresh/TokenAutoRefresh"));
var ImsConstants_1 = require("../constants/ImsConstants");
var Environment_1 = __importDefault(require("./environment/Environment"));
/**
 * Class used as a facade for ims library in order to provide public access to library functionalities
 *
 */
var AdobeIMS = /** @class */ (function () {
    /**
     * @constructor adobeData {AdobeIdData}
     * If adobeData is not null, the adobeIdData instance will be created based on these values
     *
     * if no adobeData, the imsLibrary try to read these values from window.adobeid
     *
     * After this AdobeIms class is created, it can be accessed by window[{adobeData.clientId}]
    */
    function AdobeIMS(adobeData) {
        var _this = this;
        if (adobeData === void 0) { adobeData = null; }
        /**
         * Method used to redirect the user to signin url
         *
         * <uml>
         * start
         * :SignIn;
         * :Create the state object by using appCode, appVersion (used on server side) from adobeId.analytics and contextToBePassedOnRedirect;
         * :Create the redirect url using external parameters. state object will be part of redirect url;
         * :user must enter the credentials and after that is redirected to initial uri;
         * :initialize method is used which will trigger the onAccessToken;
         * end
         * </uml>
         *
         *
         * @param externalParameters {Object} object sent from outside in order to have the possibility to override the default values when the redirect uri is created
         * @param contextToBePassedOnRedirect {any | undefined} represents the context which is passed during redirect
         *
        */
        this.signIn = function (externalParameters, contextToBePassedOnRedirect) {
            if (externalParameters === void 0) { externalParameters = {}; }
            var _a = _this, adobeIdData = _a.adobeIdData, csrfService = _a.csrfService;
            var nonce = csrfService.initialize();
            var authorizeRequestData = adobeIdData.createRedirectRequest(externalParameters, contextToBePassedOnRedirect, nonce);
            new SignInService_1.SignInService().signIn(authorizeRequestData);
        };
        /**
         * method used to sign in using an external token
         * @param token { String } token used for authorize; if the token is empty, the user will be redirected to the sign in screen
         * @param externalParameters {Object} object sent from outside in order to have the possibility to override the default values when the redirect uri is created
         * @param contextToBePassedOnRedirect {any | undefined} represents the context which is passed during redirect
         */
        this.authorizeToken = function (token, externalParameters, contextToBePassedOnRedirect) {
            if (token === void 0) { token = ''; }
            if (externalParameters === void 0) { externalParameters = {}; }
            var _a = _this, adobeIdData = _a.adobeIdData, csrfService = _a.csrfService;
            var nonce = csrfService.initialize();
            var redirectRequest = adobeIdData.createRedirectRequest(externalParameters, contextToBePassedOnRedirect, nonce);
            new SignInService_1.SignInService().authorizeToken(token, redirectRequest);
        };
        /**
         * Method used to reAuthenticate the user
         *
         * <uml>
         * start
         * :Create the state object by using appCode, appVersion (used on server side) from adobeId.analytics and contextToBePassedOnRedirect;
         * :Create the redirect url using external parameters. state object will be part of redirect url;
         * :SignIn;
         * :user must enter the credentials and after that is redirected to initial uri;
         * :initialize method is used which will trigger the token and profile;
         * end
         *
         * </uml>
         *
         * @param requestedParameters object sent from outside in order to use diferent values for reAuthenticate
         * @param contextToBePassedOnRedirect {Object | undefined} represents the context which is passed during redirect
         * @param reauth {string}; represents the re authenticate value. available values are: check and force. default value is "check"
         *
        */
        this.reAuthenticate = function (requestedParameters, reauth, contextToBePassedOnRedirect) {
            if (requestedParameters === void 0) { requestedParameters = {}; }
            if (reauth === void 0) { reauth = IReauth_1.IReauth.check; }
            var _a = _this, adobeIdData = _a.adobeIdData, csrfService = _a.csrfService;
            var nonce = csrfService.initialize();
            var redirectRequest = adobeIdData.createReAuthenticateRedirectRequest(requestedParameters, contextToBePassedOnRedirect, nonce, reauth);
            new SignInService_1.SignInService().signIn(redirectRequest);
        };
        /**
         * sign in with social providers
         * @param providerName provider name used for sign in
         * @param externalParameters external parameters sent by developer
         * @param contextToBePassedOnRedirect {Object} state of the application
         */
        this.signInWithSocialProvider = function (providerName, externalParameters, contextToBePassedOnRedirect) {
            if (externalParameters === void 0) { externalParameters = {}; }
            if (!providerName) {
                throw new Error('please provide the provider name');
            }
            var _a = _this, adobeIdData = _a.adobeIdData, csrfService = _a.csrfService;
            var nonce = csrfService.initialize();
            var authorizeRequestData = adobeIdData.createSocialProviderRedirectRequest(providerName, externalParameters, contextToBePassedOnRedirect, nonce);
            new SignInService_1.SignInService().signIn(authorizeRequestData);
        };
        /**
         *  Method used for sign out the user
         *
         * <uml>
         * start
         * :Signout;
         * :Create the redirect url;
         * :remove the token and profile from storage;
         * :initialize method is used which will redirect the app to initial url;
         * end
         * </uml>
         *
         * @param externalParameters {Object} object sent from outside in order to have the possibility to override the default values when the redirect uri is created
         *
        */
        this.signOut = function (externalParameters) {
            if (externalParameters === void 0) { externalParameters = {}; }
            _this.tokenService.purge();
            _this.profileService.removeProfile();
            var _a = _this.adobeIdData, _b = _a.api_parameters, apiParameters = _b === void 0 ? {} : _b, clientId = _a.client_id, adobeIdRedirectUri = _a.redirect_uri;
            var redirectRequest = {
                adobeIdRedirectUri: adobeIdRedirectUri,
                apiParameters: apiParameters,
                clientId: clientId,
                externalParameters: externalParameters,
            };
            var signOutService = new SignOutService_1.SignOutService();
            signOutService.signOut(redirectRequest);
        };
        /**
         * Refresh the existing token.
         *
         * <uml>
         * start
         * :refreshToken;
         * :call backend: ims/check/v4/token?client_id;
         * :read the token and profile;
         * :triggerOnAccessToken;
         * if (profile) then (yes)
         * else (nothing)
         * :call backend to get the profile ;
         * endif
         * end
         * </uml>
         *
         * @param externalParameters {Object} external parameters sent from outside of the library
         * Note: if refresh token API fails, the triggerOnAccessTokenHasExpired will be triggered
        */
        this.refreshToken = function (externalParameters) {
            if (externalParameters === void 0) { externalParameters = {}; }
            return _this.tokenService.refreshToken(externalParameters)
                .then(function (tokenResponse) { return _this.onTokenProfileReceived(tokenResponse); })
                .catch(function (ex) {
                Log_1.default.error('refresh token error', ex);
                if (ex instanceof HttpErrorResponse_1.HttpErrorResponse) {
                    return Promise.reject(ex);
                }
                if (ex instanceof RideException_1.RideException) {
                    if (ex.jump) {
                        UrlHelper_1.default.replaceUrl(ex.jump);
                        return Promise.reject(ex);
                    }
                    return Promise.reject(ex);
                }
                _this.profileService.removeProfile();
                _this.onTokenExpired();
                return Promise.reject(ex);
            });
        };
        /**
         * retreive a new token and profile for the input user id
         * @param externalParameters {Object} external parameters sent from outside of the library
         * @param userId {String} represents the user id used to get the new token and profile
         */
        this.switchProfile = function (userId, externalParameters) {
            if (externalParameters === void 0) { externalParameters = {}; }
            if (!userId) {
                return Promise.reject(new Error('Please provide the user id for switchProfile'));
            }
            return _this.tokenService.switchProfile(userId, externalParameters)
                .then(function (tokenResponse) { return _this.onTokenProfileReceived(tokenResponse); })
                .catch(function (ex) {
                if (ex instanceof HttpErrorResponse_1.HttpErrorResponse) {
                    return Promise.reject(ex);
                }
                if (ex instanceof RideException_1.RideException) {
                    if (ex.jump) {
                        UrlHelper_1.default.replaceUrl(ex.jump);
                        return Promise.reject(ex);
                    }
                    return Promise.reject(ex);
                }
                return Promise.reject(ex);
            });
        };
        /**
         *
         * @param instance { AdobeIMS } instance of AdobeIMS
         */
        this.triggerOnImsInstance = function (instance) {
            var evt = document.createEvent("CustomEvent");
            var evtData = {
                clientId: _this.adobeIdData.client_id,
                instance: instance,
            };
            evt.initCustomEvent(ImsConstants_1.ON_IMSLIB_INSTANCE, false, false, evtData);
            window.dispatchEvent(evt);
        };
        /**
           * process the initialize exception;
           * this method is the first method called in case there was an error during initialize flow;
           * check if the exception type is TokenExpiredException and pass the flow to the verifyCsrfException
           * @param initializeException represent the exception received during the initialize
           */
        this.processInitializeException = function (initializeException) {
            if (initializeException === void 0) { initializeException = {}; }
            var handlers = _this.adobeIdData.handlers;
            Log_1.default.warn('initialize', initializeException);
            _this.restoreHash();
            if (initializeException instanceof TokenExpiredException_1.TokenExpiredException) {
                handlers.triggerOnAccessTokenHasExpired();
            }
            return Promise.reject(initializeException);
        };
        /**
         * method called in case of exception on initialize.  if error is RideError, ir redirects to the jump url from RideException.jump
         */
        this.verifyRideErrorException = function (ex) {
            if (ex instanceof RideException_1.RideException && ex.jump) {
                UrlHelper_1.default.replaceUrl(ex.jump);
            }
            return Promise.reject(ex);
        };
        /**
         * method called in case of exception on initialize.  if error type is CSRF, it calls the signOut methods
         */
        this.verifyCsrfException = function (ex) {
            var errorType = ex.type;
            if (errorType && errorType === IErrorType_1.IErrorType.CSRF) {
                _this.signOut();
            }
            return Promise.reject(ex);
        };
        /**
         * method called after a successful call to the getTokenAndProfile method in order to process the token response
         * tokenProfile: TokenProfileResponse - contains the token fields and eventually the user profile
         * @returns Promise
         */
        this.processTokenResponse = function (tokenProfile) {
            var handlers = _this.adobeIdData.handlers;
            var tokenFields = tokenProfile.tokenFields, profile = tokenProfile.profile;
            var token = tokenFields.tokenValue, state = tokenFields.state, expire = tokenFields.expire, sid = tokenFields.sid, userId = tokenFields.user_id, _a = tokenFields.other, other = _a === void 0 ? {} : _a;
            Log_1.default.info('token', token);
            if (other.from_ims) {
                UrlHelper_1.default.setHash(other.old_hash || '');
            }
            _this.profileService.removeProfileIfOtherUser(userId);
            var notificationData = { token: token, expire: expire, sid: sid };
            tokenFields.isReauth() ? handlers.triggerOnReauthAccessToken(notificationData) : _this.tokenReceived(notificationData);
            if (profile) {
                _this.profileService.saveProfileToStorage(profile);
            }
            return Promise.resolve(state);
        };
        this.adobeIdData = new AdobeIdData_1.AdobeIdData(adobeData);
        var _a = this.adobeIdData, _b = _a.api_parameters, apiParameters = _b === void 0 ? {} : _b, clientId = _a.client_id, scope = _a.scope, useLocalStorage = _a.useLocalStorage, autoValidateToken = _a.autoValidateToken, handlers = _a.handlers;
        this.imsApis = new ImsApis_1.ImsApis(apiParameters);
        this.csrfService = new CsrfService_1.CsrfService(clientId);
        this.serviceRequest = {
            clientId: clientId,
            scope: scope,
            imsApis: this.imsApis
        };
        this.tokenService = new TokenService_1.TokenService(__assign(__assign({}, this.serviceRequest), { useLocalStorage: useLocalStorage,
            autoValidateToken: autoValidateToken }), this.csrfService);
        this.profileService = new ProfileService_1.ProfileService(this.serviceRequest);
    }
    Object.defineProperty(AdobeIMS.prototype, "version", {
        /**
         * represents the adobe ims library version
         */
        get: function () {
            return Environment_1.default.jslibver;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(AdobeIMS.prototype, "adobeid", {
        /**
         * AdobeIdData
         * the values for adobeId are read from window.adobeid or passed by using the constructor
        */
        get: function () {
            return __assign({}, this.adobeIdData);
        },
        enumerable: true,
        configurable: true
    });
    /**
     * enable the logging mechanism
     */
    AdobeIMS.prototype.enableLogging = function () {
        Log_1.default.enableLogging();
    };
    /**
     * disable the logging mechanism
     */
    AdobeIMS.prototype.disableLogging = function () {
        Log_1.default.disableLogging();
    };
    /**
     * Method used to redirect the user to the signup screen
     *
     * <uml>
     * start
     * :Create the state object by using appCode, appVersion (used on server side) from adobeId.analytics and contextToBePassedOnRedirect;
     * :Create the redirect url using external parameters. state object will be part of redirect url;
     * :SignUp;
     * :initialize method is used which will trigger the token and profile;
     * end
     *
     * </uml>
     *
     * @param requestedParameters object sent from outside in order to use diferent values for signUp
     * @param contextToBePassedOnRedirect {any | undefined} represents the context which is passed during redirect
     *
    */
    AdobeIMS.prototype.signUp = function (requestedParameters, contextToBePassedOnRedirect) {
        if (requestedParameters === void 0) { requestedParameters = {}; }
        var _a = this, adobeIdData = _a.adobeIdData, csrfService = _a.csrfService;
        if (!adobeIdData) {
            throw new Error('no adobeId on reAuthenticate');
        }
        var nonce = csrfService.initialize();
        var redirectRequest = adobeIdData.createSignUpRedirectRequest(requestedParameters, contextToBePassedOnRedirect, nonce);
        new SignInService_1.SignInService().signIn(redirectRequest);
    };
    /**
     * @function Method used to check if the user is signed in or not.
     * if local storage contains a token and is validated (only against expiration), the result is true
     * returns {boolean}
    */
    AdobeIMS.prototype.isSignedInUser = function () {
        return this.getAccessToken() ? true : false;
    };
    /**
     * @function Method used to get the user profile in case the user is logged)
     * returns {IDictionary | null}  representing the user profile or null
    */
    AdobeIMS.prototype.getProfile = function () {
        var _this = this;
        var profile = this.profileService.getProfileFromStorage();
        if (profile) {
            return Promise.resolve(profile);
        }
        var tokenInfo = this.getAccessToken();
        if (!tokenInfo) {
            var profileException = 'please login before getting the profile';
            return Promise.reject(new ProfileException_1.ProfileException(profileException));
        }
        return this.profileService.getProfile(tokenInfo.token).then(function (profile) {
            return Promise.resolve(profile);
        })
            .catch(function (ex) {
            Log_1.default.error('get profile exception ', ex);
            if (!(ex instanceof HttpErrorResponse_1.HttpErrorResponse)) {
                return Promise.reject(new ProfileException_1.ProfileException(ex.message || ex));
            }
            return _this.refreshToken().then(function (tokenResponse) {
                return Promise.resolve(tokenResponse.profile);
            });
        });
    };
    /**
     * @function Returns the URL of the user avatar
     * @param {UserId} userId
    */
    AdobeIMS.prototype.avatarUrl = function (userId) {
        return this.imsApis.avatarUrl(userId);
    };
    /**
      * method used to retrieve the token release flags
    */
    AdobeIMS.prototype.getReleaseFlags = function () {
        return this.tokenService.getReleaseFlags();
    };
    /**
      *
      * Returns the access token value from the local storage
      *
      * <uml>
      * start
      * :getAccessToken;
      * :check the local storage;
      * :if token exists, it is validated agains expiration;
      * :if valid the token is returned otherwise an empty token;
      * end
      * </uml>
      *
    */
    AdobeIMS.prototype.getAccessToken = function () {
        var tokenFields = this.tokenService.getTokenFieldsFromStorage();
        if (!tokenFields) {
            return null;
        }
        var token = tokenFields.tokenValue, expire = tokenFields.expire, sid = tokenFields.sid;
        return { token: token, expire: expire, sid: sid };
    };
    /**
     *
     * Returns the reauth access token value from the local storage
     *
     * <uml>
     * start
     * :getReauthAccessToken;
     * :check the local storage;
     * :if token exists, it is validated agains expiration;
     * :if valid the token is returned otherwise an empty token;
     * end
     * </uml>
     *
   */
    AdobeIMS.prototype.getReauthAccessToken = function () {
        var tokenFields = this.tokenService.getTokenFieldsFromStorage(true);
        if (!tokenFields) {
            return null;
        }
        var token = tokenFields.tokenValue, expire = tokenFields.expire, sid = tokenFields.sid;
        return { token: token, expire: expire, sid: sid };
    };
    /**
     * method used to get the social providers.
     * returns Promise - can be used to determine when the call has been ended and read the social providers response
     */
    AdobeIMS.prototype.listSocialProviders = function () {
        var _this = this;
        return new Promise(function (resolve, reject) {
            var client_id = _this.adobeIdData.client_id;
            _this.imsApis.listSocialProviders({
                client_id: client_id,
            }).then(function (response) {
                resolve(response);
            })
                .catch(function (ex) {
                reject(ex);
            });
        });
    };
    /**
     *
     * @param token {string} represents the access token
     * @param expire {Date} the date when the token will expire
     */
    AdobeIMS.prototype.tokenReceived = function (tokenInfo) {
        var handlers = this.adobeIdData.handlers;
        handlers.triggerOnAccessToken(tokenInfo);
        TokenAutoRefresh_1.default.startAutoRefreshFlow({
            expire: tokenInfo.expire,
            refreshTokenMethod: this.refreshToken,
        });
    };
    /**
     * method used to process the token and profile
     * @param tokenResponse {IRefreshTokenResponse} represents the token and profile received from back-end
     */
    AdobeIMS.prototype.onTokenProfileReceived = function (tokenResponse) {
        var tokenInfo = tokenResponse.tokenInfo, profile = tokenResponse.profile;
        Log_1.default.info('token', tokenInfo);
        this.tokenReceived(tokenInfo);
        this.profileService.saveProfileToStorage(profile);
        return Promise.resolve(tokenResponse);
    };
    /**
     * @returns a promise which is resolved as true in case the token is valid otherwise false
     * validate the existing token;
     */
    AdobeIMS.prototype.validateToken = function () {
        var _this = this;
        return this.tokenService.validateToken().then(function () {
            return Promise.resolve(true);
        })
            .catch(function (ex) {
            Log_1.default.warn('validate token exception', ex);
            if (ex instanceof HttpErrorResponse_1.HttpErrorResponse) {
                return Promise.reject(false);
            }
            _this.profileService.removeProfile();
            return Promise.reject(false);
        });
    };
    /**
     * method used in case the existent token has expired
     */
    AdobeIMS.prototype.onTokenExpired = function () {
        var handlers = this.adobeIdData.handlers;
        this.tokenService.purge();
        handlers.triggerOnAccessTokenHasExpired();
    };
    /**
     * set a new token into the local storage
     * @param tokenInfo {tokenInfo} represents the token/ expire information used by library
     */
    AdobeIMS.prototype.setStandAloneToken = function (standaloneToken) {
        return this.tokenService.setStandAloneToken(standaloneToken);
    };
    /**
     * Method called on library initialization or page reloading
     * <uml>
     * start
     * :initialize method;
     * :get token;
     * if (fragment) then (yes)
     * :returns the token from fragment;
     * else (check local storage)
     * :returns the token from local storage;
     * endif
     * :if no token: return triggerOnAccessTokenHasExpired;
     * :triggerOnAccessToken;
     * :back-end: calls getProfile ;
     * :triggerOnReady ;
     * end
     * </uml>
     *
     * Note: this method is automatically called on every page reload;
    */
    AdobeIMS.prototype.initialize = function () {
        var _this = this;
        var _a = this.adobeIdData, handlers = _a.handlers, standalone = _a.standalone;
        var state = '';
        if (standalone) {
            this.setStandAloneToken(standalone);
        }
        return this.tokenService.getTokenAndProfile()
            .then(this.processTokenResponse, function (ex) { return _this.processInitializeException(ex)
            .catch(function (ex) { return _this.verifyRideErrorException(ex); })
            .catch(function (ex) { return _this.verifyCsrfException(ex)
            .catch(function (ex) { return Log_1.default.info('initialize exception ended', ex); }); }); })
            .then(function (stateValue) {
            state = stateValue;
        })
            .finally(function () {
            Log_1.default.info('onReady initialization');
            window.addEventListener(ImsConstants_1.ASK_FOR_IMSLIB_INSTANCE_DOM_EVENT_NAME, function () {
                _this.triggerOnImsInstance(_this);
            }, false);
            var context = state ? JSON.parse(state).context : null;
            handlers.triggerOnReady(context);
            _this.triggerOnImsInstance(_this);
            Promise.resolve(context);
        });
    };
    /**
     * restore the window hash value to the initial one
     */
    AdobeIMS.prototype.restoreHash = function () {
        var fragmentValues = FragmentHelper_1.default.fragmentToObject();
        if (!fragmentValues || !fragmentValues.from_ims) {
            return;
        }
        UrlHelper_1.default.setHash(fragmentValues.old_hash || '');
    };
    /**
     * Exchange the user's access_token for a Transitory Access Code (TAC) for target client and scope
     * @see {@link https://wiki.corp.adobe.com/display/ims/Transitory+Authorization+Codes |Transitory Authorization Codes}
     * @param tacRequest {ITransitoryAuthorizationRequest}
     * @param externalParameters {IDictionary}
     */
    AdobeIMS.prototype.getTransitoryAuthorizationCode = function (tacRequest, externalParameters) {
        if (externalParameters === void 0) { externalParameters = {}; }
        tacRequest = tacRequest || {};
        tacRequest.response_type = tacRequest.response_type || 'code';
        tacRequest.target_client_id = tacRequest.target_client_id || this.adobeIdData.client_id;
        tacRequest.target_scope = tacRequest.target_scope || this.adobeIdData.scope;
        return this.imsApis.getTransitoryAuthorizationCode(tacRequest, externalParameters, this.adobeIdData.client_id);
    };
    return AdobeIMS;
}());
exports.AdobeIMS = AdobeIMS;
