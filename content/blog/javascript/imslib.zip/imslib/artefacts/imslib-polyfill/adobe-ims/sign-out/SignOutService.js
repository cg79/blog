"use strict";
var __assign = (this && this.__assign) || function () {
    __assign = Object.assign || function(t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
            s = arguments[i];
            for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p))
                t[p] = s[p];
        }
        return t;
    };
    return __assign.apply(this, arguments);
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
var RedirectHelper_1 = require("../helpers/RedirectHelper");
var UrlHelper_1 = __importDefault(require("../../url/UrlHelper"));
var Environment_1 = __importDefault(require("../environment/Environment"));
/**
 * command responsable for user sign out
 */
var SignOutService = /** @class */ (function () {
    function SignOutService() {
        /**
         * @param {IRedirectRequest} redirectRequest. contains all the necessary properties necessary for sign out
         */
        this.signOut = function (redirectRequest) {
            var apiName = 'logout';
            // eslint-disable-next-line @typescript-eslint/camelcase
            var apiParameters = redirectRequest.apiParameters, externalParameters = redirectRequest.externalParameters, _a = redirectRequest.adobeIdRedirectUri, adobeIdRedirectUri = _a === void 0 ? '' : _a, clientId = redirectRequest.clientId;
            var apiExternalParams = RedirectHelper_1.RedirectHelper.mergeApiParamsWithExternalParams(apiParameters, externalParameters, apiName);
            var redirectUrl = RedirectHelper_1.RedirectHelper.createDefaultRedirectUrl(adobeIdRedirectUri, clientId, apiExternalParams, apiName);
            var parameters = __assign(__assign({}, apiExternalParams), { client_id: clientId, redirect_uri: redirectUrl, jslVersion: Environment_1.default.jslibver });
            var queryStrings = UrlHelper_1.default.uriEncodeData(parameters);
            var url = Environment_1.default.baseUrlAdobe + "/ims/logout/v1?" + queryStrings;
            UrlHelper_1.default.replaceUrl(url);
        };
    }
    return SignOutService;
}());
exports.SignOutService = SignOutService;
