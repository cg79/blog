
export { AdobeIMS } from './adobe-ims/AdobeIMS';
export { AdobeIMS as AdobeIMSPolyfill } from './adobe-ims/AdobeIMSPolyfill';

export { AdobeIMSThin } from './adobe-ims/AdobeIMSThin';
export { AdobeIMSThin as AdobeIMSThinPolyfill } from './adobe-ims/AdobeIMSThinPolyfill';
