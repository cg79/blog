import { IDictionary } from './../facade/IDictionary';
/**
 * class used to store the helper functions
 */
declare class ApiHelpers {
    /**
   * Checks [adobeid.api_parameters]{@link adobeid} for custom parameters for an API.
   * @param apiName - represents the used api name
   * @param apiParameters - represents the parameters set from outside for api endpoints read from adobeId
   * @returns {!Object}
   */
    getCustomApiParameters: (apiParameters: any, apiName: string) => IDictionary;
    /**
     *
     * @param externalParameters external parameters received outside of the library
     * @param apiParameters the api parameters from AdobeId data
     * @param apiName api name
     * @returns IDictionary representing the merged properties
     */
    mergeExternalParameters(externalParameters: IDictionary, apiParameters: any, apiName: string): IDictionary;
    /***
     * @param value {String} represents the
     */
    toJson(value: string): object | null;
}
declare const _default: ApiHelpers;
export default _default;
