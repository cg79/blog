import PopupOpener from '../../src/adobe-ims/sign-in/PopupOpener';
import { PopupSettings } from '../../src/adobe-ims/sign-in/PopupSettings';

describe( 'popup opener', () => {

    beforeEach( function () {
        jasmine.createSpy( "timerCallback" );
        jasmine.clock().install();
    } );

    afterEach( function () {
        jasmine.clock().uninstall();
    } );
    
    it( 'should call the onPopupMessage', () => {
        let popupMessage;
        const onPopupMessage = ( info ) => {
            popupMessage = info;
        };

        const modalSettings = new PopupSettings( {} );
        PopupOpener.openSignInWindow( 'testurl', 'nonce', modalSettings, onPopupMessage );
        
        PopupOpener.receiveMessage( {
            origin: 'http://localhost:9235',
            data: 'test',
        } );

        expect( popupMessage ).toEqual( "test" );
    } );

    it( 'should call the onPopupMessage only one time', () => {
        let popupMessage = 0;
        const onPopupMessage = ( info ) => {
            popupMessage++;
        };

        const modalSettings = new PopupSettings( {} );
        PopupOpener.openSignInWindow( 'testurl', 'nonce', modalSettings, onPopupMessage );
        PopupOpener.openSignInWindow( 'testurl', 'nonce', modalSettings, onPopupMessage );
        PopupOpener.openSignInWindow( 'testurl', 'nonce', modalSettings, onPopupMessage );
        
        window.postMessage( 'href', '*' );

        jasmine.clock().tick( 10 );
        expect( popupMessage ).toEqual( 1 );
        
    } );
    
} );
