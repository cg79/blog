
import TokenAutoRefresh from '../../src/adobe-ims/token-auto-refresh/TokenAutoRefresh';
import { ITokenAutoRefreshParams } from '../../src/adobe-ims/token-auto-refresh/ITokenAutoRefreshParams';
import DomEvents from '../helpers/DomEvents';
const ONE_MIN = 60000;


const timeElapsed = ( ms ): void => {
    jasmine.clock().tick( ms );
}

describe( 'Token auto refresh', () => {

    beforeEach( function () {
        jasmine.clock().install();

        jasmine.clock().mockDate( new Date() );
    } );

    afterEach( function () {
        jasmine.clock().uninstall();
    } );

    it( 'refresh method is not called if no user interaction', () => {
        let refreshCalled = false;
        const refresh = () => {
            refreshCalled = true;
        }
        const refreshParameters: ITokenAutoRefreshParams = {
            expire: new Date( Date.now() + 20 * ONE_MIN ),
            refreshTokenMethod: refresh,
        }
        TokenAutoRefresh.startAutoRefreshFlow( refreshParameters );

        timeElapsed( 21 * ONE_MIN );

        expect( refreshCalled ).toEqual( false );
    } );

    it( 'refresh method is not called if no user interaction for the last 15 minutes', () => {
        let refreshCalled = false;
        const refresh = () => {
            refreshCalled = true;
        }
        const refreshParameters: ITokenAutoRefreshParams = {
            expire: new Date( Date.now() + 20 * ONE_MIN ),
            refreshTokenMethod: refresh,
        }
        TokenAutoRefresh.startAutoRefreshFlow( refreshParameters );

        timeElapsed( 1 * ONE_MIN );
        DomEvents.simulateMouseMove( window.document )

        expect( refreshCalled ).toEqual( false );
    } );

    it( 'refresh method it is not called if user interacted for the last 15 minutes AND is not the last expiration minute ', () => {
        let refreshCalled = false;
        const refresh = () => {
            refreshCalled = true;
        }
        const refreshParameters: ITokenAutoRefreshParams = {
            expire: new Date( Date.now() + 20 * ONE_MIN ),
            refreshTokenMethod: refresh,
        }
        TokenAutoRefresh.startAutoRefreshFlow( refreshParameters );

        timeElapsed( 15 * ONE_MIN );
        DomEvents.simulateMouseMove( window.document )

        expect( refreshCalled ).toEqual( false );
    } );

    it( 'refresh method IT IS called if user interacted for the last 15 minutes AND it is the last minute', () => {
        
        let originalClickValue = 0;
        window.document.onmousemove = function () {
            originalClickValue++;
        };

        let refreshCalled = false;

        const refresh = () => {
            refreshCalled = true;
        }
        const refreshParameters: ITokenAutoRefreshParams = {
            expire: new Date( Date.now() + 20 * ONE_MIN ),
            refreshTokenMethod: refresh,
        }

        TokenAutoRefresh.startAutoRefreshFlow( refreshParameters );

        timeElapsed( 15 * ONE_MIN );

        DomEvents.simulateMouseMove( window.document )

        expect( refreshCalled ).toEqual( false );

        expect( originalClickValue ).toEqual( 1 );
        expect( window.document.onmousemove ).not.toBe( null );

        timeElapsed( 4.1 * ONE_MIN );
        expect( refreshCalled ).toEqual( true );

    } );

} );
