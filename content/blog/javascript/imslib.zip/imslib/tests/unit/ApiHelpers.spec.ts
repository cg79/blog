import ApiHelpers from "../../src/api-helpers/ApiHelpers";

describe( "getCustomApiParameters", () => {

    it( 'getCustomApiParameters returns empty object', () => {

        const apiParameters = {
            test: 1,
        };
        const response = ApiHelpers.getCustomApiParameters( apiParameters, 'something' );
        expect( response ).toEqual( {} )

    } )

    it( 'getCustomApiParameters returns partial values', () => {

        const apiParameters = {
            test: 1,
            othter: {},
        };
        const response = ApiHelpers.getCustomApiParameters( apiParameters, 'es' );
        expect( response ).toEqual( { test: 1 } )

    } )

    it( 'getCustomApiParameters returns all mathed keys', () => {

        const apiParameters = {
            keytest: 1,
            keyothter: { day: 1 },
        };
        const response = ApiHelpers.getCustomApiParameters( apiParameters, 'key' );
        expect( response ).toEqual( apiParameters )

    } )

} );

describe( "mergeExternalParameters", () => {

    it( 'mergeExternalParameters returns empty object', () => {

        const externalParameters = {};

        const apiParameters = {
            test: 1,
        };
        const response = ApiHelpers.mergeExternalParameters( externalParameters, apiParameters, 'something' );
        expect( response ).toEqual( {} )

    } )

    it( 'getCustomApiParameters returns partial values', () => {

        const externalParameters = {};

        const apiParameters = {
            test: 1,
            othter: {},
        };
        const response = ApiHelpers.mergeExternalParameters( externalParameters, apiParameters, 'es' );
        expect( response ).toEqual( { test: 1 } )

    } )

    it( 'getCustomApiParameters returns all mathed keys', () => {

        const externalParameters = { external: true };
        const apiParameters = {
            keytest: 1,
            keyothter: { day: 1 },
        };
        const response = ApiHelpers.mergeExternalParameters( externalParameters, apiParameters, 'key' );
        expect( response ).toEqual( {
            ...externalParameters,
            ...apiParameters
        } )

    } )

} );