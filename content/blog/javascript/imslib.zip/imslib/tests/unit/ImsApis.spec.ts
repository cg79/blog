import { ImsApis } from './../../src/ims-apis/ImsApis';

import Debouncer from '../../src/debounce/Debouncer';
import { HttpErrorResponse } from '../../src/error-handlers/HttpErrorResponse';
import Xhr from '../../src/ims-apis/xhr/Xhr';
import ImsXhr from '../../src/ims-apis/xhr/ImsXhr';
import Environment from '../../src/adobe-ims/environment/Environment';

const imsApi = new ImsApis( );
const VALIDATE_TOKEN_API = 'https://ims-na1-stg1.adobelogin.com/ims/validate_token/v1';

describe( 'Ims Apis', () => {

    beforeEach( function () {
        spyOn( Debouncer, 'getCachedApiResponse' ).and.callFake( () => null );
    } )


    it( 'list social providers', ( done ) => {

        const response = [1, 2, 3];
        spyOn( Xhr, 'get' ).and.callFake( function ( url: string, config: any = {} ) {
            return Promise.resolve( {
                status: 200,
                data: response
            } );
        } );

        imsApi.listSocialProviders( {
            client_id: 'IMSLibJSTestClient'
        } )
            .then ( v => {
                expect( v ).toEqual( response );
                done();
            } )
       
    } )

    it( 'validateToken', ( done ) => {

        spyOn( Xhr, 'post' ).and.callFake( function ( url: string, data: any, config: any = {} ) {
            return Promise.resolve( {
                status: 200,
                data: {}
            } );
        } );

        imsApi.validateToken( {
            token: 'token',
            client_id: 'IMSLibJSTestClient'
        } ).then( v => {
            expect( v ).toEqual( {} )
            done();
        } )
        
    } )

    it( 'get profile', ( done ) => {

        spyOn( Xhr, 'get' ).and.callFake( function ( url: string, config: any = {} ) {
            return Promise.resolve( {
                status: 200,
                data: {}
            } );
        } );

        imsApi.getProfile( {
            token: 'token',
            client_id: 'IMSLibJSTestClient'
        } ).then ( v => {
            expect( v ).toEqual( {} );
            done();
        } )
     
    } )

    it( 'getUserInfo', ( done ) => {
        spyOn( Xhr, 'get' ).and.callFake( function ( url: string, config: any = {} ) {
            return Promise.resolve( {
                status: 200,
                data: {}
            } );
        } );

        imsApi.getUserInfo( {
            token: 'token',
            client_id: 'IMSLibJSTestClient'
        } ).then ( v => {
            expect( v ).toEqual( {} );
            done();
        } )
     
    } )


    it( 'logoutToken', ( done ) => {
        spyOn( Xhr, 'post' ).and.callFake( function ( url: string, data,  config: any = {} ) {
            return Promise.resolve( {
                status: 200,
                data: {}
            } );
        } );

        imsApi.logoutToken( {
            token: 'token',
            client_id: 'IMSLibJSTestClient'
        } ).then ( v => {
            expect( v ).toEqual( {} );
            done();
        } )
     
    } )
    

    it( 'checkStatus', ( done ) => {
        spyOn( Xhr, 'get' ).and.callFake( function ( url: string,  config: any = {} ) {
            return Promise.resolve( {
                status: 200,
                data: {}
            } );
        } );

        imsApi.checkStatus().then ( v => {
            expect( v ).toEqual( {} );
            done();
        } )
     
    } )


    it( 'checkToken', ( done ) => {
        spyOn( Xhr, 'post' ).and.callFake( function ( url: string, data, config: any = {} ) {
            return Promise.resolve( {
                status: 200,
                data: {}
            } );
        } );

        imsApi.checkToken( {
            client_id: 'IMSLibJSTestClient'
        }, {
            test: 1
        },
        'scope' ).then ( v => {
            expect( v ).toEqual( {} );
            done();
        } )
     
    } )

    it( 'checkToken with user_id', ( done ) => {
        spyOn( Xhr, 'post' ).and.callFake( function ( url: string, data, config: any = {} ) {
            return Promise.resolve( {
                status: 200,
                data: {}
            } );
        } );

        const xhrPostSpy = spyOn( ImsXhr, 'post' ).and.callThrough();

        const url = `https://adobeid-na1-stg1.services.adobe.com/ims/check/v6/token?jslVersion=${Environment.jslibver}`;

        const contentType = { "content-type": 'application/x-www-form-urlencoded;charset=utf-8' };

        imsApi.checkToken( {
            client_id: 'IMSLibJSTestClient',
            scope: 'adobeid',
        }, {
            test: 1
        },
        'userId' ).then ( v => {
            expect( xhrPostSpy ).toHaveBeenCalledWith( url, 'test=1&client_id=IMSLibJSTestClient&scope=adobeid&user_id=userId', contentType );
            done();
        } )
     
    } )


    it( 'switch profile', ( done ) => {
        spyOn( Xhr, 'post' ).and.callFake( function ( url: string, data, config: any = {} ) {
            return Promise.resolve( {
                status: 200,
                data: {}
            } );
        } );

        imsApi.switchProfile( {
            client_id: 'IMSLibJSTestClient'
        }, {
            test: 1
        },
        'clientid' ).then ( v => {
            expect( v ).toEqual( {} );
            done();
        } )
     
    } )

    it( 'listSocialProviders', ( done ) => {
        spyOn( Xhr, 'get' ).and.callFake( function ( url: string,  config: any = {} ) {
            return Promise.resolve( {
                status: 200,
                data: {}
            } );
        } );

        imsApi.listSocialProviders( {
            client_id: 'IMSLibJSTestClient',
        } ).then ( v => {
            expect( v ).toEqual( {} );
            done();
        } )
     
    } )

    it( 'exchangeIjt', ( done ) => {

        const ijtUrl = 'https://adobeid-na1-stg1.services.adobe.com/ims/jump/implicit/ijtvalue?client_id=IMSLibJSTestClient';
        spyOn( Xhr, 'get' ).and.callFake( function ( url: string, config: any = {} ) {
            return Promise.resolve( {
                status: 200,
                data: { age:1 },
            } );

        } );

        imsApi.exchangeIjt( {
            client_id: 'IMSLibJSTestClient'
        }, 'ijtvalue' ).then( v => {
            expect( v ).toEqual( { age: 1 } );
            done();
        } )
            .catch( v => {
                expect( v ).toEqual( { age: 1 } );
                done();
            } )
       
    } )

    it( 'avatarUrl', ( done ) => {
        const url = imsApi.avatarUrl( 'userid' );

        expect( url ).toBe( 'https://ims-na1-stg1.adobelogin.com/ims/avatar/download/userid' );

        done();
    } )

    it( 'validateToken fails and interceptor is called with network error', ( done ) => {

        const imsApis = new ImsApis(  );

        spyOn( Xhr, 'post' ).and.callFake( function () {
            return Promise.reject( {
                error: 'networkError',
                message: 'Network Error',
                code: 0,
                status: 0
            } );
        } )

        imsApis.validateToken( {
            token: 'token',
            client_id: 'IMSLibJSTestClient'
        } ).catch( error => {

            expect( error ).toEqual( new HttpErrorResponse( {
                error: 'networkError',
                message: '',
                retryAfter: 0
            } ) );
            done();
        } );

    } );

    it( 'validateToken fails and interceptor is called with code 429', ( done ) => {

        const imsApis = new ImsApis( );
        spyOn( Xhr, 'post' ).and.callFake( function () {
            return Promise.reject( {
                status: 429,
                data: { header: { retryAfter: 10 } }
            } );
        } )

        imsApis.validateToken( {
            token: 'token',
            client_id: 'IMSLibJSTestClient'
        } ).catch( error => {
            expect( error ).toEqual( new HttpErrorResponse( {
                error: 'rate_limited',
                retryAfter: 10,
            } ) );
            done();
        } );

    } );

    it( 'validateToken fails and interceptor is called with code 5xx', ( done ) => {

        const imsApis = new ImsApis( );
        spyOn( Xhr, 'post' ).and.callFake( function (  url: string, data: any, config: any = {} ) {
            return Promise.reject( {
                status: 500,
                data: {}
            } )

        } );

        imsApis.validateToken( {
            token: 'token',
            client_id: 'IMSLibJSTestClient'
        } ).catch( error => {
            expect( error ).toEqual( new HttpErrorResponse( {
                error: 'server_error',
                code: 500
            } ) );
            done();
        } )

    } );

} );
