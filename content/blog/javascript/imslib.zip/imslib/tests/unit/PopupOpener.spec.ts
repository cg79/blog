import PopupOpener from '../../src/adobe-ims/sign-in/PopupOpener';
import { PopupSettings } from '../../src/adobe-ims/sign-in/PopupSettings';

describe( 'popup opener', () => {

    beforeEach( function () {
        jasmine.createSpy( "timerCallback" );
        jasmine.clock().install();
    } );

    afterEach( function () {
        jasmine.clock().uninstall();
    } );

    it( 'should call the window.open function', () => {
        let popupMessage;
        const onPopupMessage = ( info ) => {
            popupMessage = info;
        };

        const windowOpenSpy = spyOn( window, 'open' ).and.callThrough();

        const modalSettings = new PopupSettings( {} );
        PopupOpener.openSignInWindow( 'testurl', 'nonce', modalSettings, onPopupMessage );
        
        expect( windowOpenSpy ).toHaveBeenCalled();
        
    } );
    
    it( 'no opener', () => {
        let popupMessage;
        let isCloseWindowCalled = false;
        const onPopupMessage = ( info ) => {
            popupMessage = info;
        };

        let wnd;

        spyOn( window, 'open' ).and.callFake( function ( url, popupHaspProp, onPopupMessage ) {
            wnd = {
                close: (): void  => {
                    isCloseWindowCalled = true
                }
            };
            return wnd;
        } );

        const modalSettings = new PopupSettings( {} );
        PopupOpener.openSignInWindow( 'testurl', 'nonce', modalSettings, onPopupMessage );
        
        jasmine.clock().tick( 501 );
        expect( isCloseWindowCalled ).toEqual( false );

        if( wnd ) {
            wnd['nonce'] = 'redirecturl';
        }
        jasmine.clock().tick( 501 );

        expect( popupMessage ).toEqual( 'redirecturl' );
        
    } );
} );
