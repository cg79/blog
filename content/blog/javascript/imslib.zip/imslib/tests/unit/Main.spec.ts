import { AdobeImsFactory, AdobeIMSKey } from "../../src/constants/ImsConstants";
import Main from '../../src/Main';
import { AdobeIMS } from '../../src/adobe-ims/AdobeIMS';

const adobeData = {
    client_id: 'IMSLibJSTestClient',
    locale: 'ro',
    scope: 'AdobeID,openid',

};

describe( "Main", () => {
    it( 'ensure the Main instance is called', () => {
        Main.initialize();
    } )

    it( 'create adobeIms', () => {
        
        const factory = window[AdobeImsFactory];
        expect( factory ).not.toBe( null );

        factory.createIMSLib( adobeData );

        const imsLib: AdobeIMS = window[AdobeIMSKey];
        
        expect( imsLib ).toBeDefined();
        
    } )
} );
