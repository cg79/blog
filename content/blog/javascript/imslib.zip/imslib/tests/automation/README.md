In order to run the automated tests, the server should be started by using the below command
```http-server -S -p 9000```

2. ```run: npm test`` 

3. https://localhost.corp.adobe.com:9000 is the url used for tests



