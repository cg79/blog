
module.exports = {
    'stg1': [
        {
            accounts: [
                {
                    password: "ffwhwnoaJ#",
                    username: "aiur.20-335.adz3nkdp@mail.adobeid.info",
                    account_type: 'type1',
                },
                {
                    password: "vqgdgojbR1",
                    username: "aiur.20-335.tk5lafkt@ims.allowconflict.adobeid.info",
                    account_type: 'type2',
                },
                {
                    password: "gldjrW#1",
                    username: "aiur.20-335.gik5ykhj@testokta3.com",
                    account_type: 'type3',
                }
            ],
            clients: [
                {
                    client_id: "IMSLibJSTestClient",
                    locale: 'en_US',
                    scope: 'AdobeID,openid',
                    environment: 'stg1',
                },
                
            ]
        }
    ],
    'prod': [
        {
            accounts: [
                {
                    password: "insfarsitA2!",
                    username: "aimsdemo@gmail.com",
                    account_type: 'type1',
                }
            ],
            clients: [
                {
                    client_id: "IMSLibJSTestClient",
                    locale: 'en_US',
                    scope: 'AdobeID,openid',
                    environment: 'prod',
                },
                
            ]
        }
    ]
}
