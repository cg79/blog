1. start the server by running the below command 
http-server -S -p 9000

Note: The js source files should be under the release directory

2. access one of the following url's
   2.1: https://localhost:9000

