var roll = (function () {
	var commonjsGlobal = typeof globalThis !== 'undefined' ? globalThis : typeof window !== 'undefined' ? window : typeof global !== 'undefined' ? global : typeof self !== 'undefined' ? self : {};

	function unwrapExports (x) {
		return x && x.__esModule && Object.prototype.hasOwnProperty.call(x, 'default') ? x['default'] : x;
	}

	function createCommonjsModule(fn, module) {
		return module = { exports: {} }, fn(module, module.exports), module.exports;
	}

	var check = function (it) {
	  return it && it.Math == Math && it;
	};

	// https://github.com/zloirock/core-js/issues/86#issuecomment-115759028
	var global_1 =
	  // eslint-disable-next-line no-undef
	  check(typeof globalThis == 'object' && globalThis) ||
	  check(typeof window == 'object' && window) ||
	  check(typeof self == 'object' && self) ||
	  check(typeof commonjsGlobal == 'object' && commonjsGlobal) ||
	  // eslint-disable-next-line no-new-func
	  Function('return this')();

	var fails = function (exec) {
	  try {
	    return !!exec();
	  } catch (error) {
	    return true;
	  }
	};

	// Thank's IE8 for his funny defineProperty
	var descriptors = !fails(function () {
	  return Object.defineProperty({}, 1, { get: function () { return 7; } })[1] != 7;
	});

	var nativePropertyIsEnumerable = {}.propertyIsEnumerable;
	var getOwnPropertyDescriptor = Object.getOwnPropertyDescriptor;

	// Nashorn ~ JDK8 bug
	var NASHORN_BUG = getOwnPropertyDescriptor && !nativePropertyIsEnumerable.call({ 1: 2 }, 1);

	// `Object.prototype.propertyIsEnumerable` method implementation
	// https://tc39.github.io/ecma262/#sec-object.prototype.propertyisenumerable
	var f = NASHORN_BUG ? function propertyIsEnumerable(V) {
	  var descriptor = getOwnPropertyDescriptor(this, V);
	  return !!descriptor && descriptor.enumerable;
	} : nativePropertyIsEnumerable;

	var objectPropertyIsEnumerable = {
		f: f
	};

	var createPropertyDescriptor = function (bitmap, value) {
	  return {
	    enumerable: !(bitmap & 1),
	    configurable: !(bitmap & 2),
	    writable: !(bitmap & 4),
	    value: value
	  };
	};

	var toString = {}.toString;

	var classofRaw = function (it) {
	  return toString.call(it).slice(8, -1);
	};

	var split = ''.split;

	// fallback for non-array-like ES3 and non-enumerable old V8 strings
	var indexedObject = fails(function () {
	  // throws an error in rhino, see https://github.com/mozilla/rhino/issues/346
	  // eslint-disable-next-line no-prototype-builtins
	  return !Object('z').propertyIsEnumerable(0);
	}) ? function (it) {
	  return classofRaw(it) == 'String' ? split.call(it, '') : Object(it);
	} : Object;

	// `RequireObjectCoercible` abstract operation
	// https://tc39.github.io/ecma262/#sec-requireobjectcoercible
	var requireObjectCoercible = function (it) {
	  if (it == undefined) throw TypeError("Can't call method on " + it);
	  return it;
	};

	// toObject with fallback for non-array-like ES3 strings



	var toIndexedObject = function (it) {
	  return indexedObject(requireObjectCoercible(it));
	};

	var isObject = function (it) {
	  return typeof it === 'object' ? it !== null : typeof it === 'function';
	};

	// `ToPrimitive` abstract operation
	// https://tc39.github.io/ecma262/#sec-toprimitive
	// instead of the ES6 spec version, we didn't implement @@toPrimitive case
	// and the second argument - flag - preferred type is a string
	var toPrimitive = function (input, PREFERRED_STRING) {
	  if (!isObject(input)) return input;
	  var fn, val;
	  if (PREFERRED_STRING && typeof (fn = input.toString) == 'function' && !isObject(val = fn.call(input))) return val;
	  if (typeof (fn = input.valueOf) == 'function' && !isObject(val = fn.call(input))) return val;
	  if (!PREFERRED_STRING && typeof (fn = input.toString) == 'function' && !isObject(val = fn.call(input))) return val;
	  throw TypeError("Can't convert object to primitive value");
	};

	var hasOwnProperty = {}.hasOwnProperty;

	var has = function (it, key) {
	  return hasOwnProperty.call(it, key);
	};

	var document$1 = global_1.document;
	// typeof document.createElement is 'object' in old IE
	var EXISTS = isObject(document$1) && isObject(document$1.createElement);

	var documentCreateElement = function (it) {
	  return EXISTS ? document$1.createElement(it) : {};
	};

	// Thank's IE8 for his funny defineProperty
	var ie8DomDefine = !descriptors && !fails(function () {
	  return Object.defineProperty(documentCreateElement('div'), 'a', {
	    get: function () { return 7; }
	  }).a != 7;
	});

	var nativeGetOwnPropertyDescriptor = Object.getOwnPropertyDescriptor;

	// `Object.getOwnPropertyDescriptor` method
	// https://tc39.github.io/ecma262/#sec-object.getownpropertydescriptor
	var f$1 = descriptors ? nativeGetOwnPropertyDescriptor : function getOwnPropertyDescriptor(O, P) {
	  O = toIndexedObject(O);
	  P = toPrimitive(P, true);
	  if (ie8DomDefine) try {
	    return nativeGetOwnPropertyDescriptor(O, P);
	  } catch (error) { /* empty */ }
	  if (has(O, P)) return createPropertyDescriptor(!objectPropertyIsEnumerable.f.call(O, P), O[P]);
	};

	var objectGetOwnPropertyDescriptor = {
		f: f$1
	};

	var anObject = function (it) {
	  if (!isObject(it)) {
	    throw TypeError(String(it) + ' is not an object');
	  } return it;
	};

	var nativeDefineProperty = Object.defineProperty;

	// `Object.defineProperty` method
	// https://tc39.github.io/ecma262/#sec-object.defineproperty
	var f$2 = descriptors ? nativeDefineProperty : function defineProperty(O, P, Attributes) {
	  anObject(O);
	  P = toPrimitive(P, true);
	  anObject(Attributes);
	  if (ie8DomDefine) try {
	    return nativeDefineProperty(O, P, Attributes);
	  } catch (error) { /* empty */ }
	  if ('get' in Attributes || 'set' in Attributes) throw TypeError('Accessors not supported');
	  if ('value' in Attributes) O[P] = Attributes.value;
	  return O;
	};

	var objectDefineProperty = {
		f: f$2
	};

	var createNonEnumerableProperty = descriptors ? function (object, key, value) {
	  return objectDefineProperty.f(object, key, createPropertyDescriptor(1, value));
	} : function (object, key, value) {
	  object[key] = value;
	  return object;
	};

	var setGlobal = function (key, value) {
	  try {
	    createNonEnumerableProperty(global_1, key, value);
	  } catch (error) {
	    global_1[key] = value;
	  } return value;
	};

	var SHARED = '__core-js_shared__';
	var store = global_1[SHARED] || setGlobal(SHARED, {});

	var sharedStore = store;

	var functionToString = Function.toString;

	// this helper broken in `3.4.1-3.4.4`, so we can't use `shared` helper
	if (typeof sharedStore.inspectSource != 'function') {
	  sharedStore.inspectSource = function (it) {
	    return functionToString.call(it);
	  };
	}

	var inspectSource = sharedStore.inspectSource;

	var WeakMap = global_1.WeakMap;

	var nativeWeakMap = typeof WeakMap === 'function' && /native code/.test(inspectSource(WeakMap));

	var shared = createCommonjsModule(function (module) {
	(module.exports = function (key, value) {
	  return sharedStore[key] || (sharedStore[key] = value !== undefined ? value : {});
	})('versions', []).push({
	  version: '3.6.4',
	  mode:  'global',
	  copyright: '© 2020 Denis Pushkarev (zloirock.ru)'
	});
	});

	var id = 0;
	var postfix = Math.random();

	var uid = function (key) {
	  return 'Symbol(' + String(key === undefined ? '' : key) + ')_' + (++id + postfix).toString(36);
	};

	var keys = shared('keys');

	var sharedKey = function (key) {
	  return keys[key] || (keys[key] = uid(key));
	};

	var hiddenKeys = {};

	var WeakMap$1 = global_1.WeakMap;
	var set, get, has$1;

	var enforce = function (it) {
	  return has$1(it) ? get(it) : set(it, {});
	};

	var getterFor = function (TYPE) {
	  return function (it) {
	    var state;
	    if (!isObject(it) || (state = get(it)).type !== TYPE) {
	      throw TypeError('Incompatible receiver, ' + TYPE + ' required');
	    } return state;
	  };
	};

	if (nativeWeakMap) {
	  var store$1 = new WeakMap$1();
	  var wmget = store$1.get;
	  var wmhas = store$1.has;
	  var wmset = store$1.set;
	  set = function (it, metadata) {
	    wmset.call(store$1, it, metadata);
	    return metadata;
	  };
	  get = function (it) {
	    return wmget.call(store$1, it) || {};
	  };
	  has$1 = function (it) {
	    return wmhas.call(store$1, it);
	  };
	} else {
	  var STATE = sharedKey('state');
	  hiddenKeys[STATE] = true;
	  set = function (it, metadata) {
	    createNonEnumerableProperty(it, STATE, metadata);
	    return metadata;
	  };
	  get = function (it) {
	    return has(it, STATE) ? it[STATE] : {};
	  };
	  has$1 = function (it) {
	    return has(it, STATE);
	  };
	}

	var internalState = {
	  set: set,
	  get: get,
	  has: has$1,
	  enforce: enforce,
	  getterFor: getterFor
	};

	var redefine = createCommonjsModule(function (module) {
	var getInternalState = internalState.get;
	var enforceInternalState = internalState.enforce;
	var TEMPLATE = String(String).split('String');

	(module.exports = function (O, key, value, options) {
	  var unsafe = options ? !!options.unsafe : false;
	  var simple = options ? !!options.enumerable : false;
	  var noTargetGet = options ? !!options.noTargetGet : false;
	  if (typeof value == 'function') {
	    if (typeof key == 'string' && !has(value, 'name')) createNonEnumerableProperty(value, 'name', key);
	    enforceInternalState(value).source = TEMPLATE.join(typeof key == 'string' ? key : '');
	  }
	  if (O === global_1) {
	    if (simple) O[key] = value;
	    else setGlobal(key, value);
	    return;
	  } else if (!unsafe) {
	    delete O[key];
	  } else if (!noTargetGet && O[key]) {
	    simple = true;
	  }
	  if (simple) O[key] = value;
	  else createNonEnumerableProperty(O, key, value);
	// add fake Function#toString for correct work wrapped methods / constructors with methods like LoDash isNative
	})(Function.prototype, 'toString', function toString() {
	  return typeof this == 'function' && getInternalState(this).source || inspectSource(this);
	});
	});

	var path = global_1;

	var aFunction = function (variable) {
	  return typeof variable == 'function' ? variable : undefined;
	};

	var getBuiltIn = function (namespace, method) {
	  return arguments.length < 2 ? aFunction(path[namespace]) || aFunction(global_1[namespace])
	    : path[namespace] && path[namespace][method] || global_1[namespace] && global_1[namespace][method];
	};

	var ceil = Math.ceil;
	var floor = Math.floor;

	// `ToInteger` abstract operation
	// https://tc39.github.io/ecma262/#sec-tointeger
	var toInteger = function (argument) {
	  return isNaN(argument = +argument) ? 0 : (argument > 0 ? floor : ceil)(argument);
	};

	var min = Math.min;

	// `ToLength` abstract operation
	// https://tc39.github.io/ecma262/#sec-tolength
	var toLength = function (argument) {
	  return argument > 0 ? min(toInteger(argument), 0x1FFFFFFFFFFFFF) : 0; // 2 ** 53 - 1 == 9007199254740991
	};

	var max = Math.max;
	var min$1 = Math.min;

	// Helper for a popular repeating case of the spec:
	// Let integer be ? ToInteger(index).
	// If integer < 0, let result be max((length + integer), 0); else let result be min(integer, length).
	var toAbsoluteIndex = function (index, length) {
	  var integer = toInteger(index);
	  return integer < 0 ? max(integer + length, 0) : min$1(integer, length);
	};

	// `Array.prototype.{ indexOf, includes }` methods implementation
	var createMethod = function (IS_INCLUDES) {
	  return function ($this, el, fromIndex) {
	    var O = toIndexedObject($this);
	    var length = toLength(O.length);
	    var index = toAbsoluteIndex(fromIndex, length);
	    var value;
	    // Array#includes uses SameValueZero equality algorithm
	    // eslint-disable-next-line no-self-compare
	    if (IS_INCLUDES && el != el) while (length > index) {
	      value = O[index++];
	      // eslint-disable-next-line no-self-compare
	      if (value != value) return true;
	    // Array#indexOf ignores holes, Array#includes - not
	    } else for (;length > index; index++) {
	      if ((IS_INCLUDES || index in O) && O[index] === el) return IS_INCLUDES || index || 0;
	    } return !IS_INCLUDES && -1;
	  };
	};

	var arrayIncludes = {
	  // `Array.prototype.includes` method
	  // https://tc39.github.io/ecma262/#sec-array.prototype.includes
	  includes: createMethod(true),
	  // `Array.prototype.indexOf` method
	  // https://tc39.github.io/ecma262/#sec-array.prototype.indexof
	  indexOf: createMethod(false)
	};

	var indexOf = arrayIncludes.indexOf;


	var objectKeysInternal = function (object, names) {
	  var O = toIndexedObject(object);
	  var i = 0;
	  var result = [];
	  var key;
	  for (key in O) !has(hiddenKeys, key) && has(O, key) && result.push(key);
	  // Don't enum bug & hidden keys
	  while (names.length > i) if (has(O, key = names[i++])) {
	    ~indexOf(result, key) || result.push(key);
	  }
	  return result;
	};

	// IE8- don't enum bug keys
	var enumBugKeys = [
	  'constructor',
	  'hasOwnProperty',
	  'isPrototypeOf',
	  'propertyIsEnumerable',
	  'toLocaleString',
	  'toString',
	  'valueOf'
	];

	var hiddenKeys$1 = enumBugKeys.concat('length', 'prototype');

	// `Object.getOwnPropertyNames` method
	// https://tc39.github.io/ecma262/#sec-object.getownpropertynames
	var f$3 = Object.getOwnPropertyNames || function getOwnPropertyNames(O) {
	  return objectKeysInternal(O, hiddenKeys$1);
	};

	var objectGetOwnPropertyNames = {
		f: f$3
	};

	var f$4 = Object.getOwnPropertySymbols;

	var objectGetOwnPropertySymbols = {
		f: f$4
	};

	// all object keys, includes non-enumerable and symbols
	var ownKeys = getBuiltIn('Reflect', 'ownKeys') || function ownKeys(it) {
	  var keys = objectGetOwnPropertyNames.f(anObject(it));
	  var getOwnPropertySymbols = objectGetOwnPropertySymbols.f;
	  return getOwnPropertySymbols ? keys.concat(getOwnPropertySymbols(it)) : keys;
	};

	var copyConstructorProperties = function (target, source) {
	  var keys = ownKeys(source);
	  var defineProperty = objectDefineProperty.f;
	  var getOwnPropertyDescriptor = objectGetOwnPropertyDescriptor.f;
	  for (var i = 0; i < keys.length; i++) {
	    var key = keys[i];
	    if (!has(target, key)) defineProperty(target, key, getOwnPropertyDescriptor(source, key));
	  }
	};

	var replacement = /#|\.prototype\./;

	var isForced = function (feature, detection) {
	  var value = data[normalize(feature)];
	  return value == POLYFILL ? true
	    : value == NATIVE ? false
	    : typeof detection == 'function' ? fails(detection)
	    : !!detection;
	};

	var normalize = isForced.normalize = function (string) {
	  return String(string).replace(replacement, '.').toLowerCase();
	};

	var data = isForced.data = {};
	var NATIVE = isForced.NATIVE = 'N';
	var POLYFILL = isForced.POLYFILL = 'P';

	var isForced_1 = isForced;

	var getOwnPropertyDescriptor$1 = objectGetOwnPropertyDescriptor.f;






	/*
	  options.target      - name of the target object
	  options.global      - target is the global object
	  options.stat        - export as static methods of target
	  options.proto       - export as prototype methods of target
	  options.real        - real prototype method for the `pure` version
	  options.forced      - export even if the native feature is available
	  options.bind        - bind methods to the target, required for the `pure` version
	  options.wrap        - wrap constructors to preventing global pollution, required for the `pure` version
	  options.unsafe      - use the simple assignment of property instead of delete + defineProperty
	  options.sham        - add a flag to not completely full polyfills
	  options.enumerable  - export as enumerable property
	  options.noTargetGet - prevent calling a getter on target
	*/
	var _export = function (options, source) {
	  var TARGET = options.target;
	  var GLOBAL = options.global;
	  var STATIC = options.stat;
	  var FORCED, target, key, targetProperty, sourceProperty, descriptor;
	  if (GLOBAL) {
	    target = global_1;
	  } else if (STATIC) {
	    target = global_1[TARGET] || setGlobal(TARGET, {});
	  } else {
	    target = (global_1[TARGET] || {}).prototype;
	  }
	  if (target) for (key in source) {
	    sourceProperty = source[key];
	    if (options.noTargetGet) {
	      descriptor = getOwnPropertyDescriptor$1(target, key);
	      targetProperty = descriptor && descriptor.value;
	    } else targetProperty = target[key];
	    FORCED = isForced_1(GLOBAL ? key : TARGET + (STATIC ? '.' : '#') + key, options.forced);
	    // contained in target
	    if (!FORCED && targetProperty !== undefined) {
	      if (typeof sourceProperty === typeof targetProperty) continue;
	      copyConstructorProperties(sourceProperty, targetProperty);
	    }
	    // add a flag to not completely full polyfills
	    if (options.sham || (targetProperty && targetProperty.sham)) {
	      createNonEnumerableProperty(sourceProperty, 'sham', true);
	    }
	    // extend global
	    redefine(target, key, sourceProperty, options);
	  }
	};

	var nativePromiseConstructor = global_1.Promise;

	var redefineAll = function (target, src, options) {
	  for (var key in src) redefine(target, key, src[key], options);
	  return target;
	};

	var nativeSymbol = !!Object.getOwnPropertySymbols && !fails(function () {
	  // Chrome 38 Symbol has incorrect toString conversion
	  // eslint-disable-next-line no-undef
	  return !String(Symbol());
	});

	var useSymbolAsUid = nativeSymbol
	  // eslint-disable-next-line no-undef
	  && !Symbol.sham
	  // eslint-disable-next-line no-undef
	  && typeof Symbol.iterator == 'symbol';

	var WellKnownSymbolsStore = shared('wks');
	var Symbol$1 = global_1.Symbol;
	var createWellKnownSymbol = useSymbolAsUid ? Symbol$1 : Symbol$1 && Symbol$1.withoutSetter || uid;

	var wellKnownSymbol = function (name) {
	  if (!has(WellKnownSymbolsStore, name)) {
	    if (nativeSymbol && has(Symbol$1, name)) WellKnownSymbolsStore[name] = Symbol$1[name];
	    else WellKnownSymbolsStore[name] = createWellKnownSymbol('Symbol.' + name);
	  } return WellKnownSymbolsStore[name];
	};

	var defineProperty = objectDefineProperty.f;



	var TO_STRING_TAG = wellKnownSymbol('toStringTag');

	var setToStringTag = function (it, TAG, STATIC) {
	  if (it && !has(it = STATIC ? it : it.prototype, TO_STRING_TAG)) {
	    defineProperty(it, TO_STRING_TAG, { configurable: true, value: TAG });
	  }
	};

	var SPECIES = wellKnownSymbol('species');

	var setSpecies = function (CONSTRUCTOR_NAME) {
	  var Constructor = getBuiltIn(CONSTRUCTOR_NAME);
	  var defineProperty = objectDefineProperty.f;

	  if (descriptors && Constructor && !Constructor[SPECIES]) {
	    defineProperty(Constructor, SPECIES, {
	      configurable: true,
	      get: function () { return this; }
	    });
	  }
	};

	var aFunction$1 = function (it) {
	  if (typeof it != 'function') {
	    throw TypeError(String(it) + ' is not a function');
	  } return it;
	};

	var anInstance = function (it, Constructor, name) {
	  if (!(it instanceof Constructor)) {
	    throw TypeError('Incorrect ' + (name ? name + ' ' : '') + 'invocation');
	  } return it;
	};

	var iterators = {};

	var ITERATOR = wellKnownSymbol('iterator');
	var ArrayPrototype = Array.prototype;

	// check on default Array iterator
	var isArrayIteratorMethod = function (it) {
	  return it !== undefined && (iterators.Array === it || ArrayPrototype[ITERATOR] === it);
	};

	// optional / simple context binding
	var functionBindContext = function (fn, that, length) {
	  aFunction$1(fn);
	  if (that === undefined) return fn;
	  switch (length) {
	    case 0: return function () {
	      return fn.call(that);
	    };
	    case 1: return function (a) {
	      return fn.call(that, a);
	    };
	    case 2: return function (a, b) {
	      return fn.call(that, a, b);
	    };
	    case 3: return function (a, b, c) {
	      return fn.call(that, a, b, c);
	    };
	  }
	  return function (/* ...args */) {
	    return fn.apply(that, arguments);
	  };
	};

	var TO_STRING_TAG$1 = wellKnownSymbol('toStringTag');
	var test = {};

	test[TO_STRING_TAG$1] = 'z';

	var toStringTagSupport = String(test) === '[object z]';

	var TO_STRING_TAG$2 = wellKnownSymbol('toStringTag');
	// ES3 wrong here
	var CORRECT_ARGUMENTS = classofRaw(function () { return arguments; }()) == 'Arguments';

	// fallback for IE11 Script Access Denied error
	var tryGet = function (it, key) {
	  try {
	    return it[key];
	  } catch (error) { /* empty */ }
	};

	// getting tag from ES6+ `Object.prototype.toString`
	var classof = toStringTagSupport ? classofRaw : function (it) {
	  var O, tag, result;
	  return it === undefined ? 'Undefined' : it === null ? 'Null'
	    // @@toStringTag case
	    : typeof (tag = tryGet(O = Object(it), TO_STRING_TAG$2)) == 'string' ? tag
	    // builtinTag case
	    : CORRECT_ARGUMENTS ? classofRaw(O)
	    // ES3 arguments fallback
	    : (result = classofRaw(O)) == 'Object' && typeof O.callee == 'function' ? 'Arguments' : result;
	};

	var ITERATOR$1 = wellKnownSymbol('iterator');

	var getIteratorMethod = function (it) {
	  if (it != undefined) return it[ITERATOR$1]
	    || it['@@iterator']
	    || iterators[classof(it)];
	};

	// call something on iterator step with safe closing on error
	var callWithSafeIterationClosing = function (iterator, fn, value, ENTRIES) {
	  try {
	    return ENTRIES ? fn(anObject(value)[0], value[1]) : fn(value);
	  // 7.4.6 IteratorClose(iterator, completion)
	  } catch (error) {
	    var returnMethod = iterator['return'];
	    if (returnMethod !== undefined) anObject(returnMethod.call(iterator));
	    throw error;
	  }
	};

	var iterate_1 = createCommonjsModule(function (module) {
	var Result = function (stopped, result) {
	  this.stopped = stopped;
	  this.result = result;
	};

	var iterate = module.exports = function (iterable, fn, that, AS_ENTRIES, IS_ITERATOR) {
	  var boundFunction = functionBindContext(fn, that, AS_ENTRIES ? 2 : 1);
	  var iterator, iterFn, index, length, result, next, step;

	  if (IS_ITERATOR) {
	    iterator = iterable;
	  } else {
	    iterFn = getIteratorMethod(iterable);
	    if (typeof iterFn != 'function') throw TypeError('Target is not iterable');
	    // optimisation for array iterators
	    if (isArrayIteratorMethod(iterFn)) {
	      for (index = 0, length = toLength(iterable.length); length > index; index++) {
	        result = AS_ENTRIES
	          ? boundFunction(anObject(step = iterable[index])[0], step[1])
	          : boundFunction(iterable[index]);
	        if (result && result instanceof Result) return result;
	      } return new Result(false);
	    }
	    iterator = iterFn.call(iterable);
	  }

	  next = iterator.next;
	  while (!(step = next.call(iterator)).done) {
	    result = callWithSafeIterationClosing(iterator, boundFunction, step.value, AS_ENTRIES);
	    if (typeof result == 'object' && result && result instanceof Result) return result;
	  } return new Result(false);
	};

	iterate.stop = function (result) {
	  return new Result(true, result);
	};
	});

	var ITERATOR$2 = wellKnownSymbol('iterator');
	var SAFE_CLOSING = false;

	try {
	  var called = 0;
	  var iteratorWithReturn = {
	    next: function () {
	      return { done: !!called++ };
	    },
	    'return': function () {
	      SAFE_CLOSING = true;
	    }
	  };
	  iteratorWithReturn[ITERATOR$2] = function () {
	    return this;
	  };
	  // eslint-disable-next-line no-throw-literal
	  Array.from(iteratorWithReturn, function () { throw 2; });
	} catch (error) { /* empty */ }

	var checkCorrectnessOfIteration = function (exec, SKIP_CLOSING) {
	  if (!SKIP_CLOSING && !SAFE_CLOSING) return false;
	  var ITERATION_SUPPORT = false;
	  try {
	    var object = {};
	    object[ITERATOR$2] = function () {
	      return {
	        next: function () {
	          return { done: ITERATION_SUPPORT = true };
	        }
	      };
	    };
	    exec(object);
	  } catch (error) { /* empty */ }
	  return ITERATION_SUPPORT;
	};

	var SPECIES$1 = wellKnownSymbol('species');

	// `SpeciesConstructor` abstract operation
	// https://tc39.github.io/ecma262/#sec-speciesconstructor
	var speciesConstructor = function (O, defaultConstructor) {
	  var C = anObject(O).constructor;
	  var S;
	  return C === undefined || (S = anObject(C)[SPECIES$1]) == undefined ? defaultConstructor : aFunction$1(S);
	};

	var html = getBuiltIn('document', 'documentElement');

	var engineUserAgent = getBuiltIn('navigator', 'userAgent') || '';

	var engineIsIos = /(iphone|ipod|ipad).*applewebkit/i.test(engineUserAgent);

	var location = global_1.location;
	var set$1 = global_1.setImmediate;
	var clear = global_1.clearImmediate;
	var process = global_1.process;
	var MessageChannel = global_1.MessageChannel;
	var Dispatch = global_1.Dispatch;
	var counter = 0;
	var queue = {};
	var ONREADYSTATECHANGE = 'onreadystatechange';
	var defer, channel, port;

	var run = function (id) {
	  // eslint-disable-next-line no-prototype-builtins
	  if (queue.hasOwnProperty(id)) {
	    var fn = queue[id];
	    delete queue[id];
	    fn();
	  }
	};

	var runner = function (id) {
	  return function () {
	    run(id);
	  };
	};

	var listener = function (event) {
	  run(event.data);
	};

	var post = function (id) {
	  // old engines have not location.origin
	  global_1.postMessage(id + '', location.protocol + '//' + location.host);
	};

	// Node.js 0.9+ & IE10+ has setImmediate, otherwise:
	if (!set$1 || !clear) {
	  set$1 = function setImmediate(fn) {
	    var args = [];
	    var i = 1;
	    while (arguments.length > i) args.push(arguments[i++]);
	    queue[++counter] = function () {
	      // eslint-disable-next-line no-new-func
	      (typeof fn == 'function' ? fn : Function(fn)).apply(undefined, args);
	    };
	    defer(counter);
	    return counter;
	  };
	  clear = function clearImmediate(id) {
	    delete queue[id];
	  };
	  // Node.js 0.8-
	  if (classofRaw(process) == 'process') {
	    defer = function (id) {
	      process.nextTick(runner(id));
	    };
	  // Sphere (JS game engine) Dispatch API
	  } else if (Dispatch && Dispatch.now) {
	    defer = function (id) {
	      Dispatch.now(runner(id));
	    };
	  // Browsers with MessageChannel, includes WebWorkers
	  // except iOS - https://github.com/zloirock/core-js/issues/624
	  } else if (MessageChannel && !engineIsIos) {
	    channel = new MessageChannel();
	    port = channel.port2;
	    channel.port1.onmessage = listener;
	    defer = functionBindContext(port.postMessage, port, 1);
	  // Browsers with postMessage, skip WebWorkers
	  // IE8 has postMessage, but it's sync & typeof its postMessage is 'object'
	  } else if (global_1.addEventListener && typeof postMessage == 'function' && !global_1.importScripts && !fails(post)) {
	    defer = post;
	    global_1.addEventListener('message', listener, false);
	  // IE8-
	  } else if (ONREADYSTATECHANGE in documentCreateElement('script')) {
	    defer = function (id) {
	      html.appendChild(documentCreateElement('script'))[ONREADYSTATECHANGE] = function () {
	        html.removeChild(this);
	        run(id);
	      };
	    };
	  // Rest old browsers
	  } else {
	    defer = function (id) {
	      setTimeout(runner(id), 0);
	    };
	  }
	}

	var task = {
	  set: set$1,
	  clear: clear
	};

	var getOwnPropertyDescriptor$2 = objectGetOwnPropertyDescriptor.f;

	var macrotask = task.set;


	var MutationObserver = global_1.MutationObserver || global_1.WebKitMutationObserver;
	var process$1 = global_1.process;
	var Promise$1 = global_1.Promise;
	var IS_NODE = classofRaw(process$1) == 'process';
	// Node.js 11 shows ExperimentalWarning on getting `queueMicrotask`
	var queueMicrotaskDescriptor = getOwnPropertyDescriptor$2(global_1, 'queueMicrotask');
	var queueMicrotask = queueMicrotaskDescriptor && queueMicrotaskDescriptor.value;

	var flush, head, last, notify, toggle, node, promise, then;

	// modern engines have queueMicrotask method
	if (!queueMicrotask) {
	  flush = function () {
	    var parent, fn;
	    if (IS_NODE && (parent = process$1.domain)) parent.exit();
	    while (head) {
	      fn = head.fn;
	      head = head.next;
	      try {
	        fn();
	      } catch (error) {
	        if (head) notify();
	        else last = undefined;
	        throw error;
	      }
	    } last = undefined;
	    if (parent) parent.enter();
	  };

	  // Node.js
	  if (IS_NODE) {
	    notify = function () {
	      process$1.nextTick(flush);
	    };
	  // browsers with MutationObserver, except iOS - https://github.com/zloirock/core-js/issues/339
	  } else if (MutationObserver && !engineIsIos) {
	    toggle = true;
	    node = document.createTextNode('');
	    new MutationObserver(flush).observe(node, { characterData: true });
	    notify = function () {
	      node.data = toggle = !toggle;
	    };
	  // environments with maybe non-completely correct, but existent Promise
	  } else if (Promise$1 && Promise$1.resolve) {
	    // Promise.resolve without an argument throws an error in LG WebOS 2
	    promise = Promise$1.resolve(undefined);
	    then = promise.then;
	    notify = function () {
	      then.call(promise, flush);
	    };
	  // for other environments - macrotask based on:
	  // - setImmediate
	  // - MessageChannel
	  // - window.postMessag
	  // - onreadystatechange
	  // - setTimeout
	  } else {
	    notify = function () {
	      // strange IE + webpack dev server bug - use .call(global)
	      macrotask.call(global_1, flush);
	    };
	  }
	}

	var microtask = queueMicrotask || function (fn) {
	  var task = { fn: fn, next: undefined };
	  if (last) last.next = task;
	  if (!head) {
	    head = task;
	    notify();
	  } last = task;
	};

	var PromiseCapability = function (C) {
	  var resolve, reject;
	  this.promise = new C(function ($$resolve, $$reject) {
	    if (resolve !== undefined || reject !== undefined) throw TypeError('Bad Promise constructor');
	    resolve = $$resolve;
	    reject = $$reject;
	  });
	  this.resolve = aFunction$1(resolve);
	  this.reject = aFunction$1(reject);
	};

	// 25.4.1.5 NewPromiseCapability(C)
	var f$5 = function (C) {
	  return new PromiseCapability(C);
	};

	var newPromiseCapability = {
		f: f$5
	};

	var promiseResolve = function (C, x) {
	  anObject(C);
	  if (isObject(x) && x.constructor === C) return x;
	  var promiseCapability = newPromiseCapability.f(C);
	  var resolve = promiseCapability.resolve;
	  resolve(x);
	  return promiseCapability.promise;
	};

	var hostReportErrors = function (a, b) {
	  var console = global_1.console;
	  if (console && console.error) {
	    arguments.length === 1 ? console.error(a) : console.error(a, b);
	  }
	};

	var perform = function (exec) {
	  try {
	    return { error: false, value: exec() };
	  } catch (error) {
	    return { error: true, value: error };
	  }
	};

	var process$2 = global_1.process;
	var versions = process$2 && process$2.versions;
	var v8 = versions && versions.v8;
	var match, version;

	if (v8) {
	  match = v8.split('.');
	  version = match[0] + match[1];
	} else if (engineUserAgent) {
	  match = engineUserAgent.match(/Edge\/(\d+)/);
	  if (!match || match[1] >= 74) {
	    match = engineUserAgent.match(/Chrome\/(\d+)/);
	    if (match) version = match[1];
	  }
	}

	var engineV8Version = version && +version;

	var task$1 = task.set;










	var SPECIES$2 = wellKnownSymbol('species');
	var PROMISE = 'Promise';
	var getInternalState = internalState.get;
	var setInternalState = internalState.set;
	var getInternalPromiseState = internalState.getterFor(PROMISE);
	var PromiseConstructor = nativePromiseConstructor;
	var TypeError$1 = global_1.TypeError;
	var document$2 = global_1.document;
	var process$3 = global_1.process;
	var $fetch = getBuiltIn('fetch');
	var newPromiseCapability$1 = newPromiseCapability.f;
	var newGenericPromiseCapability = newPromiseCapability$1;
	var IS_NODE$1 = classofRaw(process$3) == 'process';
	var DISPATCH_EVENT = !!(document$2 && document$2.createEvent && global_1.dispatchEvent);
	var UNHANDLED_REJECTION = 'unhandledrejection';
	var REJECTION_HANDLED = 'rejectionhandled';
	var PENDING = 0;
	var FULFILLED = 1;
	var REJECTED = 2;
	var HANDLED = 1;
	var UNHANDLED = 2;
	var Internal, OwnPromiseCapability, PromiseWrapper, nativeThen;

	var FORCED = isForced_1(PROMISE, function () {
	  var GLOBAL_CORE_JS_PROMISE = inspectSource(PromiseConstructor) !== String(PromiseConstructor);
	  if (!GLOBAL_CORE_JS_PROMISE) {
	    // V8 6.6 (Node 10 and Chrome 66) have a bug with resolving custom thenables
	    // https://bugs.chromium.org/p/chromium/issues/detail?id=830565
	    // We can't detect it synchronously, so just check versions
	    if (engineV8Version === 66) return true;
	    // Unhandled rejections tracking support, NodeJS Promise without it fails @@species test
	    if (!IS_NODE$1 && typeof PromiseRejectionEvent != 'function') return true;
	  }
	  // We can't use @@species feature detection in V8 since it causes
	  // deoptimization and performance degradation
	  // https://github.com/zloirock/core-js/issues/679
	  if (engineV8Version >= 51 && /native code/.test(PromiseConstructor)) return false;
	  // Detect correctness of subclassing with @@species support
	  var promise = PromiseConstructor.resolve(1);
	  var FakePromise = function (exec) {
	    exec(function () { /* empty */ }, function () { /* empty */ });
	  };
	  var constructor = promise.constructor = {};
	  constructor[SPECIES$2] = FakePromise;
	  return !(promise.then(function () { /* empty */ }) instanceof FakePromise);
	});

	var INCORRECT_ITERATION = FORCED || !checkCorrectnessOfIteration(function (iterable) {
	  PromiseConstructor.all(iterable)['catch'](function () { /* empty */ });
	});

	// helpers
	var isThenable = function (it) {
	  var then;
	  return isObject(it) && typeof (then = it.then) == 'function' ? then : false;
	};

	var notify$1 = function (promise, state, isReject) {
	  if (state.notified) return;
	  state.notified = true;
	  var chain = state.reactions;
	  microtask(function () {
	    var value = state.value;
	    var ok = state.state == FULFILLED;
	    var index = 0;
	    // variable length - can't use forEach
	    while (chain.length > index) {
	      var reaction = chain[index++];
	      var handler = ok ? reaction.ok : reaction.fail;
	      var resolve = reaction.resolve;
	      var reject = reaction.reject;
	      var domain = reaction.domain;
	      var result, then, exited;
	      try {
	        if (handler) {
	          if (!ok) {
	            if (state.rejection === UNHANDLED) onHandleUnhandled(promise, state);
	            state.rejection = HANDLED;
	          }
	          if (handler === true) result = value;
	          else {
	            if (domain) domain.enter();
	            result = handler(value); // can throw
	            if (domain) {
	              domain.exit();
	              exited = true;
	            }
	          }
	          if (result === reaction.promise) {
	            reject(TypeError$1('Promise-chain cycle'));
	          } else if (then = isThenable(result)) {
	            then.call(result, resolve, reject);
	          } else resolve(result);
	        } else reject(value);
	      } catch (error) {
	        if (domain && !exited) domain.exit();
	        reject(error);
	      }
	    }
	    state.reactions = [];
	    state.notified = false;
	    if (isReject && !state.rejection) onUnhandled(promise, state);
	  });
	};

	var dispatchEvent = function (name, promise, reason) {
	  var event, handler;
	  if (DISPATCH_EVENT) {
	    event = document$2.createEvent('Event');
	    event.promise = promise;
	    event.reason = reason;
	    event.initEvent(name, false, true);
	    global_1.dispatchEvent(event);
	  } else event = { promise: promise, reason: reason };
	  if (handler = global_1['on' + name]) handler(event);
	  else if (name === UNHANDLED_REJECTION) hostReportErrors('Unhandled promise rejection', reason);
	};

	var onUnhandled = function (promise, state) {
	  task$1.call(global_1, function () {
	    var value = state.value;
	    var IS_UNHANDLED = isUnhandled(state);
	    var result;
	    if (IS_UNHANDLED) {
	      result = perform(function () {
	        if (IS_NODE$1) {
	          process$3.emit('unhandledRejection', value, promise);
	        } else dispatchEvent(UNHANDLED_REJECTION, promise, value);
	      });
	      // Browsers should not trigger `rejectionHandled` event if it was handled here, NodeJS - should
	      state.rejection = IS_NODE$1 || isUnhandled(state) ? UNHANDLED : HANDLED;
	      if (result.error) throw result.value;
	    }
	  });
	};

	var isUnhandled = function (state) {
	  return state.rejection !== HANDLED && !state.parent;
	};

	var onHandleUnhandled = function (promise, state) {
	  task$1.call(global_1, function () {
	    if (IS_NODE$1) {
	      process$3.emit('rejectionHandled', promise);
	    } else dispatchEvent(REJECTION_HANDLED, promise, state.value);
	  });
	};

	var bind = function (fn, promise, state, unwrap) {
	  return function (value) {
	    fn(promise, state, value, unwrap);
	  };
	};

	var internalReject = function (promise, state, value, unwrap) {
	  if (state.done) return;
	  state.done = true;
	  if (unwrap) state = unwrap;
	  state.value = value;
	  state.state = REJECTED;
	  notify$1(promise, state, true);
	};

	var internalResolve = function (promise, state, value, unwrap) {
	  if (state.done) return;
	  state.done = true;
	  if (unwrap) state = unwrap;
	  try {
	    if (promise === value) throw TypeError$1("Promise can't be resolved itself");
	    var then = isThenable(value);
	    if (then) {
	      microtask(function () {
	        var wrapper = { done: false };
	        try {
	          then.call(value,
	            bind(internalResolve, promise, wrapper, state),
	            bind(internalReject, promise, wrapper, state)
	          );
	        } catch (error) {
	          internalReject(promise, wrapper, error, state);
	        }
	      });
	    } else {
	      state.value = value;
	      state.state = FULFILLED;
	      notify$1(promise, state, false);
	    }
	  } catch (error) {
	    internalReject(promise, { done: false }, error, state);
	  }
	};

	// constructor polyfill
	if (FORCED) {
	  // 25.4.3.1 Promise(executor)
	  PromiseConstructor = function Promise(executor) {
	    anInstance(this, PromiseConstructor, PROMISE);
	    aFunction$1(executor);
	    Internal.call(this);
	    var state = getInternalState(this);
	    try {
	      executor(bind(internalResolve, this, state), bind(internalReject, this, state));
	    } catch (error) {
	      internalReject(this, state, error);
	    }
	  };
	  // eslint-disable-next-line no-unused-vars
	  Internal = function Promise(executor) {
	    setInternalState(this, {
	      type: PROMISE,
	      done: false,
	      notified: false,
	      parent: false,
	      reactions: [],
	      rejection: false,
	      state: PENDING,
	      value: undefined
	    });
	  };
	  Internal.prototype = redefineAll(PromiseConstructor.prototype, {
	    // `Promise.prototype.then` method
	    // https://tc39.github.io/ecma262/#sec-promise.prototype.then
	    then: function then(onFulfilled, onRejected) {
	      var state = getInternalPromiseState(this);
	      var reaction = newPromiseCapability$1(speciesConstructor(this, PromiseConstructor));
	      reaction.ok = typeof onFulfilled == 'function' ? onFulfilled : true;
	      reaction.fail = typeof onRejected == 'function' && onRejected;
	      reaction.domain = IS_NODE$1 ? process$3.domain : undefined;
	      state.parent = true;
	      state.reactions.push(reaction);
	      if (state.state != PENDING) notify$1(this, state, false);
	      return reaction.promise;
	    },
	    // `Promise.prototype.catch` method
	    // https://tc39.github.io/ecma262/#sec-promise.prototype.catch
	    'catch': function (onRejected) {
	      return this.then(undefined, onRejected);
	    }
	  });
	  OwnPromiseCapability = function () {
	    var promise = new Internal();
	    var state = getInternalState(promise);
	    this.promise = promise;
	    this.resolve = bind(internalResolve, promise, state);
	    this.reject = bind(internalReject, promise, state);
	  };
	  newPromiseCapability.f = newPromiseCapability$1 = function (C) {
	    return C === PromiseConstructor || C === PromiseWrapper
	      ? new OwnPromiseCapability(C)
	      : newGenericPromiseCapability(C);
	  };

	  if ( typeof nativePromiseConstructor == 'function') {
	    nativeThen = nativePromiseConstructor.prototype.then;

	    // wrap native Promise#then for native async functions
	    redefine(nativePromiseConstructor.prototype, 'then', function then(onFulfilled, onRejected) {
	      var that = this;
	      return new PromiseConstructor(function (resolve, reject) {
	        nativeThen.call(that, resolve, reject);
	      }).then(onFulfilled, onRejected);
	    // https://github.com/zloirock/core-js/issues/640
	    }, { unsafe: true });

	    // wrap fetch result
	    if (typeof $fetch == 'function') _export({ global: true, enumerable: true, forced: true }, {
	      // eslint-disable-next-line no-unused-vars
	      fetch: function fetch(input /* , init */) {
	        return promiseResolve(PromiseConstructor, $fetch.apply(global_1, arguments));
	      }
	    });
	  }
	}

	_export({ global: true, wrap: true, forced: FORCED }, {
	  Promise: PromiseConstructor
	});

	setToStringTag(PromiseConstructor, PROMISE, false);
	setSpecies(PROMISE);

	PromiseWrapper = getBuiltIn(PROMISE);

	// statics
	_export({ target: PROMISE, stat: true, forced: FORCED }, {
	  // `Promise.reject` method
	  // https://tc39.github.io/ecma262/#sec-promise.reject
	  reject: function reject(r) {
	    var capability = newPromiseCapability$1(this);
	    capability.reject.call(undefined, r);
	    return capability.promise;
	  }
	});

	_export({ target: PROMISE, stat: true, forced:  FORCED }, {
	  // `Promise.resolve` method
	  // https://tc39.github.io/ecma262/#sec-promise.resolve
	  resolve: function resolve(x) {
	    return promiseResolve( this, x);
	  }
	});

	_export({ target: PROMISE, stat: true, forced: INCORRECT_ITERATION }, {
	  // `Promise.all` method
	  // https://tc39.github.io/ecma262/#sec-promise.all
	  all: function all(iterable) {
	    var C = this;
	    var capability = newPromiseCapability$1(C);
	    var resolve = capability.resolve;
	    var reject = capability.reject;
	    var result = perform(function () {
	      var $promiseResolve = aFunction$1(C.resolve);
	      var values = [];
	      var counter = 0;
	      var remaining = 1;
	      iterate_1(iterable, function (promise) {
	        var index = counter++;
	        var alreadyCalled = false;
	        values.push(undefined);
	        remaining++;
	        $promiseResolve.call(C, promise).then(function (value) {
	          if (alreadyCalled) return;
	          alreadyCalled = true;
	          values[index] = value;
	          --remaining || resolve(values);
	        }, reject);
	      });
	      --remaining || resolve(values);
	    });
	    if (result.error) reject(result.value);
	    return capability.promise;
	  },
	  // `Promise.race` method
	  // https://tc39.github.io/ecma262/#sec-promise.race
	  race: function race(iterable) {
	    var C = this;
	    var capability = newPromiseCapability$1(C);
	    var reject = capability.reject;
	    var result = perform(function () {
	      var $promiseResolve = aFunction$1(C.resolve);
	      iterate_1(iterable, function (promise) {
	        $promiseResolve.call(C, promise).then(capability.resolve, reject);
	      });
	    });
	    if (result.error) reject(result.value);
	    return capability.promise;
	  }
	});

	// Safari bug https://bugs.webkit.org/show_bug.cgi?id=200829
	var NON_GENERIC = !!nativePromiseConstructor && fails(function () {
	  nativePromiseConstructor.prototype['finally'].call({ then: function () { /* empty */ } }, function () { /* empty */ });
	});

	// `Promise.prototype.finally` method
	// https://tc39.github.io/ecma262/#sec-promise.prototype.finally
	_export({ target: 'Promise', proto: true, real: true, forced: NON_GENERIC }, {
	  'finally': function (onFinally) {
	    var C = speciesConstructor(this, getBuiltIn('Promise'));
	    var isFunction = typeof onFinally == 'function';
	    return this.then(
	      isFunction ? function (x) {
	        return promiseResolve(C, onFinally()).then(function () { return x; });
	      } : onFinally,
	      isFunction ? function (e) {
	        return promiseResolve(C, onFinally()).then(function () { throw e; });
	      } : onFinally
	    );
	  }
	});

	// patch native Promise.prototype for native async functions
	if ( typeof nativePromiseConstructor == 'function' && !nativePromiseConstructor.prototype['finally']) {
	  redefine(nativePromiseConstructor.prototype, 'finally', getBuiltIn('Promise').prototype['finally']);
	}

	var call = Function.call;

	var entryUnbind = function (CONSTRUCTOR, METHOD, length) {
	  return functionBindContext(call, global_1[CONSTRUCTOR].prototype[METHOD], length);
	};

	var _finally = entryUnbind('Promise', 'finally');

	var es2018Promise = createCommonjsModule(function (module, exports) {
	Object.defineProperty(exports, "__esModule", { value: true });
	});

	unwrapExports(es2018Promise);

	/*! *****************************************************************************
	Copyright (c) Microsoft Corporation. All rights reserved.
	Licensed under the Apache License, Version 2.0 (the "License"); you may not use
	this file except in compliance with the License. You may obtain a copy of the
	License at http://www.apache.org/licenses/LICENSE-2.0

	THIS CODE IS PROVIDED ON AN *AS IS* BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
	KIND, EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT LIMITATION ANY IMPLIED
	WARRANTIES OR CONDITIONS OF TITLE, FITNESS FOR A PARTICULAR PURPOSE,
	MERCHANTABLITY OR NON-INFRINGEMENT.

	See the Apache Version 2.0 License for specific language governing permissions
	and limitations under the License.
	***************************************************************************** */
	/* global Reflect, Promise */

	var extendStatics = function(d, b) {
	    extendStatics = Object.setPrototypeOf ||
	        ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
	        function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
	    return extendStatics(d, b);
	};

	function __extends(d, b) {
	    extendStatics(d, b);
	    function __() { this.constructor = d; }
	    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
	}

	var __assign = function() {
	    __assign = Object.assign || function __assign(t) {
	        for (var s, i = 1, n = arguments.length; i < n; i++) {
	            s = arguments[i];
	            for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
	        }
	        return t;
	    };
	    return __assign.apply(this, arguments);
	};

	function __rest(s, e) {
	    var t = {};
	    for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p) && e.indexOf(p) < 0)
	        t[p] = s[p];
	    if (s != null && typeof Object.getOwnPropertySymbols === "function")
	        for (var i = 0, p = Object.getOwnPropertySymbols(s); i < p.length; i++) {
	            if (e.indexOf(p[i]) < 0 && Object.prototype.propertyIsEnumerable.call(s, p[i]))
	                t[p[i]] = s[p[i]];
	        }
	    return t;
	}

	function __read(o, n) {
	    var m = typeof Symbol === "function" && o[Symbol.iterator];
	    if (!m) return o;
	    var i = m.call(o), r, ar = [], e;
	    try {
	        while ((n === void 0 || n-- > 0) && !(r = i.next()).done) ar.push(r.value);
	    }
	    catch (error) { e = { error: error }; }
	    finally {
	        try {
	            if (r && !r.done && (m = i["return"])) m.call(i);
	        }
	        finally { if (e) throw e.error; }
	    }
	    return ar;
	}

	function __spread() {
	    for (var ar = [], i = 0; i < arguments.length; i++)
	        ar = ar.concat(__read(arguments[i]));
	    return ar;
	}

	/**
	 * In-Memory polyFill for localStorage and sessionStorage.
	 *
	 * @constructor
	 * @description Needed for Mac and iOS Safari (v <= 10) in Private Mode. Note that this object doesn't actually
	 * persist data across refresh, it just implements the [Storage]{@link external:Storage} interface.
	 * @exports memoryStorage
	 */
	var MemoryStorage = /** @class */ (function () {
	    function MemoryStorage() {
	        /**
	         * @type {!Object}
	         */
	        this.data = {};
	        /**
	         * property added in order to be compatible with Storage class
	         */
	        this.length = 0;
	    }
	    /**
	     * clear the memory data
	     */
	    MemoryStorage.prototype.clear = function () {
	        this.data = {};
	        this.length = 0;
	    };
	    /**
	     * @param key {String} represents the used key to get a value
	     * @returns {Object} the value associated with the input key
	     */
	    MemoryStorage.prototype.getItem = function (key) {
	        var value = this.data[key];
	        return value ? value : null;
	    };
	    /**
	     *
	     * @param key {string} represent the key which will be removed from memory
	     * @returns {boolean} true if the key is removed otherwise false
	     */
	    MemoryStorage.prototype.removeItem = function (key) {
	        if (!this.data[key]) {
	            return false;
	        }
	        delete this.data[key];
	        --this.length;
	        return true;
	    };
	    /**
	     * @key {String} - the used key to store a value into memory
	     * @value {any} - value associated with the input key
	     */
	    MemoryStorage.prototype.setItem = function (key, value) {
	        if (!this.data[key]) {
	            ++this.length;
	        }
	        this.data[key] = value;
	    };
	    MemoryStorage.prototype.key = function (index) {
	        throw new Error("Method not implemented. " + index);
	    };
	    return MemoryStorage;
	}());

	var AdobeIdKey = 'adobeid';
	var AdobeIMSKey = 'adobeIMS';
	var AdobeImsFactory = 'adobeImsFactory';
	var DEFAULT_LANGUAGE = 'en_US';
	var STORAGE_MODE;
	(function (STORAGE_MODE) {
	    STORAGE_MODE["LocalStorage"] = "local";
	    STORAGE_MODE["SessionStorage"] = "session";
	    STORAGE_MODE["MemoryStorage"] = "memory";
	})(STORAGE_MODE || (STORAGE_MODE = {}));
	var HEADERS = {
	    AUTHORIZATION: 'Authorization',
	    X_IMS_CLIENT_ID: 'X-IMS-ClientId',
	    RETRY_AFTER: 'Retry-after',
	};
	var PROFILE_STORAGE_KEY = 'adobeid_ims_profile';
	var TOKEN_STORAGE_KEY = 'adobeid_ims_access_token';
	var ON_IMSLIB_INSTANCE = 'onImsLibInstance';
	var ASK_FOR_IMSLIB_INSTANCE_DOM_EVENT_NAME = 'getImsLibInstance';

	/**
	 * Wrapper for <code>console</code>. Checks <code>console</code> is available and <code>debug</code> Mode is enabled.
	 *
	 * @exports log
	 *
	 */
	var Log = /** @class */ (function () {
	    function Log() {
	        var _this = this;
	        this.logEnabled = false;
	        /**
	         * Wrapper function.
	         *
	         * @param {String} method - Which <code>console</code> method to use.
	         * @param {*} args - Arguments object
	         *
	         * @private
	         */
	        this.print = function (method, args) {
	            if (!_this.logEnabled) {
	                return;
	            }
	            method.apply(void 0, __spread(args));
	        };
	        /**
	         * Writes an error to the console when the evaluated expression is false.
	         *
	         * @example
	         * log.assert(1 == 2, "Counting is hard.");
	         *
	         * @param {Boolean} expression - Expression to evaluate.
	         * @param {String} message - Message to print if <code>epxression</code> is <code>false</code>.
	         *
	         * @static
	         */
	        this.assert = function (val, message) {
	            _this.print(console.assert, [val, message]);
	        };
	        /**
	         * Writes an error to the console when the evaluated expression is false.
	         *
	         * @example
	         * log.assert(1 == 2, "Counting is hard.");
	         *
	         * @param {Boolean} expression - Expression to evaluate.
	         * @param {String} message - Message to print if <code>epxression</code> is <code>false</code>.
	         *
	         * @static
	         */
	        this.assertCondition = function (condition, message) {
	            if (!condition()) {
	                _this.print(console.error, [message]);
	            }
	        };
	        /**
	         * Prints a message similar to <code>console.log()</code>, styles the message like an error, and includes a stack
	         * trace from where the method wasval, called.
	         *
	         * @see {@link https://developers.google.com/web/tools/chrome-devtools/console/#filtering_the_console_output | Filtering the Console output}
	         *
	         * @example
	         * log.error("Define window.adobeid", "would you?!");
	         * @param {String} message - Message to print.
	         */
	        this.error = function () {
	            var args = [];
	            for (var _i = 0; _i < arguments.length; _i++) {
	                args[_i] = arguments[_i];
	            }
	            _this.print(console.error, args);
	        };
	        /**
	         * logs a warnig message
	         */
	        this.warn = function () {
	            var args = [];
	            for (var _i = 0; _i < arguments.length; _i++) {
	                args[_i] = arguments[_i];
	            }
	            _this.print(console.warn, args);
	        };
	        /**
	         * Prints a message like <code>console.log()</code> but also shows an icon (blue circle with white "i") next to the
	         * output.
	         *
	         * <code>console.info()</code> can be filtered in the Console, whereas <code>console.log()</code> can not.
	         *
	         * @example
	         * log.info("Imslib.js Ready", "to Rumble");
	         *
	         * @param {String} message - Message to print.
	         *
	         * @static
	         */
	        this.info = function () {
	            var args = [];
	            for (var _i = 0; _i < arguments.length; _i++) {
	                args[_i] = arguments[_i];
	            }
	            _this.print(console.info, args);
	        };
	    }
	    Log.prototype.enableLogging = function () {
	        this.logEnabled = true;
	    };
	    Log.prototype.disableLogging = function () {
	        this.logEnabled = false;
	    };
	    return Log;
	}());
	var Log$1 = new Log();

	/**
	 * A cross-browser way to use `sessionStorage`
	 *
	 * @exports storage
	 * @requires MemoryStorage
	 */
	var StorageFactory = /** @class */ (function () {
	    function StorageFactory() {
	        this.memoryStorageInstance = null;
	    }
	    Object.defineProperty(StorageFactory.prototype, "memoryStorage", {
	        get: function () {
	            if (!this.memoryStorageInstance) {
	                this.memoryStorageInstance = new MemoryStorage();
	            }
	            return this.memoryStorageInstance;
	        },
	        enumerable: true,
	        configurable: true
	    });
	    /**
	    *
	    * @param storageName represents the storage name
	    * @returns the local or session storage; in case there is a problem with storage, the memory storage is returned
	    */
	    StorageFactory.prototype.getStorageByName = function (storageName) {
	        var storageInstance = this.getStorageInstanceByName(storageName);
	        if (!storageInstance) {
	            return this.memoryStorage;
	        }
	        return this.verifyStorage(storageInstance) ? storageInstance : this.memoryStorage;
	    };
	    /**
	     * method used to get the avilable storage and to give the possibility to mock the behaviour
	     * @param storageName the storage name used to get the storage
	     * @returns Storage or null
	     */
	    StorageFactory.prototype.getStorageInstanceByName = function (storageName) {
	        if (storageName === STORAGE_MODE.MemoryStorage) {
	            return this.memoryStorage;
	        }
	        try {
	            return storageName === STORAGE_MODE.LocalStorage ? window.localStorage : window.sessionStorage;
	        }
	        catch (ex) {
	            Log$1.warn('Please change your cookies settings in order to allow local data to be set');
	            return null;
	        }
	    };
	    /**
	     * returns the available storage; the priority is local storage and after that the session storage
	     * if no local or session storage is available, the Memory Storage is returned
	     */
	    StorageFactory.prototype.getAvailableStorage = function () {
	        var storage = this.getStorageByName(STORAGE_MODE.LocalStorage);
	        if (storage instanceof MemoryStorage) {
	            return this.getStorageByName(STORAGE_MODE.SessionStorage);
	        }
	        return storage;
	    };
	    /**
	     *
	     * @param storage represents the storage instance
	     * @returns true if storage is working as expected otherwise false
	     */
	    StorageFactory.prototype.verifyStorage = function (storage) {
	        var storageKey = 'test';
	        try {
	            storage.setItem(storageKey, 'true');
	            var storageValue = storage.getItem(storageKey);
	            if (storageValue !== 'true') {
	                return false;
	            }
	            storage.removeItem(storageKey);
	            return true;
	        }
	        catch (ex) {
	            return false;
	        }
	    };
	    return StorageFactory;
	}());
	var StorageFactory$1 = new StorageFactory();

	/**
	 * nonce key used for store the Csrf nonce value
	 */
	var NONCE = 'nonce';
	var NONCE_LENGTH = 16;
	var ONE_HOUR = 60 * 60 * 3600;
	/**
	 * class used for the CSRF process
	 */
	var CsrfService = /** @class */ (function () {
	    /**
	     *
	     * @param clientId {String} the client id used for Csrf
	     */
	    function CsrfService(clientId) {
	        /**
	         * represents the Storage instance used during Csrf flow
	         */
	        this.storageInstance = null;
	        /**
	         * represents the storage key used to save the nonce values for current client Id
	         */
	        this.nonceStorageKey = '';
	        this.nonceStorageKey = "" + NONCE + clientId;
	    }
	    Object.defineProperty(CsrfService.prototype, "storage", {
	        get: function () {
	            if (!this.storageInstance) {
	                this.storageInstance = StorageFactory$1.getAvailableStorage();
	            }
	            return this.storageInstance;
	        },
	        enumerable: true,
	        configurable: true
	    });
	    /**
	     * Starts the CSRF process by trying to save a random string value to available storage
	     * @returns the nonce value
	     */
	    CsrfService.prototype.initialize = function () {
	        if (!this.isStorageAvailable()) {
	            return '';
	        }
	        var nonce = CsrfService.generateNonce();
	        var nonceStorageValue = this.getNonceFromStorage() || {};
	        nonceStorageValue = this.clearOlderNonceKeys(nonceStorageValue);
	        this.addNonceToObject(nonceStorageValue, nonce);
	        this.saveNonceValuesToStorage(nonceStorageValue);
	        return nonce.value;
	    };
	    /**
	     *
	     * @param nonceStorageValue represents the object used to store the nonce values
	     * @param nonce represents the nonce value
	     */
	    CsrfService.prototype.addNonceToObject = function (nonceStorageValue, nonce) {
	        nonceStorageValue[nonce.value] = nonce.expiry;
	    };
	    /**
	     * clears the local storage keys older than 1h
	     * @param nonceStorageValue local storage object used to store nonce
	     */
	    CsrfService.prototype.clearOlderNonceKeys = function (nonceStorageValue, olderThan) {
	        if (olderThan === void 0) { olderThan = ONE_HOUR; }
	        var oneHourAgo = Date.now() - olderThan;
	        var expiry = 0;
	        Object.keys(nonceStorageValue).forEach(function (key) {
	            expiry = parseInt(nonceStorageValue[key]);
	            if (expiry < oneHourAgo) {
	                delete nonceStorageValue[key];
	            }
	        });
	        return nonceStorageValue;
	    };
	    /**
	     * @param fragmentNonce represents the nonce value received after redirect from ims
	     * @returns {boolean} true if nonce is valid, otherwise false
	     */
	    CsrfService.prototype.verify = function (fragmentNonce) {
	        if (!this.isStorageAvailable()) {
	            return true;
	        }
	        var storageNonce = this.getNonceFromStorage();
	        if (!storageNonce) {
	            return false;
	        }
	        var nonceStorageValue = this.clearOlderNonceKeys(storageNonce);
	        var isValidCsrf = (nonceStorageValue[fragmentNonce] || null) !== null;
	        if (isValidCsrf) {
	            this.clearNonceValueFromStorage(nonceStorageValue, fragmentNonce);
	        }
	        return isValidCsrf;
	    };
	    /**
	     *
	     * @param nonceStorageValue represents the saved nonce values into the Storage
	     * @param fragmentNonce is nonce value which will be removed from Storage
	     */
	    CsrfService.prototype.clearNonceValueFromStorage = function (nonceStorageValue, fragmentNonce) {
	        delete nonceStorageValue[fragmentNonce];
	        this.saveNonceValuesToStorage(nonceStorageValue);
	    };
	    /**
	     * Returns the nonce values from storage as an Object or null
	     * @returns {IDictionary | null}
	     */
	    CsrfService.prototype.getNonceFromStorage = function () {
	        var nonce = this.storage.getItem(this.nonceStorageKey);
	        return nonce ? JSON.parse(nonce) : null;
	    };
	    /**
	   * @param nonceValues the nonce values which will be saved to Storage
	   */
	    CsrfService.prototype.saveNonceValuesToStorage = function (nonceValues) {
	        this.storage.setItem(this.nonceStorageKey, JSON.stringify(nonceValues));
	    };
	    /**
	     * function used to check if the local or session storage is available
	     */
	    CsrfService.prototype.isStorageAvailable = function () {
	        return !(this.storage instanceof MemoryStorage);
	    };
	    /**
	     * generate random string based on crypto object
	     */
	    CsrfService.cryptoRndomString = function () {
	        if (!window.crypto) {
	            return '';
	        }
	        var array = new Uint32Array(3);
	        window.crypto.getRandomValues(array);
	        return array.join('').substr(0, NONCE_LENGTH);
	    };
	    /**
	     * @function randomString
	     * used to generate a random string during the initialization of Csrf process
	     */
	    CsrfService.randomString = function () {
	        var cryptorandomString = CsrfService.cryptoRndomString();
	        if (cryptorandomString) {
	            return cryptorandomString;
	        }
	        var text = "";
	        var possible = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
	        for (var i = 0; i < NONCE_LENGTH; i++) {
	            text += possible.charAt(Math.floor(Math.random() * possible.length));
	        }
	        return text;
	    };
	    /**
	     * generate a key value pair used for nonce
	     * @returns INonce object
	     */
	    CsrfService.generateNonce = function () { return ({
	        value: CsrfService.randomString(),
	        expiry: new Date().getTime().toString()
	    }); };
	    return CsrfService;
	}());

	/**
	 * class used to implement the main functions used for query strings
	 */
	var UrlHelper = /** @class */ (function () {
	    function UrlHelper() {
	    }
	    /**
	   * Encodes data as a query string.
	   * @param {Object} data - The data.
	   * @returns {string} - The encoded string.
	    * @example
	    * encoded = uriEncodeData({
	    *   first: true,
	    *   foo: {
	    *     bar: 'foobar'
	    *   }
	    * }) // -> first=true&foo=%7B%22bar%22%3A%22foobar%22%7D
	    */
	    UrlHelper.prototype.uriEncodeData = function (data) {
	        if (typeof data !== 'object') {
	            return '';
	        }
	        var encodings = [];
	        var encodedValue = '';
	        var keyValue;
	        for (var key in data) {
	            keyValue = data[key];
	            if (keyValue === undefined) {
	                continue;
	            }
	            encodedValue = this.encodeValue(keyValue);
	            encodings.push(encodeURIComponent(key) + "=" + encodedValue);
	        }
	        return encodings.join("&");
	    };
	    /**
	   * @param value : any; represents the value which will be encoded
	   * @returns string.
	   */
	    UrlHelper.prototype.encodeValue = function (value) {
	        if (value === null) {
	            return 'null';
	        }
	        if (typeof value === 'object') {
	            return encodeURIComponent(JSON.stringify(value));
	        }
	        return encodeURIComponent(value);
	    };
	    /**
	   * Opens the URL in the current page
	   *
	   * @param {!string} url
	   */
	    UrlHelper.prototype.replaceUrl = function (url) {
	        if (!url) {
	            return;
	        }
	        window.location.replace(url);
	    };
	    /**
	   * Opens the URL in the current page
	   * @param {!string} url
	   */
	    UrlHelper.prototype.setHrefUrl = function (url) {
	        if (!url) {
	            return;
	        }
	        window.location.href = url;
	    };
	    /**
	  * Change the hash from url to a new value without reloading the page
	  * @param hash {String} represents the new hash value
	  *
	  */
	    UrlHelper.prototype.setHash = function (hash) {
	        if (hash === void 0) { hash = ''; }
	        window.location.hash = hash;
	    };
	    return UrlHelper;
	}());
	var UrlHelper$1 = new UrlHelper();

	/**
	 * Enumeration values for available environments
	 */
	var IEnvironment;
	(function (IEnvironment) {
	    /**
	     * Stage environment
	     */
	    IEnvironment["STAGE"] = "stg1";
	    /**
	     * Prod environment
	     */
	    IEnvironment["PROD"] = "prod";
	})(IEnvironment || (IEnvironment = {}));

	/**
	 * class used to store the variables used for ims flow
	 */
	var Environment = /** @class */ (function () {
	    function Environment() {
	        /**
	       * @property {String} Represents the base url used on api (back-end) call in case of getProfile, getUserInfo and validateToken;
	       */
	        this.baseUrlAdobe = '';
	        /**
	       * @property {string} Represents the base url used on api (back-end) call in case of logoutToken, checkStatus checkToken,listSocialProviders and exchangeIjt;
	       */
	        this.baseUrlServices = '';
	        /**
	       * @property {string} this parameter is passed to redirect uri during a sign in or sign out operation
	       */
	        this.jslibver = 'v2-v0.17.0-35-gdd2e891';
	    }
	    Environment.prototype.loadEnvironment = function (environment) {
	        if (environment === IEnvironment.STAGE) {
	            this.baseUrlAdobe = 'https://ims-na1-stg1.adobelogin.com';
	            this.baseUrlServices = 'https://adobeid-na1-stg1.services.adobe.com';
	            return;
	        }
	        this.baseUrlAdobe = 'https://ims-na1.adobelogin.com';
	        this.baseUrlServices = 'https://adobeid-na1.services.adobe.com';
	    };
	    return Environment;
	}());
	var Environment$1 = new Environment();

	/**
	 * class used to store the helper functions
	 */
	var ApiHelpers = /** @class */ (function () {
	    function ApiHelpers() {
	        /**
	       * Checks [adobeid.api_parameters]{@link adobeid} for custom parameters for an API.
	       * @param apiName - represents the used api name
	       * @param apiParameters - represents the parameters set from outside for api endpoints read from adobeId
	       * @returns {!Object}
	       */
	        this.getCustomApiParameters = function (apiParameters, apiName) {
	            return Object.keys(apiParameters).reduce(function (acumulator, key) {
	                if (key.indexOf(apiName) > -1) {
	                    acumulator[key] = apiParameters[key] || null;
	                }
	                return acumulator;
	            }, {});
	        };
	    }
	    /**
	     *
	     * @param externalParameters external parameters received outside of the library
	     * @param apiParameters the api parameters from AdobeId data
	     * @param apiName api name
	     * @returns IDictionary representing the merged properties
	     */
	    ApiHelpers.prototype.mergeExternalParameters = function (externalParameters, apiParameters, apiName) {
	        return __assign(__assign({}, this.getCustomApiParameters(apiParameters, apiName)), externalParameters);
	    };
	    /***
	     * @param value {String} represents the
	     */
	    ApiHelpers.prototype.toJson = function (value) {
	        try {
	            if (typeof value !== 'string') {
	                return value;
	            }
	            return JSON.parse(value);
	        }
	        catch (_a) {
	            return null;
	        }
	    };
	    return ApiHelpers;
	}());
	var ApiHelpers$1 = new ApiHelpers();

	var RedirectHelper = /** @class */ (function () {
	    function RedirectHelper() {
	    }
	    /**
	    * returns the initial redirect url; the priority value is redirect_uri from external parameters, adobeId and finally the href value from browsers
	    * @param externalParameters
	    * @param adobeIdRedirectUri
	    */
	    RedirectHelper.getInitialRedirectUri = function (externalParameters, adobeIdRedirectUri) {
	        var redirectValue = externalParameters["redirect_uri"] || (adobeIdRedirectUri || window.location.href);
	        var fromImsIndex = redirectValue.indexOf('from_ims');
	        if (fromImsIndex === -1) {
	            return redirectValue;
	        }
	        if (redirectValue[fromImsIndex - 1] === '#') {
	            fromImsIndex--;
	        }
	        return redirectValue.substr(0, fromImsIndex);
	    };
	    /**
	    * create the return url which it will be passed to authorize or logout endpoint
	    * @param adobeIdRedirectUri {string} - represents the redirect_uri? set on AdobeId;
	    * @param clientId {string} - represents the client id from AdobeId
	    * @param externalParameters {Object} external parameters passed to library
	    * @param apiName {string} api name
	    *
	    * @returns {string} final redirect url used for sign-in or reauth (authorize) or logout
	    */
	    RedirectHelper.createDefaultRedirectUrl = function (adobeIdRedirectUri, clientId, externalParameters, apiName) {
	        var initialRedirectUri = this.getInitialRedirectUri(externalParameters, adobeIdRedirectUri);
	        //encode the hash in case that exists
	        var redirectUri = this.createOldHash(initialRedirectUri);
	        return redirectUri.indexOf('?') > 0 ?
	            redirectUri + "&client_id=" + clientId + "&api=" + apiName :
	            redirectUri + "?client_id=" + clientId + "&api=" + apiName;
	    };
	    /**
	     * <uml>
	     * start
	     * :CreateDefaultRedirectUrl ;
	     * :merge api parameters with external parameters
	     * :encode the merged parameters and call the /ims/authorize/v1/${encodedParameters} url
	     * end
	     * </uml>
	     *
	     * create the return url which it will be passed to authorization endpoint
	     * @param redirectUri {string} - represents the base url href value
	     * @param clientId {string} - represents the client id
	     * @param externalParameters {Object} external parameters passed to library
	     * @param apiName {string} api name
	     * @parm scope {string} scope of sign in
	     * @returns {string} final redirect url used for sign in
	     */
	    RedirectHelper.createRedirectUrl = function (adobeIdRedirectUri, clientId, externalParameters, apiName, scope) {
	        if (scope === void 0) { scope = ''; }
	        var redirectUri = this.createDefaultRedirectUrl(adobeIdRedirectUri, clientId, externalParameters, apiName);
	        scope = scope || externalParameters["scope"] || '';
	        if (scope) {
	            redirectUri = redirectUri + "&scope=" + encodeURIComponent(scope);
	        }
	        var reauth = externalParameters["reauth"] || '';
	        if (reauth) {
	            redirectUri = redirectUri + "&reauth=" + encodeURIComponent(reauth);
	        }
	        return redirectUri;
	    };
	    /**
	     * @param source {string} represent the url value with hash which will be encoded
	     * @returns {string} the same url but the hash is encoded
	     */
	    RedirectHelper.createOldHash = function (source) {
	        var index = source.indexOf("#");
	        if (index < 0) {
	            return source + "#old_hash=&from_ims=true";
	        }
	        var baseUrl = source.substring(0, index);
	        var hash = source.substring(index + 1);
	        return baseUrl + "#old_hash=" + encodeURIComponent(hash) + "&from_ims=true";
	    };
	    RedirectHelper.mergeApiParamsWithExternalParams = function (apiParameters, externalParameters, apiName) {
	        return __assign(__assign({}, ApiHelpers$1.getCustomApiParameters(apiParameters, apiName)), externalParameters);
	    };
	    return RedirectHelper;
	}());

	/**
	 * command responsable for user sign in
	 */
	var BaseSignInService = /** @class */ (function () {
	    function BaseSignInService() {
	        var _this = this;
	        /**
	         * execute the sign in method which redirects the user to the login page
	         * <uml>
	         * start
	         * :CreateRedirectUrl;
	         * :merge api parameters with external parameters
	         * :encode the merged parameters and call the /ims/authorize/v1/${encodedParameters} url
	         * end
	         * </uml>
	         *
	         * @param {IRedirectRequest} redirectRequest. contains all the adobeId necessary properties necessary for sign in
	         */
	        this.composeRedirectUrl = function (redirectRequest) {
	            var apiName = "authorize";
	            var apiParameters = redirectRequest.apiParameters, _a = redirectRequest.externalParameters, externalParameters = _a === void 0 ? {} : _a, _b = redirectRequest.adobeIdRedirectUri, adobeIdRedirectUri = _b === void 0 ? "" : _b, clientId = redirectRequest.clientId, localeAdobeId = redirectRequest.locale, _c = redirectRequest.state, state = _c === void 0 ? {} : _c;
	            var _d = redirectRequest.scope, scope = _d === void 0 ? externalParameters["scope"] || apiParameters["scope"] || "" : _d;
	            var apiExternalParams = RedirectHelper.mergeApiParamsWithExternalParams(apiParameters, externalParameters, apiName);
	            var redirectUrl = RedirectHelper.createRedirectUrl(adobeIdRedirectUri, clientId, apiExternalParams, apiName, scope);
	            var locale = externalParameters.locale || localeAdobeId || '';
	            var 
	            // eslint-disable-next-line @typescript-eslint/camelcase
	            _e = redirectRequest.response_type, 
	            // eslint-disable-next-line @typescript-eslint/camelcase
	            response_type = _e === void 0 ? apiExternalParams["response_type"] || '' : _e;
	            var parameters = __assign(__assign({}, apiExternalParams), { client_id: clientId, scope: scope,
	                locale: locale,
	                response_type: response_type, jslVersion: Environment$1.jslibver, redirect_uri: redirectUrl });
	            if (state) {
	                parameters["state"] = state;
	            }
	            return parameters;
	        };
	        /**
	         * execute the sign in method which redirects the user to the login page
	         * <uml>
	         * start
	         * :CreateRedirectUrl;
	         * :merge api parameters with external parameters
	         * :encode the merged parameters and call the /ims/authorize/v1/${encodedParameters} url
	         * end
	         * </uml>
	         *
	         * @param {IRedirectRequest} redirectRequest. contains all the adobeId necessary properties necessary for sign in
	         */
	        this.createRedirectUrl = function (redirectRequest) {
	            var parameters = _this.composeRedirectUrl(redirectRequest);
	            var queryStrings = UrlHelper$1.uriEncodeData(parameters);
	            var url = Environment$1.baseUrlAdobe + "/ims/authorize/v1?" + queryStrings;
	            return url;
	        };
	    }
	    return BaseSignInService;
	}());

	/**
	 * command responsable for user sign in
	 */
	var SignInService = /** @class */ (function (_super) {
	    __extends(SignInService, _super);
	    function SignInService() {
	        var _this = _super !== null && _super.apply(this, arguments) || this;
	        /**
	         * execute the sign in method which redirects the user to the login page
	         * <uml>
	         * start
	         * :CreateRedirectUrl;
	         * :merge api parameters with external parameters
	         * :encode the merged parameters and call the /ims/authorize/v1/${encodedParameters} url
	         * end
	         * </uml>
	         *
	         * @param {IRedirectRequest} redirectRequest. contains all the adobeId necessary properties necessary for sign in
	         */
	        _this.signIn = function (redirectRequest) {
	            var url = _this.createRedirectUrl(redirectRequest);
	            UrlHelper$1.setHrefUrl(url);
	        };
	        /**
	         *
	         * @param token { String } value used to authorize a user based on this token value
	         * @param redirectRequest { IRedirectRequest } contains the object properties which are passed to the authorize api
	         */
	        _this.authorizeToken = function (token, redirectRequest) {
	            var parameters = _this.composeRedirectUrl(redirectRequest);
	            if (token) {
	                parameters.user_assertion = token;
	                parameters.user_assertion_type = 'urn:ietf:params:oauth:client-assertion-type:jwt-bearer';
	            }
	            var postForm = _this.createAuthorizeForm(parameters);
	            postForm.submit();
	        };
	        return _this;
	    }
	    /**
	     * returns a html form containing all the properties from the parameter object
	     * @param parameters {object} contains the properties which will be passed to authorize api (as form submit post action)
	     */
	    SignInService.prototype.createAuthorizeForm = function (parameters) {
	        var formAction = Environment$1.baseUrlAdobe + "/ims/authorize/v1";
	        var form = document.createElement("form");
	        form.setAttribute("method", "post");
	        form.setAttribute("action", formAction);
	        var formEl = null;
	        var paramValue = null;
	        var paramValueAsString = '';
	        for (var propertyName in parameters) {
	            paramValue = parameters[propertyName];
	            if (typeof paramValue === 'object') {
	                if (Object.keys(paramValue).length === 0) {
	                    continue;
	                }
	                paramValueAsString = JSON.stringify(paramValue);
	            }
	            else {
	                paramValueAsString = paramValue;
	            }
	            if (paramValueAsString !== '') {
	                formEl = this.createFormElement('input', 'text', propertyName, paramValueAsString);
	                form.appendChild(formEl);
	            }
	        }
	        document.getElementsByTagName("body")[0]
	            .appendChild(form);
	        return form;
	    };
	    /**
	     * create a new html form element; this element will be added to the form
	     * @param inputType {String} input html element type
	     * @param type {String} type of the input element
	     * @param name {String} name of the input element
	     * @param value {String} value for the element
	     */
	    SignInService.prototype.createFormElement = function (inputType, type, name, value) {
	        var formElement = document.createElement(inputType);
	        formElement.setAttribute("type", type);
	        formElement.setAttribute("name", name);
	        formElement.setAttribute("value", value);
	        return formElement;
	    };
	    return SignInService;
	}(BaseSignInService));

	/**
	 * class used to open a new authorization popup
	 */
	var PopupOpener = /** @class */ (function () {
	    function PopupOpener() {
	        var _this = this;
	        /**
	         * refernce of the window object
	         */
	        this.windowObjectReference = null;
	        /**
	         * represents the previous url used to open the popup window
	         */
	        this.previousUrl = '';
	        /**
	         * open the popup window used for authorization
	         * @param url {String} url of the popup window
	         * @param popupSettings {object} contains the popup setting as height and width
	         * @param onPopupMessage {Function} function used to transfer the data from popup
	         */
	        this.openSignInWindow = function (url, popupHaspProp, popupSettings, onPopupMessage) {
	            _this.onProcessLocation = onPopupMessage;
	            if (_this.timerId) {
	                clearInterval(_this.timerId);
	            }
	            // remove any existing event listeners
	            window.removeEventListener('message', _this.receiveMessage);
	            // add the listener for receiving a message from the popup
	            window.addEventListener('message', _this.receiveMessage);
	            // window features
	            var strWindowFeatures = "toolbar=no, menubar=no, width=" + popupSettings.width + ", height=" + popupSettings.height + ", top=" + popupSettings.top + ", left=" + popupSettings.left;
	            if (!_this.windowObjectReference || (_this.windowObjectReference && _this.windowObjectReference.closed)) {
	                /* if the pointer to the window object in memory does not exist or if such pointer exists but the window was closed */
	                _this.windowObjectReference = window.open(url, popupSettings.title, strWindowFeatures);
	            }
	            else if (_this.previousUrl !== url) {
	                /* if the resource to load is different, then we load it in the already opened secondary window and then  we bring such window back on top/in front of its parent window. */
	                _this.windowObjectReference = window.open(url, popupSettings.title, strWindowFeatures);
	                _this.windowObjectReference && _this.windowObjectReference.focus();
	            }
	            else {
	                /* else the window reference must exist and the window is not closed; therefore, we can bring it back on top of any other window with the focus() method. There would be no need to re-create
	                    the window or to reload the referenced resource. */
	                _this.windowObjectReference.focus();
	            }
	            var popupWnd = _this.windowObjectReference || {};
	            if (!popupWnd.opener) {
	                _this.timerId = setInterval(function () {
	                    if (!popupWnd[popupHaspProp]) {
	                        return;
	                    }
	                    clearInterval(_this.timerId);
	                    _this.onProcessLocation && _this.onProcessLocation(popupWnd[popupHaspProp]);
	                    delete popupWnd[popupHaspProp];
	                    _this.windowObjectReference && _this.windowObjectReference.close();
	                }, 500);
	            }
	            // assign the previous URL
	            _this.previousUrl = url;
	        };
	        /**
	         * function used to receive the message from the popup window
	         * @param event {window event} contains the dom event passed by popup window
	         */
	        this.receiveMessage = function (event) {
	            _this.onProcessLocation && _this.onProcessLocation(event.data);
	        };
	    }
	    return PopupOpener;
	}());
	var PopupOpener$1 = new PopupOpener();

	/**
	 * command responsable for user sign in
	 */
	var SignInModalService = /** @class */ (function (_super) {
	    __extends(SignInModalService, _super);
	    /**
	     * constructor of the SignInModalService
	     */
	    function SignInModalService(onPopupMessage, popupSettings) {
	        var _this = _super.call(this) || this;
	        /**
	         * execute the sign in method which redirects the user to the login page
	         * <uml>
	         * start
	         * :CreateRedirectUrl;
	         * :merge api parameters with external parameters
	         * :encode the merged parameters and call the /ims/authorize/v1/${encodedParameters} url
	         * end
	         * </uml>
	         *
	         * @param {IRedirectRequest} redirectRequest. contains all the adobeId necessary properties necessary for sign in
	         * @param onPopupMessage {Function} represents the function used, as a hook, to be triggered when a message comes from popup
	         */
	        _this.signIn = function (redirectRequest) {
	            redirectRequest.state = __assign(__assign({}, redirectRequest.state), { imslibmodal: true });
	            var nonce = redirectRequest.state.nonce;
	            var url = _this.createRedirectUrl(redirectRequest);
	            PopupOpener$1.openSignInWindow(url, nonce, _this.popupSettings, _this.onPopupMessage);
	        };
	        _this.onPopupMessage = onPopupMessage;
	        _this.popupSettings = popupSettings;
	        return _this;
	    }
	    return SignInModalService;
	}(BaseSignInService));

	/**
	 * command responsable for user sign out
	 */
	var SignOutService = /** @class */ (function () {
	    function SignOutService() {
	        /**
	         * @param {IRedirectRequest} redirectRequest. contains all the necessary properties necessary for sign out
	         */
	        this.signOut = function (redirectRequest) {
	            var apiName = 'logout';
	            // eslint-disable-next-line @typescript-eslint/camelcase
	            var apiParameters = redirectRequest.apiParameters, externalParameters = redirectRequest.externalParameters, _a = redirectRequest.adobeIdRedirectUri, adobeIdRedirectUri = _a === void 0 ? '' : _a, clientId = redirectRequest.clientId;
	            var apiExternalParams = RedirectHelper.mergeApiParamsWithExternalParams(apiParameters, externalParameters, apiName);
	            var redirectUrl = RedirectHelper.createDefaultRedirectUrl(adobeIdRedirectUri, clientId, apiExternalParams, apiName);
	            var parameters = __assign(__assign({}, apiExternalParams), { client_id: clientId, redirect_uri: redirectUrl, jslVersion: Environment$1.jslibver });
	            var queryStrings = UrlHelper$1.uriEncodeData(parameters);
	            var url = Environment$1.baseUrlAdobe + "/ims/logout/v1?" + queryStrings;
	            UrlHelper$1.replaceUrl(url);
	        };
	    }
	    return SignOutService;
	}());

	/**
	 * class used to store the modal settings
	 */
	var PopupSettings = /** @class */ (function () {
	    function PopupSettings(data) {
	        if (data === void 0) { data = {}; }
	        this.title = 'Adobe ID';
	        this.width = 600;
	        this.top = 100;
	        this.left = 100;
	        var _a = data.title, title = _a === void 0 ? 'Adobe ID' : _a, _b = data.width, width = _b === void 0 ? 600 : _b, _c = data.height, height = _c === void 0 ? 700 : _c, _d = data.top, top = _d === void 0 ? 100 : _d, _e = data.left, left = _e === void 0 ? 100 : _e;
	        this.title = title;
	        this.width = width;
	        this.height = height;
	        this.top = top;
	        this.left = left;
	    }
	    return PopupSettings;
	}());

	/**
	 * class used to encapsulate the token and expiration ms;
	 * this values are passed from outside of the library by using adobeid
	 */
	var StandaloneToken = /** @class */ (function () {
	    function StandaloneToken(data) {
	        this.token = '';
	        /**
	         * representing the session identifier
	         */
	        this.sid = '';
	        this.expirems = 0;
	        var token = data.token, expirems = data.expirems;
	        this.token = token;
	        this.expirems = expirems;
	    }
	    return StandaloneToken;
	}());

	/**
	 * Enumeration values used for reAuthenticate method
	 *
	 * Default value is check
	 */
	var IReauth;
	(function (IReauth) {
	    /**
	     * Forces the reauth process to show the credentials screen to the user
	     */
	    IReauth["force"] = "force";
	    /**
	     * Starts the reauthentication check flow. Which won't prompt the user for reauthentication if the user already performed an authentication in a period of time configured on the client id.
	     */
	    IReauth["check"] = "check";
	})(IReauth || (IReauth = {}));

	/**
	 * Enumeration values used for available grant types
	 *
	 * Default value is token
	 */
	var IGrantTypes;
	(function (IGrantTypes) {
	    /**
	     * token
	     */
	    IGrantTypes["token"] = "token";
	    /**
	     * authorization code
	     */
	    IGrantTypes["code"] = "code";
	})(IGrantTypes || (IGrantTypes = {}));

	/**
	 * class used to store the analytics parameters
	 */
	var AnalyticsParameters = /** @class */ (function () {
	    function AnalyticsParameters() {
	        /**
	        * represents the application code value;
	        * this value (if exists) will be sent to the server.
	        */
	        this.appCode = '';
	        /**
	         * represents the application version value;
	         * this value (if exists) will be sent to the server.
	         */
	        this.appVersion = '';
	    }
	    return AnalyticsParameters;
	}());

	var ONE_HOUR$1 = 60 * 60 * 3600;
	var CodeChallenge = /** @class */ (function () {
	    function CodeChallenge() {
	        this.storage = StorageFactory$1.getAvailableStorage();
	    }
	    CodeChallenge.prototype.b64Uri = function (r) {
	        return btoa(r).replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/, "");
	    };
	    /**
	     *
	     * @param nonce {String} represents the key used to store the code verifier
	     * @param verifierLength {number} represents the verifier length
	     * @returns {ICodeChallenge} verifier and challenge codes
	     */
	    CodeChallenge.prototype.createCodeChallenge = function (nonce, verifierLength) {
	        var _this = this;
	        if (verifierLength === void 0) { verifierLength = 43; }
	        var cryptoObj = window['msCrypto'] || window.crypto;
	        var verifier = this.b64Uri(Array.prototype.map.call(cryptoObj.getRandomValues(new Uint8Array(verifierLength)), function (r) {
	            return String.fromCharCode(r);
	        }).join("")).substring(0, verifierLength);
	        var uintVerifierArr = new Uint8Array(verifier.length);
	        for (var i = 0; i < verifier.length; i++)
	            uintVerifierArr[i] = verifier.charCodeAt(i);
	        var cryptoDigest = cryptoObj.subtle.digest('SHA-256', uintVerifierArr);
	        return new Promise(function (resolve, reject) {
	            if (window['CryptoOperation']) {
	                cryptoDigest.onerror = function (err) { return reject(err); };
	                cryptoDigest.oncomplete = function (response) {
	                    var uintArr = new Uint8Array(response.target.result);
	                    var challenge = _this.b64Uri(String.fromCharCode.apply(String, __spread(uintArr)));
	                    return resolve(_this.saveVerifierAndReturn(nonce, {
	                        verifier: verifier,
	                        challenge: challenge,
	                    }));
	                };
	            }
	            else {
	                cryptoDigest.then(function (response) {
	                    var uintArr = new Uint8Array(response);
	                    var challenge = _this.b64Uri(String.fromCharCode.apply(String, __spread(uintArr)));
	                    return resolve(_this.saveVerifierAndReturn(nonce, {
	                        verifier: verifier,
	                        challenge: challenge,
	                    }));
	                });
	            }
	        });
	    };
	    /**
	     *
	     * @param nonce {String} represents the key used to store the code verifier
	     * @param challengeAndVerifier {ICodeChallenge} represents the code challenge and code verifier
	     * @returns ICodeChallenge
	     */
	    CodeChallenge.prototype.saveVerifierAndReturn = function (nonce, challengeAndVerifier) {
	        var verifiers = this.getVerifierValuesFromStorage();
	        var storageValue = {
	            verifier: challengeAndVerifier.verifier || '',
	            expiry: new Date().getTime().toString()
	        };
	        verifiers[nonce] = storageValue;
	        this.storage.setItem('verifiers', JSON.stringify(verifiers));
	        return Promise.resolve(challengeAndVerifier);
	    };
	    /**
	   * Returns the nonce values from storage as an Object or null
	   * @returns {IDictionary | null}
	   */
	    CodeChallenge.prototype.getVerifierValuesFromStorage = function () {
	        var storageVerifiers = this.storage.getItem('verifiers');
	        var verifiers = storageVerifiers ? JSON.parse(storageVerifiers) : {};
	        return this.clearOlderVerifiers(verifiers);
	    };
	    CodeChallenge.prototype.clearOlderVerifiers = function (verifiers, olderThan) {
	        if (olderThan === void 0) { olderThan = ONE_HOUR$1; }
	        var oneHourAgo = Date.now() - olderThan;
	        var expiry = 0;
	        Object.keys(verifiers).forEach(function (key) {
	            expiry = parseInt(verifiers[key]);
	            if (expiry < oneHourAgo) {
	                delete verifiers[key];
	            }
	        });
	        return verifiers;
	    };
	    /**
	     * rerturns the verifier from storage
	     * @param key {String} represents the key used to stora the verfier
	     */
	    CodeChallenge.prototype.getVerifierByKey = function (key) {
	        var verifiers = this.getVerifierValuesFromStorage();
	        var verifierObj = verifiers ? verifiers[key] : {};
	        delete verifiers[key];
	        this.storage.setItem('verifiers', JSON.stringify(verifiers));
	        return verifierObj ? verifierObj['verifier'] : '';
	    };
	    return CodeChallenge;
	}());

	/**
	 *  Class used to store the adobe data values.
	 *
	 *  Ims library will use these values for all operations
	 */
	var AdobeIdThinData = /** @class */ (function () {
	    /**
	     * @constructor Create the adobeIdData object with all necessary properties from adobeData input paramater
	     *
	     * It uses the input adobeData parameter or the object stored in window.adobeid
	     */
	    function AdobeIdThinData(adobeData) {
	        if (adobeData === void 0) { adobeData = null; }
	        /**
	         * represents the class used to store the analytics parameters
	         */
	        this.analyticsParameters = new AnalyticsParameters();
	        /**
	          @property Object containing various custom parameters for IMS.
	          This object is used in case a custom API parameter is desired to be sent to the back-end.
	      
	          E.G. { logout: 'your_custom_value' }
	      
	          The list of api's which can be customized are: authorize, validate_token, profile, userinfo, logout, logout_token, check, providers, ijt
	        */
	        this.api_parameters = {};
	        /**
	          @property {string} Localization value used by ims library.
	          
	          Default value is `en_US`
	        */
	        this.locale = "";
	        /**
	         * @property {string} - The scopes used to acquire access tokens. A comma separated list of client scopes.
	         * No whitespace.
	         * Default scopes: AdobeID
	         */
	        this.scope = "AdobeID";
	        /**
	         * @property {string} - The client id used by ims library
	         */
	        this.client_id = "";
	        /**
	         * represents the used environment; default is prod and in case the value is stg1, the stage environment is used
	         */
	        this.environment = IEnvironment.PROD;
	        /**
	         *  use the local storage for token management; default value is false;
	         */
	        this.useLocalStorage = false;
	        /** @function {adobeid.onReady} [onReady] - Function to be executed once imslib.js has been fully
	         * initialized.
	         */
	        this.onReady = null;
	        var adobeid = adobeData ? adobeData : window[AdobeIdKey];
	        if (!adobeid) {
	            throw new Error("Please provide adobeId information");
	        }
	        var api_parameters = adobeid.api_parameters, client_id = adobeid.client_id, locale = adobeid.locale, scope = adobeid.scope, ijt = adobeid.ijt, _a = adobeid.environment, environment = _a === void 0 ? IEnvironment.PROD : _a, redirect_uri = adobeid.redirect_uri, useLocalStorage = adobeid.useLocalStorage, logsEnabled = adobeid.logsEnabled, onReady = adobeid.onReady;
	        this.environment = environment;
	        this.api_parameters = api_parameters ? api_parameters : {};
	        this.client_id = client_id;
	        this.locale = locale || DEFAULT_LANGUAGE;
	        this.scope = scope ? scope.replace(/\s/gi, '') : '';
	        this.redirect_uri = redirect_uri;
	        this.ijt = ijt;
	        this.useLocalStorage = useLocalStorage;
	        if (logsEnabled) {
	            Log$1.enableLogging();
	        }
	        else {
	            Log$1.disableLogging();
	        }
	        this.onReady = onReady ? onReady : null;
	        this.fillAnalityticsParameters(adobeid);
	        Environment$1.loadEnvironment(environment);
	    }
	    /**
	     * fill the analytic parameters with the values provided by adobeid data
	     * @param adobeid represents the adobeid data provided to library
	     */
	    AdobeIdThinData.prototype.fillAnalityticsParameters = function (adobeid) {
	        var _a = adobeid.analytics, _b = _a === void 0 ? {} : _a, _c = _b.appCode, appCode = _c === void 0 ? "" : _c, _d = _b.appVersion, appVersion = _d === void 0 ? "" : _d;
	        var analyticsParameters = this.analyticsParameters;
	        analyticsParameters.appCode = appCode;
	        analyticsParameters.appVersion = appVersion;
	    };
	    /**
	     * Function used by IMSLib to use only the neccesarry properties from AdobeIdData for social provider
	     * @param providerName provider name used for sign in
	     * @param requestedParameters {Object} the external parameters used for signin and reauth methods
	     * @param contextToBePassedOnRedirect {any | undefined} represents the context which is passed during redirect
	     */
	    AdobeIdThinData.prototype.createSocialProviderRedirectRequest = function (providerName, requestedParameters, contextToBePassedOnRedirect, nonce, grantType) {
	        var params = {
	            idp_flow: "social.deep_link.web",
	            provider_id: providerName,
	        };
	        var signInParams = __assign(__assign({}, requestedParameters), params);
	        return this.createRedirectRequest(signInParams, contextToBePassedOnRedirect, nonce, grantType);
	    };
	    /**
	     * Function used by ims to use only the neccesarry properties from AdobeIdData on sign in and reauth methods
	     * @param requestedParameters {Object} the external parameters used for signin and reauth methods
	     * @param contextToBePassedOnRedirect {any | undefined} represents the context which is passed during redirect
	     * @param nonce {string} - string representing the nonce value used for CSRF
	     * @param reauth {string}; represents the re authenticate value. available values are: check and force. default value is "check"
	     */
	    AdobeIdThinData.prototype.createReAuthenticateRedirectRequest = function (requestedParameters, contextToBePassedOnRedirect, nonce, reauth, grantType) {
	        if (reauth === void 0) { reauth = IReauth.check; }
	        if (grantType === void 0) { grantType = IGrantTypes.token; }
	        var params = {
	            reauth: reauth,
	        };
	        var reauthParams = __assign(__assign({}, requestedParameters), params);
	        return this.createRedirectRequest(reauthParams, contextToBePassedOnRedirect, nonce, grantType);
	    };
	    /**
	     * Function used by ims to use only the neccesarry properties from AdobeIdData on sign in and reauth methods
	     * @param requestedParameters {Object} the external parameters used for signin and reauth methods
	     * @param contextToBePassedOnRedirect {any | undefined} represents the context which is passed during redirect
	     */
	    AdobeIdThinData.prototype.createSignUpRedirectRequest = function (requestedParameters, contextToBePassedOnRedirect, nonce) {
	        var signupParams = __assign(__assign({}, requestedParameters), { idp_flow: "create_account" });
	        return this.createRedirectRequest(signupParams, contextToBePassedOnRedirect, nonce, IGrantTypes.token);
	    };
	    /**
	     * Function used by ims to use only the neccesarry properties from AdobeIdData on sign in and reauth methods
	     * @param externalParameters {Object} the external parameters used for signin and reauth methods
	     * @param contextToBePassedOnRedirect {any | undefined} represents the context which is passed during redirect
	     * @param nonce {string} - string representing the nonce value used for CSRF
	     * @param grantType {IGrantTypes} represents the grant type used for sign in flow
	     */
	    AdobeIdThinData.prototype.createRedirectRequest = function (externalParameters, contextToBePassedOnRedirect, nonce, grantType) {
	        var _this = this;
	        var _a = this, _b = _a.api_parameters, apiParameters = _b === void 0 ? {} : _b, clientId = _a.client_id, _c = _a.redirect_uri, adobeIdRedirectUri = _c === void 0 ? '' : _c, scope = _a.scope, locale = _a.locale;
	        var state = this.createRedirectState(contextToBePassedOnRedirect, nonce);
	        var redirectRequest = {
	            adobeIdRedirectUri: adobeIdRedirectUri,
	            apiParameters: apiParameters,
	            clientId: clientId,
	            externalParameters: externalParameters,
	            scope: scope,
	            locale: locale,
	            response_type: grantType,
	            state: state,
	        };
	        if (grantType === IGrantTypes.token) {
	            return Promise.resolve(redirectRequest);
	        }
	        var codeChallenge = new CodeChallenge();
	        return codeChallenge.createCodeChallenge(nonce).then(function (challengeResponse) {
	            externalParameters.code_challenge = challengeResponse.challenge;
	            externalParameters.code_challenge_method = 'S256';
	            var codeState = _this.createRedirectState(contextToBePassedOnRedirect, nonce);
	            redirectRequest.state = codeState;
	            return Promise.resolve(redirectRequest);
	        });
	    };
	    /**
	     * create the stae object used during redirect; if the adobeid.context is empty and no analytics parameters, the state will ne null
	     * @param context represents the external parameters
	     */
	    AdobeIdThinData.prototype.createRedirectState = function (context, nonce) {
	        var _a = this.analyticsParameters, _b = _a.appCode, appCode = _b === void 0 ? "" : _b, _c = _a.appVersion, appVersion = _c === void 0 ? "" : _c;
	        var state = context === undefined
	            ? {}
	            : {
	                context: context,
	            };
	        if (appCode) {
	            state["ac"] = appCode;
	        }
	        if (appVersion) {
	            state["av"] = appVersion;
	        }
	        state["jslibver"] = Environment$1.jslibver;
	        state["nonce"] = nonce;
	        return Object.keys(state).length ? state : null;
	    };
	    AdobeIdThinData.prototype.triggerOnReady = function () {
	        this.onReady && this.onReady(undefined);
	    };
	    return AdobeIdThinData;
	}());

	/**
	 *  Class used to store the adobe data values.
	 *
	 *  Ims library will use these values for all operations
	 */
	var AdobeIdData = /** @class */ (function (_super) {
	    __extends(AdobeIdData, _super);
	    /**
	     * @constructor Create the adobeIdData object with all necessary properties from adobeData input paramater
	     *
	     * It uses the input adobeData parameter or the object stored in window.adobeid
	     */
	    function AdobeIdData(adobeData) {
	        if (adobeData === void 0) { adobeData = null; }
	        var _this = _super.call(this, adobeData) || this;
	        /** @function {adobeid.onAccessTokenHasExpired} onAccessTokenHasExpired
	         *  Function to be executed if the 'access_token' is invalid.
	         */
	        _this.onAccessTokenHasExpired = null;
	        /**  @function {adobeid.onAccessToken} - Function to be executed once imslib.js has acquired
	         * an `access_token`.
	         */
	        _this.onAccessToken = null;
	        /**
	         * @function {adobeid.onReauthAccessToken} Function used to trigger the reauth access token
	         */
	        _this.onReauthAccessToken = null;
	        /**
	         * @function {adobeid.onError}
	         * Function used to notify external libraries for ims errors
	         */
	        _this.onError = null;
	        /**
	         * Handlers object is used to invoke the adobe id data events.
	         *
	         * When a token, profile is aquired, or token is expired and library is fully intialized, an event is triggered
	         */
	        _this.handlers = {
	            triggerOnAccessToken: function (data) {
	                _this.onAccessToken && _this.onAccessToken(data);
	            },
	            triggerOnReauthAccessToken: function (data) {
	                _this.onReauthAccessToken && _this.onReauthAccessToken(data);
	            },
	            triggerOnAccessTokenHasExpired: function () {
	                _this.onAccessTokenHasExpired && _this.onAccessTokenHasExpired();
	            },
	            triggerOnReady: function (context) {
	                if (context === void 0) { context = null; }
	                _this.onReady && _this.onReady(context);
	            },
	            triggerOnError: function (errorType, error) {
	                _this.onError && _this.onError(errorType, error);
	            }
	        };
	        var adobeid = adobeData ? adobeData : window[AdobeIdKey];
	        if (!adobeid) {
	            throw new Error("Please provide adobeId information");
	        }
	        var standalone = adobeid.standalone, autoValidateToken = adobeid.autoValidateToken, _a = adobeid.modalSettings, modalSettings = _a === void 0 ? {} : _a, _b = adobeid.modalMode, modalMode = _b === void 0 ? false : _b, onAccessToken = adobeid.onAccessToken, onReauthAccessToken = adobeid.onReauthAccessToken, onAccessTokenHasExpired = adobeid.onAccessTokenHasExpired, onReady = adobeid.onReady, onError = adobeid.onError;
	        if (standalone && standalone.token) {
	            _this.standalone = new StandaloneToken(standalone);
	        }
	        _this.modalSettings = new PopupSettings(modalSettings);
	        _this.modalMode = modalMode;
	        _this.autoValidateToken = !!autoValidateToken;
	        _this.onAccessToken = onAccessToken ? onAccessToken : null;
	        _this.onReauthAccessToken = onReauthAccessToken ? onReauthAccessToken : null;
	        _this.onAccessTokenHasExpired = onAccessTokenHasExpired
	            ? onAccessTokenHasExpired
	            : null;
	        _this.onReady = onReady ? onReady : null;
	        _this.onError = onError ? onError : null;
	        return _this;
	    }
	    /**
	     * Function used by IMSLib to use only the neccesarry properties from AdobeIdData for social provider
	     * @param providerName provider name used for sign in
	     * @param requestedParameters {Object} the external parameters used for signin and reauth methods
	     * @param contextToBePassedOnRedirect {any | undefined} represents the context which is passed during redirect
	     */
	    AdobeIdData.prototype.createSocialProviderRedirectRequest = function (providerName, requestedParameters, contextToBePassedOnRedirect, nonce, grantType) {
	        if (grantType === void 0) { grantType = IGrantTypes.token; }
	        var params = {
	            idp_flow: "social.deep_link.web",
	            provider_id: providerName,
	        };
	        var signInParams = __assign(__assign({}, requestedParameters), params);
	        return this.createRedirectRequest(signInParams, contextToBePassedOnRedirect, nonce, grantType);
	    };
	    /**
	     * Function used by ims to use only the neccesarry properties from AdobeIdData on sign in and reauth methods
	     * @param requestedParameters {Object} the external parameters used for signin and reauth methods
	     * @param contextToBePassedOnRedirect {any | undefined} represents the context which is passed during redirect
	     * @param nonce {string} - string representing the nonce value used for CSRF
	     * @param reauth {string}; represents the re authenticate value. available values are: check and force. default value is "check"
	     */
	    AdobeIdData.prototype.createReAuthenticateRedirectRequest = function (requestedParameters, contextToBePassedOnRedirect, nonce, reauth, grantType) {
	        if (reauth === void 0) { reauth = IReauth.check; }
	        if (grantType === void 0) { grantType = IGrantTypes.token; }
	        var params = {
	            reauth: reauth,
	        };
	        var reauthParams = __assign(__assign({}, requestedParameters), params);
	        return this.createRedirectRequest(reauthParams, contextToBePassedOnRedirect, nonce, grantType);
	    };
	    /**
	     * Function used by ims to use only the neccesarry properties from AdobeIdData on sign in and reauth methods
	     * @param requestedParameters {Object} the external parameters used for signin and reauth methods
	     * @param contextToBePassedOnRedirect {any | undefined} represents the context which is passed during redirect
	     */
	    AdobeIdData.prototype.createSignUpRedirectRequest = function (requestedParameters, contextToBePassedOnRedirect, nonce, grantType) {
	        if (grantType === void 0) { grantType = IGrantTypes.token; }
	        var signupParams = __assign(__assign({}, requestedParameters), { idp_flow: "create_account" });
	        return this.createRedirectRequest(signupParams, contextToBePassedOnRedirect, nonce, grantType);
	    };
	    return AdobeIdData;
	}(AdobeIdThinData));

	/**
	 * class used for caching the api calls for a second.
	 * The flow is:
	 * 1. make api call from ImsLib
	 * 2. if the Debouncer cache already contains a response for that api/parameters -> return the cashed response
	 *
	 */
	var Debouncer = /** @class */ (function () {
	    function Debouncer() {
	        var _this = this;
	        /**
	         * debounce time value; one second
	         */
	        this.DEBOUNCE_TIME = 1000;
	        /**
	         * dictionary with all executed methods for the last second
	         */
	        this.cache = {};
	        /**
	         *
	         * @param url {String} - url used to make the api
	         * @param bodyParams {String} - the hash associated with the request parameters
	         * @param response {ApiResponse} - data received as a http response
	         */
	        this.storeApiResponse = function (url, bodyParams, response) {
	            if (url === void 0) { url = ''; }
	            if (bodyParams === void 0) { bodyParams = ''; }
	            _this.cacheApiResponse(url, bodyParams, response);
	        };
	    }
	    /**
	     * starts to execute a specific API. if there is a cached response, it will be returned
	     * @param url - api url
	     * @param parameters - represents the parameters used to call the api
	     */
	    Debouncer.prototype.getCachedApiResponse = function (url, parameters) {
	        if (parameters === void 0) { parameters = ''; }
	        var hash = typeof parameters === 'string' ? parameters : JSON.stringify(parameters);
	        var cachedUrlValues = this.cache[url];
	        if (!cachedUrlValues) {
	            return null;
	        }
	        var cachedHash = cachedUrlValues[hash];
	        if (!cachedHash) {
	            return null;
	        }
	        return cachedHash.data;
	    };
	    /**
	     *
	     * @param url {String} - url used to make the api
	     * @param bodyParams {String} - the hash associated with the request parameters
	     * @param response {ApiResponse} - data received as a http response
	     */
	    Debouncer.prototype.cacheApiResponse = function (url, bodyParams, response) {
	        if (url === void 0) { url = ''; }
	        if (bodyParams === void 0) { bodyParams = ''; }
	        var cachedUrlValues = this.cache[url];
	        if (!cachedUrlValues) {
	            cachedUrlValues = {};
	            this.cache[url] = cachedUrlValues;
	        }
	        var timerId = this.createClearCachedDataTimer(url, bodyParams);
	        cachedUrlValues[bodyParams] = {
	            timerId: timerId,
	            data: __assign({}, response),
	        };
	    };
	    /**
	     * create the timer for a url/hash
	     * @param url - {string} - represents the url used to make the http call
	     * @param hash {String} - the hash associated with the request parameters
	     */
	    Debouncer.prototype.createClearCachedDataTimer = function (url, hash) {
	        var _this = this;
	        var timerId = setTimeout(function () {
	            var cachedUrlValues = _this.cache[url] || {};
	            var methodValues = cachedUrlValues[hash];
	            if (!methodValues) {
	                return;
	            }
	            if (methodValues && methodValues.timerId) {
	                clearTimeout(methodValues.timerId);
	                delete cachedUrlValues[hash];
	            }
	        }, this.DEBOUNCE_TIME);
	        return timerId;
	    };
	    return Debouncer;
	}());
	var Debouncer$1 = new Debouncer();

	/**
	 * class used to store the ride errors after a check token call
	 */
	var RideException = /** @class */ (function () {
	    function RideException(code, jump) {
	        /**
	         * new redirect url in case of a ride error
	         */
	        this.jump = '';
	        this.code = code;
	        this.jump = jump;
	    }
	    return RideException;
	}());

	/**
	 * class used to pass the http errors to external applications
	 */
	var HttpErrorResponse = /** @class */ (function () {
	    function HttpErrorResponse(data) {
	        var error = data.error, _a = data.retryAfter, retryAfter = _a === void 0 ? 0 : _a, _b = data.message, message = _b === void 0 ? '' : _b;
	        this.error = error;
	        this.retryAfter = retryAfter;
	        this.message = message;
	    }
	    return HttpErrorResponse;
	}());

	/**
	 * class used to create a IHttpErrorResponse object in case the code is != 200
	 */
	var HttpErrorHandler = /** @class */ (function () {
	    function HttpErrorHandler() {
	    }
	    HttpErrorHandler.prototype.verify = function (exception) {
	        var status = exception.status, data = exception.data;
	        if (!status) {
	            return new HttpErrorResponse({
	                error: 'networkError',
	                message: data || ''
	            });
	        }
	        if (status == 401) {
	            return new HttpErrorResponse({
	                error: 'unauthorized',
	            });
	        }
	        var rideException = this.parseTokenResponseForRideErrors(data);
	        if (rideException) {
	            return rideException;
	        }
	        if (status == 409) {
	            return data;
	        }
	        if (status == 429) {
	            return new HttpErrorResponse({
	                error: 'rate_limited',
	                retryAfter: data.retryAfter ? parseInt(data.retryAfter) : 10,
	            });
	        }
	        if (status.toString().match(/5\d{2}/g)) {
	            return new HttpErrorResponse({
	                error: 'server_error'
	            });
	        }
	        return null;
	    };
	    /**
	        * parse the check token response to see if there are any ride errors
	        * @param tokenResponse represents the response from check token call
	        * @returns a RideException or null in case that the error code is not one from RideExceptions
	        */
	    HttpErrorHandler.prototype.parseTokenResponseForRideErrors = function (refreshException) {
	        if (!refreshException) {
	            return null;
	        }
	        var error = refreshException.error, jump = refreshException.jump;
	        if (!error) {
	            return null;
	        }
	        var isRideError = error.indexOf('ride_') === 0;
	        if (!isRideError) {
	            return null;
	        }
	        var jumpValue = jump ? jump : '';
	        return new RideException(error, jumpValue);
	    };
	    /**
	     * check if the exception status has the code equal 401
	     * @param exception represents the exception caught during get profile method
	     * @returns true if the status code is 401, otherwise false
	     */
	    HttpErrorHandler.prototype.isUnauthorizedException = function (exception) {
	        var _a = exception.status, status = _a === void 0 ? 0 : _a;
	        return status === 401;
	    };
	    return HttpErrorHandler;
	}());
	var HttpErrorHandler$1 = new HttpErrorHandler();

	/**
	 * class used to store the xhr error response
	 */
	var ApiResponse = /** @class */ (function () {
	    function ApiResponse(status, message) {
	        this.status = 0;
	        this.data = '';
	        this.status = status;
	        this.data = this.toJson(message);
	    }
	    ApiResponse.prototype.toJson = function (value) {
	        try {
	            if (typeof value !== 'string') {
	                return value;
	            }
	            return JSON.parse(value);
	        }
	        catch (_a) {
	            return value;
	        }
	    };
	    return ApiResponse;
	}());

	var Xhr = new /** @class */ (function () {
	    function Xhr() {
	    }
	    Xhr.prototype.http = function (options) {
	        return new Promise(function (resolve, reject) {
	            var xmlHttpObject = window.XMLHttpRequest;
	            var xhr = new xmlHttpObject();
	            xhr.withCredentials = true;
	            xhr.open(options.method, options.url, true);
	            var addHeaders = function (headers) {
	                if (!headers) {
	                    return;
	                }
	                Object.keys(headers).forEach(function (key) {
	                    xhr.setRequestHeader(key, headers[key]);
	                });
	            };
	            xhr.onload = function onload() {
	                if (this.status >= 200 && this.status < 300) {
	                    return resolve(new ApiResponse(this.status, this.response));
	                }
	                return reject(new ApiResponse(this.status, this.response));
	            };
	            xhr.onerror = function onerror() {
	                var error = new ApiResponse(this.status, this.response);
	                return reject(error);
	            };
	            addHeaders(options.headers);
	            xhr.send(options.data);
	        });
	    };
	    Xhr.prototype.post = function (url, data, headers) {
	        if (headers === void 0) { headers = {}; }
	        return this.http({
	            headers: headers,
	            method: 'POST',
	            url: url,
	            data: data,
	        });
	    };
	    Xhr.prototype.get = function (url, headers) {
	        if (headers === void 0) { headers = {}; }
	        return this.http({
	            headers: headers,
	            method: 'GET',
	            url: url,
	        });
	    };
	    return Xhr;
	}());

	var ImsXhr = new /** @class */ (function () {
	    function ImsXhr() {
	        this.triggerOnError = null;
	    }
	    /**
	     * check if the cache contains data for the same url and parameters value;
	     * if true, returns the cached value otherwise make the http call
	     * @param url - url used to make a POST http request
	     * @param data - dat passed to the back-end
	     * @param config - http configuration
	    */
	    ImsXhr.prototype.post = function (url, data, config) {
	        var _this = this;
	        if (config === void 0) { config = {}; }
	        var cachedData = Debouncer$1.getCachedApiResponse(url, data);
	        if (cachedData) {
	            var status = cachedData.status, data_1 = cachedData.data;
	            return status === 200 ? Promise.resolve(data_1) : Promise.reject(data_1);
	        }
	        return Xhr.post(url, data, config)
	            .then(function (response) {
	            return _this.storeApiResponse(url, JSON.stringify(data), response);
	        })
	            .catch(function (ex) {
	            return _this.verifyError(url, JSON.stringify(data), ex);
	        });
	    };
	    /**
	     * check if the cache contains data for the input url
	     * if true, returns the cached value otherwise make the http call
	     * @param url - url used to make a POST http request
	     * @param config - contains xmlhttprequest headers
	    */
	    ImsXhr.prototype.get = function (url, config) {
	        var _this = this;
	        if (config === void 0) { config = {}; }
	        var cachedData = Debouncer$1.getCachedApiResponse(url);
	        if (cachedData) {
	            var status = cachedData.status, data = cachedData.data;
	            return status === 200 ? Promise.resolve(data) : Promise.reject(data);
	        }
	        return Xhr.get(url, config)
	            .then(function (response) {
	            return _this.storeApiResponse(url, '', response);
	        })
	            .catch(function (ex) {
	            return _this.verifyError(url, '', ex);
	        });
	    };
	    /**
	     *
	     * @param exception {ApiResponse} - represents the back-end service
	     * @param url: {string} - url used to call the api
	     * @param bodyParams: {string} represents the body parameters
	     */
	    ImsXhr.prototype.verifyError = function (url, bodyParams, exception) {
	        this.storeApiResponse(url, bodyParams, exception);
	        var httpErrorResponse = HttpErrorHandler$1.verify(exception);
	        return Promise.reject(httpErrorResponse || exception.data);
	    };
	    /**
	    *
	    * @param response {any} - represents the back-end service
	    * @param url url: {string} - url used to call the api
	    * @param bodyParams {string} represents the body parameters
	    */
	    ImsXhr.prototype.storeApiResponse = function (url, bodyParams, response) {
	        if (bodyParams === void 0) { bodyParams = ''; }
	        Debouncer$1.storeApiResponse(url, bodyParams, response);
	        return Promise.resolve(response.data);
	    };
	    return ImsXhr;
	}());

	/**
	 * class used as a entry point for Ims api's
	 * @todo discuss rate limit --> code 429 on http response.
	 */
	var ImsApis = /** @class */ (function () {
	    /**
	     * imsApis constructor;
	     */
	    function ImsApis(apiParameters) {
	        if (apiParameters === void 0) { apiParameters = {}; }
	        this.CONTENT_FORM_ENCODED = 'application/x-www-form-urlencoded;charset=utf-8';
	        this.apiParameters = apiParameters;
	    }
	    /**
	     * validate the input token
	     * @param request IAuthorizedApiRequest contains clientId and token information
	     */
	    ImsApis.prototype.validateToken = function (request) {
	        var token = request.token, client_id = request.client_id;
	        var data = UrlHelper$1.uriEncodeData(__assign(__assign({}, ApiHelpers$1.getCustomApiParameters(this.apiParameters, 'validate_token')), { type: 'access_token', client_id: client_id,
	            token: token }));
	        var url = Environment$1.baseUrlAdobe + "/ims/validate_token/v1?jslVersion=" + Environment$1.jslibver;
	        return ImsXhr.post(url, data, this.formEncoded());
	    };
	    /**
	     * retrieve the profile based on the input token
	     * @param request IAuthorizedApiRequest contains clientId and token information
	     */
	    ImsApis.prototype.getProfile = function (request) {
	        var token = request.token, client_id = request.client_id;
	        var additionalParams = __assign({}, ApiHelpers$1.getCustomApiParameters(this.apiParameters, 'profile'));
	        var config = this.createAuthorizationHeader(token);
	        var queryStrings = UrlHelper$1.uriEncodeData(__assign({ client_id: client_id }, additionalParams));
	        var url = Environment$1.baseUrlAdobe + "/ims/profile/v1?" + queryStrings + "&jslVersion=" + Environment$1.jslibver;
	        return ImsXhr.get(url, config);
	    };
	    /**
	     * @returns the user info based on the input token
	     * @param request IAuthorizedApiRequest contains clientId and token information
	     */
	    ImsApis.prototype.getUserInfo = function (request) {
	        var token = request.token, client_id = request.client_id;
	        var additionalParams = __assign({}, ApiHelpers$1.getCustomApiParameters(this.apiParameters, 'userinfo'));
	        var config = this.createAuthorizationHeader(token);
	        var queryStrings = UrlHelper$1.uriEncodeData(__assign({ client_id: client_id }, additionalParams));
	        var url = Environment$1.baseUrlAdobe + "/ims/userinfo/v1?" + queryStrings + "&jslVersion=" + Environment$1.jslibver;
	        return ImsXhr.get(url, config);
	    };
	    /**
	      * invalidate the input token
	      * @param request IAuthorizedApiRequest contains clientId and token information
	      */
	    ImsApis.prototype.logoutToken = function (apiRequest) {
	        var client_id = apiRequest.client_id, access_token = apiRequest.token;
	        var additionalParams = __assign({}, ApiHelpers$1.getCustomApiParameters(this.apiParameters, 'logout_token'));
	        var url = Environment$1.baseUrlServices + "/ims/logout/v1?jslVersion=" + Environment$1.jslibver;
	        return ImsXhr.post(url, __assign({ client_id: client_id,
	            access_token: access_token }, additionalParams));
	    };
	    /**
	     * Does an API to check the cookie status of the browser.
	     */
	    ImsApis.prototype.checkStatus = function () {
	        var url = Environment$1.baseUrlServices + "/ims/check/v1/status";
	        return ImsXhr.get(url);
	    };
	    /**
	     * @returns a new token
	     * @param request IUnAuthorizedApiRequest contains clientId information
	     * @param userId { string } represents the user id associated with logged user
	     * @todo We will probably need also check token v5
	     */
	    ImsApis.prototype.checkToken = function (apiRequest, externalParameters, userId) {
	        var client_id = apiRequest.client_id, scope = apiRequest.scope;
	        var additionalParams = __assign({}, ApiHelpers$1.mergeExternalParameters(externalParameters, this.apiParameters, 'check_token'));
	        var url = Environment$1.baseUrlServices + "/ims/check/v6/token?jslVersion=" + Environment$1.jslibver;
	        var apiBody = __assign(__assign({}, additionalParams), { client_id: client_id,
	            scope: scope });
	        if (userId) {
	            apiBody.user_id = userId;
	        }
	        var data = UrlHelper$1.uriEncodeData(apiBody);
	        return ImsXhr.post(url, data, this.formEncoded());
	    };
	    /**
	     * @returns a new token and profile for the existing user
	     * @param request IUnAuthorizedApiRequest contains clientId information
	     * @param userId contains the user id of the logged user
	     * https://wiki.corp.adobe.com/display/ims/IMS+API+-+check+token#IMSAPIchecktoken-Version6
	     */
	    ImsApis.prototype.switchProfile = function (apiRequest, externalParameters, userId) {
	        if (userId === void 0) { userId = ''; }
	        var client_id = apiRequest.client_id, _a = apiRequest.scope, scope = _a === void 0 ? '' : _a;
	        var additionalParams = __assign({}, ApiHelpers$1.mergeExternalParameters(externalParameters, this.apiParameters, 'check_token'));
	        var url = Environment$1.baseUrlServices + "/ims/check/v6/token?jslVersion=" + Environment$1.jslibver;
	        var data = UrlHelper$1.uriEncodeData(__assign(__assign({}, additionalParams), { client_id: client_id,
	            scope: scope, user_id: userId }));
	        return ImsXhr.post(url, data, this.formEncoded());
	    };
	    /**
	     * @returns list of api providers
	     * @param request IUnAuthorizedApiRequest contains clientId information
	     */
	    ImsApis.prototype.listSocialProviders = function (apiRequest) {
	        var client_id = apiRequest.client_id;
	        var additionalParams = __assign({}, ApiHelpers$1.getCustomApiParameters(this.apiParameters, 'providers'));
	        var queryStrings = UrlHelper$1.uriEncodeData(__assign({ client_id: client_id }, additionalParams));
	        var url = Environment$1.baseUrlServices + "/ims/social/v1/providers?" + queryStrings + "&jslVersion=" + Environment$1.jslibver;
	        return ImsXhr.get(url);
	    };
	    /**
	    * @see {@link https://wiki.corp.adobe.com/display/ims/Implicit+Jump+Tokens |Implicit Jump Tokens}
	    * @param request IUnAuthorizedApiRequest contains clientId and token information
	    * @param ijt {string}
	    */
	    ImsApis.prototype.exchangeIjt = function (apiRequest, ijt) {
	        var client_id = apiRequest.client_id;
	        var additionalParams = __assign({}, ApiHelpers$1.getCustomApiParameters(this.apiParameters, 'ijt'));
	        var url = Environment$1.baseUrlServices + "/ims/jump/implicit/" + ijt;
	        var queryStrings = UrlHelper$1.uriEncodeData(__assign({ client_id: client_id }, additionalParams));
	        var apiUrl = url + "?" + queryStrings + "&jslVersion=" + Environment$1.jslibver;
	        if (apiUrl.length > 2048) {
	            delete additionalParams['redirect_uri'];
	            queryStrings = UrlHelper$1.uriEncodeData(additionalParams);
	            apiUrl = url + "?" + queryStrings;
	        }
	        return ImsXhr.get(apiUrl);
	    };
	    /**
	     * Returns the URL to the avatar of a user
	     * @param {UserId} userId
	     * @returns {String}
	     */
	    ImsApis.prototype.avatarUrl = function (userId) {
	        return Environment$1.baseUrlAdobe + "/ims/avatar/download/" + userId;
	    };
	    /**
	     * Makes a request to IMS to get the Floodgate release flags.
	     * Optionally accepts an access token from which to decode the release flags.
	     * @param request IAuthorizedApiRequest contains clientId and token information
	     */
	    ImsApis.prototype.getReleaseFlags = function (request) {
	        var token = request.token, client_id = request.client_id;
	        var additionalParams = __assign({}, ApiHelpers$1.getCustomApiParameters(this.apiParameters, 'fg_value'));
	        var config = this.createAuthorizationHeader(token);
	        var queryStrings = UrlHelper$1.uriEncodeData(__assign({ client_id: client_id }, additionalParams));
	        var url = Environment$1.baseUrlAdobe + "/ims/fg/value/v1?" + queryStrings + "&jslVersion=" + Environment$1.jslibver;
	        return ImsXhr.get(url, config);
	    };
	    /**
	     * Exchange the user's access_token for a Transitory Access Code (TAC) for target client and scope
	     * @param tacRequest {ITransitoryAuthorizationRequest} - contains the request parameters
	     * @param externalParameters {object} - contains the possible parameters used to override the api parameters
	     * @param clientId {string} - the adobeid.client_id value
	     */
	    ImsApis.prototype.getTransitoryAuthorizationCode = function (tacRequest, externalParameters, clientId) {
	        if (externalParameters === void 0) { externalParameters = {}; }
	        var additionalParams = __assign({}, ApiHelpers$1.mergeExternalParameters(externalParameters, this.apiParameters, 'check_token'));
	        var url = Environment$1.baseUrlServices + "/ims/check/v6/token?client_id=" + clientId + "&jslVersion=" + Environment$1.jslibver;
	        var data = UrlHelper$1.uriEncodeData(__assign(__assign({}, additionalParams), tacRequest));
	        return ImsXhr.post(url, data, this.formEncoded());
	    };
	    /**
	     * returns an access token from a authorization or device code
	     * @param authorizationRequest {AuthorizationCode} contains the authorization request parameters
	     * @param externalParameters {object} - contains the possible parameters used to override the api parameters
	     */
	    ImsApis.prototype.getTokenFromCode = function (authorizationRequest, externalParameters) {
	        if (externalParameters === void 0) { externalParameters = {}; }
	        var additionalParams = __assign({}, ApiHelpers$1.mergeExternalParameters(externalParameters, this.apiParameters, 'token'));
	        additionalParams.grant_type = 'authorization_code';
	        delete authorizationRequest.other;
	        var url = Environment$1.baseUrlServices + "/ims/token/v3?jslVersion=" + Environment$1.jslibver;
	        var data = UrlHelper$1.uriEncodeData(__assign(__assign({}, additionalParams), authorizationRequest));
	        return ImsXhr.post(url, data, this.formEncoded());
	    };
	    /**
	     * Allows a client to launch a system-browser and arrive at another IMS-integrated application
	     * @see {@link https://wiki.corp.adobe.com/pages/viewpage.action?spaceKey=ims&title=IMS+API+-+jumptoken }
	     * @param jumpTokenRequest {JumpTokenRequest}
	     * @param externalParameters {IDictionary}
	     * @returns JumpTokenResponse
	     */
	    ImsApis.prototype.jumpToken = function (jumpTokenRequest, externalParameters, clientId) {
	        if (externalParameters === void 0) { externalParameters = {}; }
	        var additionalParams = __assign({}, ApiHelpers$1.mergeExternalParameters(externalParameters, this.apiParameters, 'jumptoken'));
	        var url = Environment$1.baseUrlServices + "/ims/jumptoken/v1?client_id=" + clientId + "&jslVersion=" + Environment$1.jslibver;
	        var data = UrlHelper$1.uriEncodeData(__assign(__assign({}, additionalParams), jumpTokenRequest));
	        return ImsXhr.post(url, data, this.formEncoded());
	    };
	    /**
	     * create the authorization header in case the accesToken exists
	     * @param accessToken {string};
	     * @returns {string}
	     */
	    ImsApis.prototype.createAuthorizationHeader = function (accessToken) {
	        var headers = {};
	        if (accessToken) {
	            headers[HEADERS.AUTHORIZATION] = "Bearer " + accessToken;
	        }
	        return headers;
	    };
	    /**
	     *
	     * @param headers the header which will be sent to ims server on API request
	     */
	    ImsApis.prototype.formEncoded = function (headers) {
	        if (headers === void 0) { headers = {}; }
	        headers["content-type"] = this.CONTENT_FORM_ENCODED;
	        return headers;
	    };
	    return ImsApis;
	}());

	/**
	 * Enumeration values used for ims error types
	 */
	/**
	 * Enumeration values used for ims error types
	 */
	var IErrorType;
	(function (IErrorType) {
	    /**
	     * error triggered in case of exception on adobe ims initialize
	     */
	    IErrorType["INITIALIZE_ERROR"] = "initialize_error";
	    /**
	     * http exception type
	     */
	    IErrorType["HTTP"] = "http";
	    /**
	     * fragment exception type
	     */
	    IErrorType["FRAGMENT"] = "fragment";
	    /**
	     * csrf exception type
	     */
	    IErrorType["CSRF"] = "csrf";
	    /**
	     * error triggered when get token method is called using a different api than authorize
	     */
	    IErrorType["NOT_AUTHORIZE"] = "not_authorize";
	    /**
	     * exception triggered when the profile api throws exception
	     */
	    IErrorType["PROFILE_EXCEPTION"] = "profile_exception";
	    /**
	     * token expired error
	     */
	    IErrorType["TOKEN_EXPIRED"] = "token_expired";
	    /**
	      * social providers error type
	      */
	    IErrorType["SOCIAL_PROVIDERS"] = "SOCIAL_PROVIDERS";
	    /**
	    * ride exception sent to the client in case ther is no jump
	    */
	    IErrorType["RIDE_EXCEPTION"] = "ride_exception";
	})(IErrorType || (IErrorType = {}));

	/**
	 * class used to trigger profile errors
	 */
	var ProfileException = /** @class */ (function () {
	    function ProfileException(message) {
	        this.message = null;
	        this.errorType = IErrorType.PROFILE_EXCEPTION;
	        this.message = message;
	    }
	    return ProfileException;
	}());

	/**
	 * class used to implement the profile methods
	 */
	var ProfileService = /** @class */ (function () {
	    function ProfileService(profileServiceRequest) {
	        this.profileServiceRequest = profileServiceRequest;
	        this.storage = StorageFactory$1.getStorageByName(STORAGE_MODE.SessionStorage);
	    }
	    /**
	     *
	     * @param token {string} - the string used to obtain the profile information
	     */
	    ProfileService.prototype.getProfile = function (token) {
	        var _this = this;
	        var _a = this.profileServiceRequest, clientId = _a.clientId, imsApis = _a.imsApis;
	        var sessionProfile = this.getProfileFromStorage();
	        if (sessionProfile) {
	            return Promise.resolve(sessionProfile);
	        }
	        return imsApis.getProfile({
	            client_id: clientId,
	            token: token
	        }).then(function (profile) {
	            // const { data: profile } = response;
	            if (!profile) {
	                throw new ProfileException('NO profile response');
	            }
	            if (Object.keys(profile).length === 0) {
	                throw new ProfileException('NO profile value');
	            }
	            _this.saveProfileToStorage(profile);
	            return Promise.resolve(profile);
	        })
	            .catch(function (ex) {
	            if (ex instanceof HttpErrorResponse) {
	                return Promise.reject(ex);
	            }
	            _this.removeProfile();
	            return Promise.reject(ex);
	        });
	    };
	    /**
	    * private method used to compose the key used for storage
	    * @param clientId
	    * @param scope
	    * @param isReAuth default false
	    */
	    ProfileService.prototype.getProfileStorageKey = function () {
	        var _a = this.profileServiceRequest, clientId = _a.clientId, scope = _a.scope;
	        var isReAuth = false;
	        return PROFILE_STORAGE_KEY + "/" + clientId + "/" + isReAuth + "/" + scope;
	    };
	    /**
	     * read the profile from session storage
	     */
	    ProfileService.prototype.getProfileFromStorage = function () {
	        var profileStorageKey = this.getProfileStorageKey();
	        var sessionProfile = this.storage.getItem(profileStorageKey);
	        return sessionProfile ? JSON.parse(sessionProfile) : null;
	    };
	    /**
	     *
	     * @param profile {Object} object containing the profile information
	     * save the profile to session storage
	     */
	    ProfileService.prototype.saveProfileToStorage = function (profile) {
	        var profileStorageKey = this.getProfileStorageKey();
	        this.storage.setItem(profileStorageKey, JSON.stringify(profile));
	    };
	    /**
	     * remove the profile value from the SessionStorage
	     */
	    ProfileService.prototype.removeProfile = function () {
	        var profileStorageKey = this.getProfileStorageKey();
	        this.storage.removeItem(profileStorageKey);
	    };
	    /**
	     *
	     * @param userId {string} represents the user id of the new logged user
	     * @returns { boolean } - true if the profile was removed, otherwise false
	     */
	    ProfileService.prototype.removeProfileIfOtherUser = function (userId) {
	        if (!userId) {
	            return;
	        }
	        var profile = this.getProfileFromStorage();
	        if (!profile || profile.userId === userId) {
	            return;
	        }
	        this.removeProfile();
	    };
	    return ProfileService;
	}());

	/**
	 * class used to store the token fields obtained during validation and validate the token against values from adobeIdData
	 */
	var TokenFields = /** @class */ (function () {
	    /**
	     *
	     * @param tokenProps {object} represents the server answer for a validation token request
	     * @param expire {Date} represents the token expiration date
	     *
	     * this class is used to create a TokenFields instance based on storage object;
	     * if token was saved by ImsLib v1, the token field is stored in access_token property and expiration in 'expiresAtMilliseconds',
	     * otherwise, (for imsLIb v2) 'tokenValue' and 'expire' properties are used
	     */
	    function TokenFields(tokenProps, expire) {
	        var _this = this;
	        this.REAUTH_SCOPE = 'reauthenticated';
	        this.valid = false;
	        this.isReauth = function () { return _this.scope.indexOf(_this.REAUTH_SCOPE) >= 0; };
	        /**
	         * represents the client id associated with this token fields
	         */
	        this.client_id = '';
	        /**
	         * represents the scope used to retrieve the token
	         */
	        this.scope = '';
	        /**
	         * represents the token expiration date
	         */
	        this.expire = new Date();
	        /**
	         * represents the user_id associated with the token
	         */
	        this.user_id = '';
	        this.tokenValue = '';
	        /**
	         * represents the session identifier
	         */
	        this.sid = '';
	        this.state = null;
	        /**
	         * true if the token fields is created based on the fragment values and not from storage
	         */
	        this.fromFragment = false;
	        var valid = tokenProps.valid, tokenValue = tokenProps.tokenValue, access_token = tokenProps.access_token, state = tokenProps.state, other = tokenProps.other;
	        var token = tokenValue || access_token;
	        var parsedToken = this.parseJwt(token);
	        if (!parsedToken) {
	            throw new Error("token cannot be decoded " + token);
	        }
	        this.state = ApiHelpers$1.toJson(state);
	        var client_id = parsedToken.client_id, user_id = parsedToken.user_id, tokenScope = parsedToken.scope, sid = parsedToken.sid;
	        this.client_id = client_id;
	        this.expire = expire;
	        this.user_id = user_id;
	        this.scope = tokenScope;
	        this.valid = valid;
	        this.tokenValue = token;
	        this.sid = sid;
	        this.other = other;
	    }
	    /**
	     * parse the token value
	     */
	    TokenFields.prototype.parseJwt = function (token) {
	        if (!token) {
	            return null;
	        }
	        try {
	            return JSON.parse(atob(token.split('.')[1]));
	        }
	        catch (ex) {
	            Log$1.error('error on decoding token ', token, ex);
	            return null;
	        }
	    };
	    /**
	     *
	     * @param adobeClientId client id provided on adobe id
	     * @param adobeIdScope scope value provided in adobe id
	     * @returns {boolean} true if token is valid otherwise false
	     */
	    TokenFields.prototype.validate = function (adobeClientId, adobeIdScope) {
	        var _this = this;
	        var _a = this, valid = _a.valid, client_id = _a.client_id, scope = _a.scope, expire = _a.expire;
	        // check if is expired
	        if (expire < new Date()) {
	            Log$1.error('token invalid  --> expires_at', expire);
	            return false;
	        }
	        if (valid != undefined && !valid) {
	            Log$1.error('token invalid  --> valid');
	            return false;
	        }
	        if (client_id !== adobeClientId) {
	            Log$1.error('token invalid  --> client id', client_id, adobeClientId);
	            return false;
	        }
	        if (!this.isReauth()) {
	            if (scope !== adobeIdScope) {
	                Log$1.error('token invalid  --> scope', ' token scope =', scope, 'vs adobeIdScope =', adobeIdScope, '.');
	                return false;
	            }
	        }
	        else {
	            var scopeToValidate = scope.split(',').filter(function (el) { return el !== _this.REAUTH_SCOPE; }).join(',');
	            if (scopeToValidate !== adobeIdScope) {
	                Log$1.error('reauth token invalid  --> scope', ' token scope =', scopeToValidate, 'vs adobeIdScope =', adobeIdScope, '.');
	                return false;
	            }
	        }
	        return true;
	    };
	    return TokenFields;
	}());

	/**
	 * class used to implement the main functions used for fragment
	 */
	var FragmentHelper = /** @class */ (function () {
	    function FragmentHelper() {
	    }
	    FragmentHelper.prototype.fragmentToObject = function () {
	        var currentHash = this.getHashFromURL();
	        if (!currentHash) {
	            return null;
	        }
	        var url = this.processHashUrl(currentHash);
	        var oldHash = this.getOldHash(url);
	        // fragment values should contain only values starting with old_hash
	        //this is in case when hash route is used: e.g.: https://localhost.corp.adobe.com:9000/#/cdn#old_hash=...
	        //#/cdn# should be ignored when getQueryParamsAsMap is called;
	        var urlWithoutRoute = oldHash ? url.slice(url.indexOf('old_hash')) : url;
	        var urlWithoutOldHash = this.removeOldHash(urlWithoutRoute);
	        var imsResponseAsMap = this.getQueryParamsAsMap(urlWithoutOldHash);
	        if (oldHash) {
	            imsResponseAsMap['old_hash'] = oldHash;
	        }
	        var stateAsString = imsResponseAsMap['state'];
	        if (stateAsString) {
	            imsResponseAsMap['state'] = ApiHelpers$1.toJson(stateAsString);
	        }
	        return imsResponseAsMap;
	    };
	    /**
	     * function used to determine the old_hash value contained into the source
	     * @param source {String} represents the input source used to determine the old_hash
	     * @returns {String}
	     */
	    FragmentHelper.prototype.getOldHash = function (source) {
	        if (!source) {
	            return '';
	        }
	        var match = source.match('old_hash=(.*?)&from_ims=true');
	        if (!match) {
	            return '';
	        }
	        return match[1];
	    };
	    /**
	     * remove the old hash value from the input string
	     * @param source {String} represents the input source
	     */
	    FragmentHelper.prototype.removeOldHash = function (source) {
	        if (!source) {
	            return source;
	        }
	        return source.replace(/old_hash=(.*?)&from_ims=true/gi, 'from_ims=true');
	    };
	    /**
	   * Gets the hash from an url.
	   * @param {string=} url The URL from which to get the hash.
	   *                      If missing use the current page's URL.
	   * @Note: the # is not returned from url
	   * @returns {string}
	   */
	    FragmentHelper.prototype.getHashFromURL = function (url) {
	        if (url === void 0) { url = window.location.href; }
	        var index = url.indexOf("#");
	        return index !== -1 ? url.substring(index + 1) : "";
	    };
	    /**
	   * Parses a query string to a JSON.
	   * @NOTE Sometimes, the query string is actually a hash, due to inconsistent servers
	   * @param source {String}; represents the inpt strring value wich will be transformed to object
	   * @returns {!Object}
	   */
	    FragmentHelper.prototype.getQueryParamsAsMap = function (source) {
	        if (!source) {
	            return {};
	        }
	        var paramMap = {};
	        //in case the source starts with #, ? or &, the first character is removed. 
	        source = source.replace(/^(#\/|\/|#|\?|&)/, "");
	        source.split("&").forEach(function (keyValuePair) {
	            if (keyValuePair.length) {
	                var arr = keyValuePair.split("=");
	                paramMap[arr[0]] = decodeURIComponent(arr[1]);
	            }
	        });
	        return paramMap;
	    };
	    /**
	   * @param source {string} represent the input source wich will be processed
	   * The backend appends a second "#" sign to redirect_uri, even if it already contains one.
	   * @see https://jira.corp.adobe.com/browse/IMSB-4107554
	   */
	    FragmentHelper.prototype.processHashUrl = function (source) {
	        return decodeURIComponent(source)
	            .replace("?error", "#error")
	            .replace(/#/gi, '&')
	            .replace('from_ims=true?', 'from_ims=true&');
	    };
	    return FragmentHelper;
	}());
	var FragmentHelper$1 = new FragmentHelper();

	var FragmentException = /** @class */ (function () {
	    function FragmentException(type, message) {
	        this.message = '';
	        this.type = '';
	        this.type = type;
	        this.message = message;
	    }
	    return FragmentException;
	}());

	/**
	 * Enumeration values used for defining possible fragment exception types
	 *
	 */
	var IFragmentExceptionType;
	(function (IFragmentExceptionType) {
	    /**
	     * fragment exception type
	     */
	    IFragmentExceptionType["FRAGMENT"] = "fragment";
	    /**
	     * csrf exception type
	     */
	    IFragmentExceptionType["CSRF"] = "csrf";
	    IFragmentExceptionType["NOT_AUTHORIZE"] = "not_authorize";
	})(IFragmentExceptionType || (IFragmentExceptionType = {}));

	var TokenProfileResponse = /** @class */ (function () {
	    function TokenProfileResponse(tokenFields, profile) {
	        this.profile = null;
	        this.tokenFields = tokenFields;
	        this.profile = profile;
	    }
	    return TokenProfileResponse;
	}());

	/**
	 * class used to encapsulate the token expired message
	 */
	var TokenExpiredException = /** @class */ (function () {
	    function TokenExpiredException(exception) {
	        this.exception = null;
	        this.exception = exception;
	    }
	    return TokenExpiredException;
	}());

	/**
	 * class used to store the authorization code fields
	 */
	var AuthorizationCode = /** @class */ (function () {
	    /**
	     * this class is used to create a AuthorizationCode instance based on authorization server response
	     * @param authProps {object} represents the authorization server response
	     */
	    function AuthorizationCode(authProps) {
	        /**
	         * represents the client id associated with this token fields
	         */
	        this.client_id = '';
	        /**
	         * represents the scope used to retrieve the token
	         */
	        this.scope = '';
	        /**
	         * represents the code recived during the authorization
	         */
	        this.code = '';
	        /**
	         * represents the state used during initialize
	         */
	        this.state = null;
	        /**
	         * represents the code_verifier used to generate the code_challenge (used during authorization flow)
	         */
	        this.code_verifier = '';
	        /**
	         * represents the other properties from url
	         */
	        this.other = null;
	        var code = authProps.code, state = authProps.state, client_id = authProps.client_id, scope = authProps.scope, verifier = authProps.verifier, other = __rest(authProps, ["code", "state", "client_id", "scope", "verifier"]);
	        this.state = state;
	        this.client_id = client_id;
	        this.code = code;
	        this.scope = scope;
	        this.code_verifier = verifier;
	        this.other = other;
	    }
	    return AuthorizationCode;
	}());

	/**
	 * class used only by the popup window in order to know that the parent should be notified
	 * it is triggered by getTokenFields if the redirect state contains imslibmodal propery
	 * during imslib initialization, if this type of event is received than the parent window will be notified
	 */
	var ModalSignInEvent = /** @class */ (function () {
	    /**
	     * this type of event is triggered by get token from fragment method (in case imslibmodal from fragment is true)
	     * @param wndRedirectPropName {String} represents the property used by popup window to set the redirect url
	     */
	    function ModalSignInEvent(wndRedirectPropName) {
	        /**
	         * represents the property used by popup window, to set the redirect url
	         * this property will be used only if the popup.opener is not defined (edge bug)
	         */
	        this.wndRedirectPropName = '';
	        this.wndRedirectPropName = wndRedirectPropName;
	    }
	    return ModalSignInEvent;
	}());

	/* eslint-disable @typescript-eslint/camelcase */
	var API_AUTHORIZE = 'authorize';
	/**
	 * class used to store the specific token methods
	 */
	var TokenService = /** @class */ (function () {
	    function TokenService(tokenServiceRequest, csrfService) {
	        var _this = this;
	        /**
	         * tries to get a valid token; if there is no token, the refresh method is called
	         * @param externalParameters represents the external parameters used for refresh token
	         * @returns TokenProfileResponse
	         */
	        this.getTokenAndProfile = function (externalParameters) {
	            if (externalParameters === void 0) { externalParameters = {}; }
	            var tokenResponse = _this.getTokenFields();
	            if (tokenResponse instanceof ModalSignInEvent) {
	                return Promise.reject(tokenResponse);
	            }
	            if (tokenResponse instanceof FragmentException) {
	                return Promise.reject(tokenResponse);
	            }
	            if (tokenResponse instanceof AuthorizationCode) {
	                var imsApis = _this.tokenServiceRequest.imsApis;
	                return imsApis.getTokenFromCode(tokenResponse, externalParameters).then(function (tokenApiResponse) {
	                    var access_token = tokenApiResponse.access_token, state = tokenApiResponse.state, expires_in = tokenApiResponse.expires_in, _a = tokenApiResponse.scope, scope = _a === void 0 ? '' : _a, profile = __rest(tokenApiResponse, ["access_token", "state", "expires_in", "scope"]);
	                    var tokenFields = new TokenFields({
	                        scope: scope,
	                        tokenValue: access_token,
	                        valid: true,
	                        state: state,
	                        other: tokenResponse.other,
	                    }, new Date(new Date().getTime() + parseFloat(expires_in)));
	                    return Promise.resolve(new TokenProfileResponse(tokenFields, profile));
	                });
	            }
	            if (tokenResponse instanceof TokenFields) {
	                if (tokenResponse.fromFragment || !_this.tokenServiceRequest.autoValidateToken) {
	                    return Promise.resolve(new TokenProfileResponse(tokenResponse, null));
	                }
	                return _this.callValidateTokenApi(tokenResponse.tokenValue).then(function () { return new TokenProfileResponse(tokenResponse, null); })
	                    .catch(function () { return _this.callRefreshToken(externalParameters); });
	            }
	            else {
	                return _this.callRefreshToken(externalParameters);
	            }
	        };
	        var useLocalStorage = tokenServiceRequest.useLocalStorage;
	        this.csrfService = csrfService;
	        this.tokenServiceRequest = tokenServiceRequest;
	        this.storage = StorageFactory$1.getStorageByName(useLocalStorage ? STORAGE_MODE.LocalStorage : STORAGE_MODE.SessionStorage);
	    }
	    /**
	     *
	     * @returns {TokenFields} representing the token fields from fragment or local storage
	     */
	    TokenService.prototype.getTokenFields = function () {
	        var _a = this.tokenServiceRequest, clientId = _a.clientId, scope = _a.scope;
	        var fragmentResult = this.getTokenFromFragment();
	        if (fragmentResult instanceof ModalSignInEvent) {
	            return fragmentResult;
	        }
	        if (fragmentResult instanceof FragmentException) {
	            return fragmentResult;
	        }
	        if (fragmentResult instanceof AuthorizationCode) {
	            return fragmentResult;
	        }
	        if (fragmentResult && fragmentResult.validate(clientId, scope)) {
	            fragmentResult.fromFragment = true;
	            this.addTokenToStorage(fragmentResult);
	            return fragmentResult;
	        }
	        return this.getTokenFieldsFromStorage();
	    };
	    /**
	     * method used to validate the local storage token value
	     */
	    TokenService.prototype.validateToken = function () {
	        var tokenFields = this.getTokenFieldsFromStorage();
	        if (!tokenFields) {
	            return Promise.reject(null);
	        }
	        return this.callValidateTokenApi(tokenFields.tokenValue);
	    };
	    /**
	     * method used to retrieve the token release flags
	     */
	    TokenService.prototype.getReleaseFlags = function () {
	        var _a = this.tokenServiceRequest, clientId = _a.clientId, imsApis = _a.imsApis;
	        var tokenFields = this.getTokenFieldsFromStorage();
	        if (!tokenFields) {
	            return Promise.reject(null);
	        }
	        return imsApis.getReleaseFlags({
	            token: tokenFields.tokenValue,
	            client_id: clientId,
	        });
	    };
	    /**
	     * method used to call the validate token api
	     * @param token {String} validate the input token value
	     */
	    TokenService.prototype.callValidateTokenApi = function (token) {
	        var _this = this;
	        var _a = this.tokenServiceRequest, clientId = _a.clientId, scope = _a.scope, imsApis = _a.imsApis;
	        return imsApis.validateToken({ client_id: clientId, token: token })
	            .then(function (tokenResponseData) {
	            Log$1.info('validateToken response', tokenResponseData);
	            var tokenFields = new TokenFields(__assign(__assign({}, tokenResponseData), { tokenValue: token }), new Date(parseFloat(tokenResponseData.expires_at)));
	            if (tokenFields.validate(clientId, scope)) {
	                _this.addTokenToStorage(tokenFields);
	                return Promise.resolve(tokenFields);
	            }
	            throw new Error('could not validate tokenFields');
	        })
	            .catch(function (ex) {
	            Log$1.error('validateToken response', ex);
	            if (ex instanceof HttpErrorResponse) {
	                return Promise.reject(ex);
	            }
	            _this.removeTokenFromLocalStorage();
	            return Promise.reject(ex);
	        });
	    };
	    /**
	     * @returns the object values from the url fragment
	     */
	    TokenService.prototype.getTokenFromFragment = function () {
	        var fragmentValues = FragmentHelper$1.fragmentToObject();
	        if (!fragmentValues) {
	            return null;
	        }
	        Log$1.info("fragment value " + fragmentValues);
	        var token = fragmentValues.access_token, scope = fragmentValues.scope, error = fragmentValues.error, api = fragmentValues.api, _a = fragmentValues.state, state = _a === void 0 ? {} : _a, expires_in = fragmentValues.expires_in, client_id = fragmentValues.client_id, _b = fragmentValues.code, code = _b === void 0 ? '' : _b, other = __rest(fragmentValues, ["access_token", "scope", "error", "api", "state", "expires_in", "client_id", "code"]);
	        var imslibmodal = state.imslibmodal, nonce = state.nonce;
	        if (imslibmodal === true) {
	            return new ModalSignInEvent(nonce);
	        }
	        if (!fragmentValues.from_ims) {
	            return null;
	        }
	        if (client_id !== this.tokenServiceRequest.clientId) {
	            return null;
	        }
	        if (error) {
	            return new FragmentException(IFragmentExceptionType.FRAGMENT, error);
	        }
	        if (api !== API_AUTHORIZE) {
	            return new FragmentException(IFragmentExceptionType.NOT_AUTHORIZE, "api should be authorize and " + api + " is used");
	        }
	        var validCsrf = this.csrfService.verify(nonce);
	        if (!validCsrf) {
	            return new FragmentException(IFragmentExceptionType.CSRF, 'CSRF exception');
	        }
	        if (code) {
	            var codeChallenge = new CodeChallenge();
	            var verifier = codeChallenge.getVerifierByKey(nonce);
	            if (!verifier) {
	                throw new Error('no verifier value has been found');
	            }
	            return new AuthorizationCode(__assign(__assign({}, fragmentValues), { verifier: verifier }));
	        }
	        if (!token) {
	            return null;
	        }
	        var tokenFields = new TokenFields({
	            scope: scope,
	            tokenValue: token,
	            valid: true,
	            state: state,
	            other: other
	        }, new Date(new Date().getTime() + parseFloat(expires_in)));
	        return tokenFields;
	    };
	    /**
	     *
	     * @param key {string} represents the key used to read the value from storage
	     */
	    TokenService.prototype.getStorageKeyValue = function (key) {
	        return this.storage.getItem(key);
	    };
	    /**
	     * @returns the TokenFields structure from local storage or null
	     * @isReauth boolean value; true if token is for reauthentification
	     */
	    TokenService.prototype.getTokenFieldsFromStorage = function (isReauth) {
	        if (isReauth === void 0) { isReauth = false; }
	        var _a = this.tokenServiceRequest, clientId = _a.clientId, scope = _a.scope;
	        var tokenStorageKey = this.getAccessTokenKey(isReauth);
	        var tokenData = this.getStorageKeyValue(tokenStorageKey);
	        if (!tokenData) {
	            return null;
	        }
	        var parsedToken = JSON.parse(tokenData);
	        var expire = parsedToken.expire ? new Date(Date.parse(parsedToken.expire)) : new Date(parsedToken.expiresAtMilliseconds);
	        var tokenFields = new TokenFields(parsedToken, expire);
	        return tokenFields.validate(clientId, scope) ? tokenFields : null;
	    };
	    /**
	     * private method used to compose the key used for storage
	     * @param clientId
	     * @param scope
	     * @param isReAuth default false; true means that the key is for re-authentification
	     */
	    TokenService.prototype.getAccessTokenKey = function (isReauth) {
	        if (isReauth === void 0) { isReauth = false; }
	        var _a = this.tokenServiceRequest, clientId = _a.clientId, scope = _a.scope;
	        return TOKEN_STORAGE_KEY + "/" + clientId + "/" + isReauth + "/" + scope;
	    };
	    /**
	     * save the token into local storage
	     * @param tokenFragment - object with the values from fragment
	     */
	    TokenService.prototype.addTokenToStorage = function (tokenFields) {
	        if (!tokenFields) {
	            return;
	        }
	        var isReauth = tokenFields.isReauth();
	        var tokenStorageKey = this.getAccessTokenKey(isReauth);
	        var clonedTokenFields = __assign({}, tokenFields);
	        clonedTokenFields.state = {};
	        clonedTokenFields.other = '{}';
	        this.storage.setItem(tokenStorageKey, JSON.stringify(clonedTokenFields));
	    };
	    /**
	     * remove the token from local storage
	     */
	    TokenService.prototype.removeTokenFromLocalStorage = function () {
	        var tokenStorageKey = this.getAccessTokenKey();
	        this.storage.removeItem(tokenStorageKey);
	    };
	    /**
	     * remove the reauth token from local storage
	     */
	    TokenService.prototype.removeReauthTokenFromLocalStorage = function () {
	        var tokenStorageKey = this.getAccessTokenKey(true);
	        this.storage.removeItem(tokenStorageKey);
	    };
	    /**
	     *
	     * @param externalParameters external parameters received outside of the library
	     * @returns IRefreshTokenResponse containing the refresh token information
	     */
	    TokenService.prototype.refreshToken = function (externalParameters) {
	        var _this = this;
	        if (externalParameters === void 0) { externalParameters = {}; }
	        var _a = this.tokenServiceRequest, clientId = _a.clientId, imsApis = _a.imsApis, scope = _a.scope;
	        var tokenFields = this.getTokenFieldsFromStorage();
	        var userId = tokenFields ? tokenFields.user_id : '';
	        return imsApis.checkToken({
	            client_id: clientId,
	            scope: scope,
	        }, externalParameters, userId)
	            .then(function (data) {
	            if (!data) {
	                throw new Error('refresh token --> no response');
	            }
	            var access_token = data.access_token, expires_in = data.expires_in, token_type = data.token_type, error = data.error, _a = data.error_description, error_description = _a === void 0 ? '' : _a, sid = data.sid, profileValues = __rest(data, ["access_token", "expires_in", "token_type", "error", "error_description", "sid"]);
	            if (error) {
	                throw new Error(error + " " + error_description);
	            }
	            var profile = Object.keys(profileValues).length ? profileValues : null;
	            var refreshTokenResponse = {
	                tokenInfo: {
	                    token: access_token,
	                    expire: new Date(Date.now() + parseFloat(expires_in)),
	                    token_type: token_type,
	                    sid: sid,
	                },
	                profile: profile
	            };
	            _this.updateToken(refreshTokenResponse.tokenInfo);
	            return Promise.resolve(refreshTokenResponse);
	        })
	            .catch(function (refreshTokenException) {
	            if (refreshTokenException === void 0) { refreshTokenException = {}; }
	            if (refreshTokenException instanceof HttpErrorResponse) {
	                return Promise.reject(refreshTokenException);
	            }
	            if (refreshTokenException instanceof RideException) {
	                return Promise.reject(refreshTokenException);
	            }
	            _this.removeTokenFromLocalStorage();
	            return Promise.reject(new TokenExpiredException(refreshTokenException));
	        });
	    };
	    /**
	     * function used to change the user profile
	     * @param externalParameters external parameters received outside of the library
	     * @param userId {String} represents the user id used to get the new token and profile
	     * @returns IRefreshTokenResponse containing the refresh token information
	     */
	    TokenService.prototype.switchProfile = function (userId, externalParameters) {
	        var _this = this;
	        if (externalParameters === void 0) { externalParameters = {}; }
	        var _a = this.tokenServiceRequest, clientId = _a.clientId, imsApis = _a.imsApis, scope = _a.scope;
	        return imsApis.switchProfile({
	            client_id: clientId,
	            scope: scope,
	        }, externalParameters, userId).then(function (data) {
	            if (!data) {
	                throw new Error('refresh token --> no response');
	            }
	            var access_token = data.access_token, expires_in = data.expires_in, token_type = data.token_type, error = data.error, _a = data.error_description, error_description = _a === void 0 ? '' : _a, sid = data.sid, profileValues = __rest(data, ["access_token", "expires_in", "token_type", "error", "error_description", "sid"]);
	            if (error) {
	                throw new Error(error + " " + error_description);
	            }
	            var profile = Object.keys(profileValues).length ? profileValues : null;
	            var refreshTokenResponse = {
	                tokenInfo: {
	                    token: access_token,
	                    expire: new Date(Date.now() + parseFloat(expires_in)),
	                    token_type: token_type,
	                    sid: sid,
	                },
	                profile: profile
	            };
	            _this.updateToken(refreshTokenResponse.tokenInfo);
	            return Promise.resolve(refreshTokenResponse);
	        })
	            .catch(function (switchTokenException) {
	            if (switchTokenException === void 0) { switchTokenException = {}; }
	            return Promise.reject(switchTokenException);
	        });
	    };
	    /**
	     *
	     * @param externalParameters external parameters received outside of the library
	     * @returns IRefreshTokenResponse containing the refresh token information
	     */
	    TokenService.prototype.callRefreshToken = function (externalParameters) {
	        if (externalParameters === void 0) { externalParameters = {}; }
	        return this.refreshToken(externalParameters)
	            .then(function (tokenResponse) {
	            var _a = tokenResponse.tokenInfo, token = _a.token, expire = _a.expire, profile = tokenResponse.profile;
	            var refreshTokenFields = new TokenFields({
	                valid: true,
	                tokenValue: token,
	            }, expire);
	            var tokenProfileResponse = new TokenProfileResponse(refreshTokenFields, profile);
	            return Promise.resolve(tokenProfileResponse);
	        })
	            .catch(function (ex) {
	            return Promise.reject(ex);
	        });
	    };
	    /**
	     * update the token into local storage after a refresh action
	     * @param tokenInfo {ITokenInformation}
	     *
	     */
	    TokenService.prototype.updateToken = function (tokenInfo) {
	        var token = tokenInfo.token, expire = tokenInfo.expire;
	        var tokenFields = new TokenFields({
	            tokenValue: token,
	        }, expire);
	        if (!tokenFields) {
	            return;
	        }
	        tokenFields.tokenValue = token;
	        this.addTokenToStorage(tokenFields);
	    };
	    /**
	     * remove the tokens from the local storage
	     */
	    TokenService.prototype.purge = function () {
	        this.removeTokenFromLocalStorage();
	        this.removeReauthTokenFromLocalStorage();
	    };
	    /**
	     * set a new access token
	     * @param tokenInfo {StandaloneToken} represents the token and expiration ms
	     */
	    TokenService.prototype.setStandAloneToken = function (standaloneToken) {
	        var token = standaloneToken.token, sid = standaloneToken.sid, _a = standaloneToken.expirems, expirems = _a === void 0 ? -1 : _a;
	        var _b = this.tokenServiceRequest, clientId = _b.clientId, scope = _b.scope;
	        var expire = new Date(new Date().getTime() + expirems);
	        var tokenFields = new TokenFields({
	            valid: true,
	            tokenValue: token,
	        }, expire);
	        if (!tokenFields.validate(clientId, scope)) {
	            return false;
	        }
	        var tokenInfoToBeSaved = {
	            expire: expire,
	            token: token,
	            sid: sid,
	        };
	        this.updateToken(tokenInfoToBeSaved);
	        return true;
	    };
	    /**
	     * method used during initialization in order to get a ijt token
	     * @returns {Promise<TokenProfileResponse>} ijt response
	     */
	    TokenService.prototype.exchangeIjt = function (ijt) {
	        var _a = this.tokenServiceRequest, clientId = _a.clientId, scope = _a.scope, imsApis = _a.imsApis;
	        var apiRequest = {
	            client_id: clientId,
	            scope: scope,
	        };
	        return imsApis.exchangeIjt(apiRequest, ijt).then(function (ijtResponse) {
	            var valid = ijtResponse.valid, access_token = ijtResponse.access_token, expires_in = ijtResponse.expires_in;
	            if (valid === false) {
	                return Promise.reject(ijtResponse);
	            }
	            var expire = new Date(Date.now() + parseFloat(expires_in));
	            var ijtTokenFields = new TokenFields({
	                valid: true,
	                tokenValue: access_token,
	            }, expire);
	            var tokenProfileResponse = new TokenProfileResponse(ijtTokenFields, null);
	            return Promise.resolve(tokenProfileResponse);
	        });
	    };
	    return TokenService;
	}());

	/**
	 * class used for automatically refresh the token.
	 * the refreshtoken method is auomatically triggered in case the user interacted with the page within the last 15 minutes before token expiration
	 */
	/**
	 * auto refresh minutes interval
	 */
	var CONSIDER_INTERACTION_MINUTES_INTERVAL = 15;
	var ONE_MIN_MS = 60000;
	var USER_INTERACTION_EVENTS = ['keyup', 'mousemove'];
	var TokenAutoRefresh = /** @class */ (function () {
	    function TokenAutoRefresh() {
	        var _this = this;
	        /**
	         * store the list of token auto refresh parameters (multiple client support)
	         */
	        this.autoRefreshParameters = null;
	        /**
	         * method called every time the user interacted with the dom
	         * if ignoreUserInteractionTimerId, the interaction will be ignored otherwise create the autorefresh timer and remove the custom user interaction handler
	         */
	        this.onUserInteraction = function () {
	            if (!_this.ignoreUserInteractionTimerId) {
	                return;
	            }
	            _this.initializeRefreshTokenLastMinuteInterval();
	        };
	    }
	    /**
	     * starts the autorefresh flow
	     * @param autoRefreshParameters {ITokenAutoRefreshParams} parameters used for auto refresh flow
	     */
	    TokenAutoRefresh.prototype.startAutoRefreshFlow = function (autoRefreshParameters) {
	        var _this = this;
	        if (!autoRefreshParameters) {
	            return;
	        }
	        this.autoRefreshParameters = autoRefreshParameters;
	        var expire = autoRefreshParameters.expire;
	        if (!expire) {
	            return;
	        }
	        this.stopTimer(this.autoRefreshTimerId);
	        this.autoRefreshTimerId = 0;
	        this.initializeIgnoreUserInteractionInterval(expire);
	        USER_INTERACTION_EVENTS.forEach(function (eventName) { return _this.initializeDomEvent(eventName); });
	    };
	    /**
	     * initialize the ignore user interaction interval
	     * @param expire
	     */
	    TokenAutoRefresh.prototype.initializeIgnoreUserInteractionInterval = function (expire) {
	        var _this = this;
	        this.stopTimer(this.ignoreUserInteractionTimerId);
	        this.ignoreUserInteractionTimerId = 0;
	        var ignoreUserInteractionTime = this.getIgnoreUserInteractionInterval(expire);
	        this.ignoreUserInteractionTimerId = setTimeout(function () {
	            _this.stopTimer(_this.ignoreUserInteractionTimerId);
	        }, ignoreUserInteractionTime);
	    };
	    /**
	     * initialize the autorefresh timer which will trigger the refresh token
	     */
	    TokenAutoRefresh.prototype.initializeRefreshTokenLastMinuteInterval = function () {
	        var _this = this;
	        if (this.autoRefreshTimerId) {
	            return;
	        }
	        this.autoRefreshTimerId = setTimeout(function () {
	            var _a;
	            _this.stopTimer(_this.autoRefreshTimerId);
	            _this.autoRefreshTimerId = 0;
	            (_a = _this.autoRefreshParameters) === null || _a === void 0 ? void 0 : _a.refreshTokenMethod();
	        }, this.getMSTimeTillCallRefreshMethod());
	    };
	    TokenAutoRefresh.prototype.getMSTimeTillCallRefreshMethod = function () {
	        if (!this.autoRefreshParameters) {
	            return 0;
	        }
	        return this.autoRefreshParameters.expire.getTime() - new Date().getTime() - ONE_MIN_MS;
	    };
	    /**
	     * initialize the dom event
	     * @param expiration represents the Date when the token will expire
	     */
	    TokenAutoRefresh.prototype.initializeDomEvent = function (eventName) {
	        window.removeEventListener(eventName, this.onUserInteraction);
	        window.addEventListener(eventName, this.onUserInteraction);
	    };
	    /**
	     * add minutes value to date and returns the new date value
	     * @param date represents the inout date
	     * @param minutes contains the minutes which will be added to the date
	     */
	    TokenAutoRefresh.prototype.addMinutes = function (date, minutes) {
	        return new Date(date.getTime() + minutes * ONE_MIN_MS);
	    };
	    /**
	     * returns the miliseconds interval when the user interaction should be ignored
	     * the ignore interval should be less than 15 minutes before token expiration
	     * @param expire represents the token expire date;
	     */
	    TokenAutoRefresh.prototype.getIgnoreUserInteractionInterval = function (expire) {
	        var ignoreInteraction = this.addMinutes(expire, -CONSIDER_INTERACTION_MINUTES_INTERVAL - 1);
	        return ignoreInteraction.getTime() - (new Date).getTime();
	    };
	    /**
	     * clear the timeout timer id
	     * @param timer represents the timer id which it will be cleared
	     */
	    TokenAutoRefresh.prototype.stopTimer = function (timer) {
	        if (!timer) {
	            return;
	        }
	        clearTimeout(timer);
	    };
	    return TokenAutoRefresh;
	}());
	var TokenAutoRefresh$1 = new TokenAutoRefresh();

	/**
	 * Class used as a facade for ims library in order to provide public access to library functionalities
	 *
	 */
	var AdobeIMS = /** @class */ (function () {
	    /**
	     * @constructor adobeData {AdobeIdData}
	     * If adobeData is not null, the adobeIdData instance will be created based on these values
	     *
	     * if no adobeData, the imsLibrary try to read these values from window.adobeid
	     *
	     * After this AdobeIms class is created, it can be accessed by window[{adobeData.clientId}]
	    */
	    function AdobeIMS(adobeData) {
	        var _this = this;
	        if (adobeData === void 0) { adobeData = null; }
	        /**
	         * flag used to block the access to signin, signout functions in case the library is not fully initialized
	         * { Boolean }; true if library is initialized, otherwise false
	         */
	        this.initialized = false;
	        /**
	         *
	         * @param authUrlRedirectResponse {String} represents the authorization redirect response
	         */
	        this.onPopupMessage = function (authUrlRedirectResponse) {
	            UrlHelper$1.replaceUrl(authUrlRedirectResponse);
	            return _this.initialize();
	        };
	        /**
	         * Method used to redirect the user to signin url
	         *
	         * <uml>
	         * start
	         * :SignIn;
	         * :Create the state object by using appCode, appVersion (used on server side) from adobeId.analytics and contextToBePassedOnRedirect;
	         * :Create the redirect url using external parameters. state object will be part of redirect url;
	         * :user must enter the credentials and after that is redirected to initial uri;
	         * :initialize method is used which will trigger the onAccessToken;
	         * end
	         * </uml>
	         *
	         *
	         * @param externalParameters {Object} object sent from outside in order to have the possibility to override the default values when the redirect uri is created
	         * @param contextToBePassedOnRedirect {any | undefined} represents the context which is passed during redirect
	         * @param grantType {IGrantTypes} represents the grant type used for sign in flow
	         *
	        */
	        this.signIn = function (externalParameters, contextToBePassedOnRedirect, grantType) {
	            if (externalParameters === void 0) { externalParameters = {}; }
	            if (grantType === void 0) { grantType = IGrantTypes.token; }
	            _this.checkInitialized();
	            var _a = _this, adobeIdData = _a.adobeIdData, csrfService = _a.csrfService;
	            var nonce = csrfService.initialize();
	            return adobeIdData.createRedirectRequest(externalParameters, contextToBePassedOnRedirect, nonce, grantType)
	                .then(function (authorizeRequestData) {
	                _this.signInservice.signIn(authorizeRequestData);
	            });
	        };
	        /**
	         * method used to sign in using an external token
	         * @param token { String } token used for authorize; if the token is empty, the user will be redirected to the sign in screen
	         * @param externalParameters {Object} object sent from outside in order to have the possibility to override the default values when the redirect uri is created
	         * @param contextToBePassedOnRedirect {any | undefined} represents the context which is passed during redirect
	         */
	        this.authorizeToken = function (token, externalParameters, contextToBePassedOnRedirect, grantType) {
	            if (token === void 0) { token = ''; }
	            if (externalParameters === void 0) { externalParameters = {}; }
	            if (grantType === void 0) { grantType = IGrantTypes.token; }
	            var _a = _this, adobeIdData = _a.adobeIdData, csrfService = _a.csrfService;
	            var nonce = csrfService.initialize();
	            return adobeIdData.createRedirectRequest(externalParameters, contextToBePassedOnRedirect, nonce, grantType)
	                .then(function (authorizeRequestData) {
	                new SignInService().authorizeToken(token, authorizeRequestData);
	            });
	        };
	        /**
	         * Method used to reAuthenticate the user
	         *
	         * <uml>
	         * start
	         * :Create the state object by using appCode, appVersion (used on server side) from adobeId.analytics and contextToBePassedOnRedirect;
	         * :Create the redirect url using external parameters. state object will be part of redirect url;
	         * :SignIn;
	         * :user must enter the credentials and after that is redirected to initial uri;
	         * :initialize method is used which will trigger the token and profile;
	         * end
	         *
	         * </uml>
	         *
	         * @param requestedParameters object sent from outside in order to use diferent values for reAuthenticate
	         * @param contextToBePassedOnRedirect {Object | undefined} represents the context which is passed during redirect
	         * @param reauth {string}; represents the re authenticate value. available values are: check and force. default value is "check"
	         *
	        */
	        this.reAuthenticate = function (requestedParameters, reauth, contextToBePassedOnRedirect, grantType) {
	            if (requestedParameters === void 0) { requestedParameters = {}; }
	            if (reauth === void 0) { reauth = IReauth.check; }
	            if (grantType === void 0) { grantType = IGrantTypes.token; }
	            _this.checkInitialized();
	            var _a = _this, adobeIdData = _a.adobeIdData, csrfService = _a.csrfService;
	            var nonce = csrfService.initialize();
	            return adobeIdData.createReAuthenticateRedirectRequest(requestedParameters, contextToBePassedOnRedirect, nonce, reauth, grantType)
	                .then(function (authorizeRequestData) {
	                _this.signInservice.signIn(authorizeRequestData);
	            });
	        };
	        /**
	         * sign in with social providers
	         * @param providerName provider name used for sign in
	         * @param externalParameters external parameters sent by developer
	         * @param contextToBePassedOnRedirect {Object} state of the application
	         */
	        this.signInWithSocialProvider = function (providerName, externalParameters, contextToBePassedOnRedirect, grantType) {
	            if (externalParameters === void 0) { externalParameters = {}; }
	            if (grantType === void 0) { grantType = IGrantTypes.token; }
	            _this.checkInitialized();
	            if (!providerName) {
	                throw new Error('please provide the provider name');
	            }
	            var _a = _this, adobeIdData = _a.adobeIdData, csrfService = _a.csrfService;
	            var nonce = csrfService.initialize();
	            adobeIdData.createSocialProviderRedirectRequest(providerName, externalParameters, contextToBePassedOnRedirect, nonce, grantType)
	                .then(function (authorizeRequestData) {
	                _this.signInservice.signIn(authorizeRequestData);
	            });
	        };
	        /**
	         *  Method used for sign out the user
	         *
	         * <uml>
	         * start
	         * :Signout;
	         * :Create the redirect url;
	         * :remove the token and profile from storage;
	         * :initialize method is used which will redirect the app to initial url;
	         * end
	         * </uml>
	         *
	         * @param externalParameters {Object} object sent from outside in order to have the possibility to override the default values when the redirect uri is created
	         *
	        */
	        this.signOut = function (externalParameters) {
	            if (externalParameters === void 0) { externalParameters = {}; }
	            _this.checkInitialized();
	            _this.tokenService.purge();
	            _this.profileService.removeProfile();
	            var _a = _this.adobeIdData, _b = _a.api_parameters, apiParameters = _b === void 0 ? {} : _b, clientId = _a.client_id, adobeIdRedirectUri = _a.redirect_uri;
	            var redirectRequest = {
	                adobeIdRedirectUri: adobeIdRedirectUri,
	                apiParameters: apiParameters,
	                clientId: clientId,
	                externalParameters: externalParameters,
	            };
	            var signOutService = new SignOutService();
	            signOutService.signOut(redirectRequest);
	        };
	        /**
	         * Refresh the existing token.
	         *
	         * <uml>
	         * start
	         * :refreshToken;
	         * :call backend: ims/check/v4/token?client_id;
	         * :read the token and profile;
	         * :triggerOnAccessToken;
	         * if (profile) then (yes)
	         * else (nothing)
	         * :call backend to get the profile ;
	         * endif
	         * end
	         * </uml>
	         *
	         * @param externalParameters {Object} external parameters sent from outside of the library
	         * Note: if refresh token API fails, the triggerOnAccessTokenHasExpired will be triggered
	        */
	        this.refreshToken = function (externalParameters) {
	            if (externalParameters === void 0) { externalParameters = {}; }
	            return _this.tokenService.refreshToken(externalParameters)
	                .then(function (tokenResponse) { return _this.onTokenProfileReceived(tokenResponse); })
	                .catch(function (ex) {
	                Log$1.error('refresh token error', ex);
	                if (ex instanceof HttpErrorResponse) {
	                    return Promise.reject(ex);
	                }
	                if (ex instanceof RideException) {
	                    if (ex.jump) {
	                        UrlHelper$1.replaceUrl(ex.jump);
	                        return Promise.reject(ex);
	                    }
	                    return Promise.reject(ex);
	                }
	                _this.profileService.removeProfile();
	                _this.onTokenExpired();
	                return Promise.reject(ex);
	            });
	        };
	        /**
	         * retreive a new token and profile for the input user id
	         * @param externalParameters {Object} external parameters sent from outside of the library
	         * @param userId {String} represents the user id used to get the new token and profile
	         */
	        this.switchProfile = function (userId, externalParameters) {
	            if (externalParameters === void 0) { externalParameters = {}; }
	            if (!userId) {
	                return Promise.reject(new Error('Please provide the user id for switchProfile'));
	            }
	            return _this.tokenService.switchProfile(userId, externalParameters)
	                .then(function (tokenResponse) { return _this.onTokenProfileReceived(tokenResponse); })
	                .catch(function (ex) {
	                if (ex instanceof HttpErrorResponse) {
	                    return Promise.reject(ex);
	                }
	                if (ex instanceof RideException) {
	                    if (ex.jump) {
	                        UrlHelper$1.replaceUrl(ex.jump);
	                        return Promise.reject(ex);
	                    }
	                    return Promise.reject(ex);
	                }
	                return Promise.reject(ex);
	            });
	        };
	        /**
	         *
	         * @param instance { AdobeIMS } instance of AdobeIMS
	         */
	        this.triggerOnImsInstance = function (instance) {
	            var evt = document.createEvent("CustomEvent");
	            var evtData = {
	                clientId: _this.adobeIdData.client_id,
	                instance: instance,
	            };
	            evt.initCustomEvent(ON_IMSLIB_INSTANCE, false, false, evtData);
	            window.dispatchEvent(evt);
	        };
	        /**
	           * process the initialize exception;
	           * this method is the first method called in case there was an error during initialize flow;
	           * check if the exception type is TokenExpiredException and pass the flow to the verifyCsrfException
	           * @param initializeException represent the exception received during the initialize
	           */
	        this.processInitializeException = function (initializeException) {
	            if (initializeException === void 0) { initializeException = {}; }
	            var handlers = _this.adobeIdData.handlers;
	            Log$1.warn('initialize', initializeException);
	            if (initializeException instanceof ModalSignInEvent) {
	                // this happens when popup window redirects and the state from fragment contains imslibmodal property as true
	                return _this.notifyParentAboutModalSignIn(initializeException);
	            }
	            _this.restoreHash();
	            if (initializeException instanceof TokenExpiredException) {
	                handlers.triggerOnAccessTokenHasExpired();
	            }
	            return Promise.reject(initializeException);
	        };
	        /**
	         * method called in case of exception on initialize.  if error is RideError, ir redirects to the jump url from RideException.jump
	         */
	        this.verifyRideErrorException = function (ex) {
	            if (ex instanceof RideException && ex.jump) {
	                UrlHelper$1.replaceUrl(ex.jump);
	            }
	            return Promise.reject(ex);
	        };
	        /**
	         * method called in case of exception on initialize.  if error type is CSRF, it calls the signOut methods
	         */
	        this.verifyCsrfException = function (ex) {
	            var errorType = ex.type;
	            if (errorType && errorType === IErrorType.CSRF) {
	                _this.signOut();
	            }
	            return Promise.reject(ex);
	        };
	        /**
	         * method called after a successful call to the getTokenAndProfile method in order to process the token response
	         * tokenProfile: TokenProfileResponse - contains the token fields and eventually the user profile
	         * @returns Promise
	         */
	        this.processTokenResponse = function (tokenProfile) {
	            var handlers = _this.adobeIdData.handlers;
	            var tokenFields = tokenProfile.tokenFields, profile = tokenProfile.profile;
	            var token = tokenFields.tokenValue, state = tokenFields.state, expire = tokenFields.expire, sid = tokenFields.sid, userId = tokenFields.user_id, _a = tokenFields.other, other = _a === void 0 ? {} : _a;
	            Log$1.info('token', token);
	            if (other.from_ims) {
	                UrlHelper$1.setHash(other.old_hash || '');
	            }
	            _this.profileService.removeProfileIfOtherUser(userId);
	            var notificationData = { token: token, expire: expire, sid: sid };
	            tokenFields.isReauth() ? handlers.triggerOnReauthAccessToken(notificationData) : _this.tokenReceived(notificationData);
	            if (profile) {
	                _this.profileService.saveProfileToStorage(profile);
	            }
	            return Promise.resolve(state);
	        };
	        /**
	         * method used during initialization in order to get a ijt token
	         * https://wiki.corp.adobe.com/display/ims/Implicit+Jump+Tokens
	         * @returns {Promise<any>} ijt response
	         * @param {string} ijt value used for token excahnge (other than the one from adobeid)
	         * @usage adobeIMS.adobeIdData.ijt = 'ijtValue' followed by adobeIMS.initialize()
	         */
	        this.exchangeIjt = function (ijt) {
	            var adobeIjt = _this.adobeIdData.ijt;
	            if (!ijt && !adobeIjt) {
	                return Promise.reject(new Error('please set the adobeid.ijt value'));
	            }
	            return _this.tokenService.exchangeIjt(ijt || adobeIjt).then(function (resp) {
	                _this.profileService.removeProfile();
	                return Promise.resolve(resp);
	            });
	        };
	        this.adobeIdData = new AdobeIdData(adobeData);
	        var _a = this.adobeIdData, _b = _a.api_parameters, apiParameters = _b === void 0 ? {} : _b, clientId = _a.client_id, scope = _a.scope, useLocalStorage = _a.useLocalStorage, autoValidateToken = _a.autoValidateToken, modalMode = _a.modalMode, modalSettings = _a.modalSettings;
	        this.imsApis = new ImsApis(apiParameters);
	        this.csrfService = new CsrfService(clientId);
	        this.serviceRequest = {
	            clientId: clientId,
	            scope: scope,
	            imsApis: this.imsApis
	        };
	        this.tokenService = new TokenService(__assign(__assign({}, this.serviceRequest), { useLocalStorage: useLocalStorage,
	            autoValidateToken: autoValidateToken }), this.csrfService);
	        this.profileService = new ProfileService(this.serviceRequest);
	        this.signInservice = modalMode ? new SignInModalService(this.onPopupMessage, modalSettings) : new SignInService();
	    }
	    Object.defineProperty(AdobeIMS.prototype, "version", {
	        /**
	         * represents the adobe ims library version
	         */
	        get: function () {
	            return Environment$1.jslibver;
	        },
	        enumerable: true,
	        configurable: true
	    });
	    Object.defineProperty(AdobeIMS.prototype, "adobeid", {
	        /**
	         * AdobeIdData
	         * the values for adobeId are read from window.adobeid or passed by using the constructor
	        */
	        get: function () {
	            return __assign({}, this.adobeIdData);
	        },
	        enumerable: true,
	        configurable: true
	    });
	    /**
	     * enable the logging mechanism
	     */
	    AdobeIMS.prototype.enableLogging = function () {
	        Log$1.enableLogging();
	    };
	    /**
	     * disable the logging mechanism
	     */
	    AdobeIMS.prototype.disableLogging = function () {
	        Log$1.disableLogging();
	    };
	    /**
	     * function used to check is initialized; in case of false, an error is triggered
	     */
	    AdobeIMS.prototype.checkInitialized = function () {
	        if (this.initialized) {
	            return;
	        }
	        //   throw new Error( 'the imslib is not yet initialized' );
	    };
	    /**
	     * Method used to redirect the user to the signup screen
	     *
	     * <uml>
	     * start
	     * :Create the state object by using appCode, appVersion (used on server side) from adobeId.analytics and contextToBePassedOnRedirect;
	     * :Create the redirect url using external parameters. state object will be part of redirect url;
	     * :SignUp;
	     * :initialize method is used which will trigger the token and profile;
	     * end
	     *
	     * </uml>
	     *
	     * @param requestedParameters object sent from outside in order to use diferent values for signUp
	     * @param contextToBePassedOnRedirect {any | undefined} represents the context which is passed during redirect
	     *
	    */
	    AdobeIMS.prototype.signUp = function (requestedParameters, contextToBePassedOnRedirect) {
	        var _this = this;
	        if (requestedParameters === void 0) { requestedParameters = {}; }
	        this.checkInitialized();
	        var _a = this, adobeIdData = _a.adobeIdData, csrfService = _a.csrfService;
	        if (!adobeIdData) {
	            throw new Error('no adobeId on reAuthenticate');
	        }
	        var nonce = csrfService.initialize();
	        return adobeIdData.createSignUpRedirectRequest(requestedParameters, contextToBePassedOnRedirect, nonce)
	            .then(function (authorizeRequestData) {
	            _this.signInservice.signIn(authorizeRequestData);
	        });
	    };
	    /**
	     * @function Method used to check if the user is signed in or not.
	     * if local storage contains a token and is validated (only against expiration), the result is true
	     * returns {boolean}
	    */
	    AdobeIMS.prototype.isSignedInUser = function () {
	        return this.getAccessToken() ? true : false;
	    };
	    /**
	     * @function Method used to get the user profile in case the user is logged)
	     * returns {IDictionary | null}  representing the user profile or null
	    */
	    AdobeIMS.prototype.getProfile = function () {
	        var _this = this;
	        var profile = this.profileService.getProfileFromStorage();
	        if (profile) {
	            return Promise.resolve(profile);
	        }
	        var tokenInfo = this.getAccessToken();
	        if (!tokenInfo) {
	            var profileException = 'please login before getting the profile';
	            return Promise.reject(new ProfileException(profileException));
	        }
	        return this.profileService.getProfile(tokenInfo.token).then(function (profile) {
	            return Promise.resolve(profile);
	        })
	            .catch(function (ex) {
	            Log$1.error('get profile exception ', ex);
	            if (!(ex instanceof HttpErrorResponse)) {
	                return Promise.reject(new ProfileException(ex.message || ex));
	            }
	            return _this.refreshToken().then(function (tokenResponse) {
	                return Promise.resolve(tokenResponse.profile);
	            });
	        });
	    };
	    /**
	     * @function Returns the URL of the user avatar
	     * @param {UserId} userId
	    */
	    AdobeIMS.prototype.avatarUrl = function (userId) {
	        return this.imsApis.avatarUrl(userId);
	    };
	    /**
	      * method used to retrieve the token release flags
	    */
	    AdobeIMS.prototype.getReleaseFlags = function () {
	        return this.tokenService.getReleaseFlags();
	    };
	    /**
	      *
	      * Returns the access token value from the local storage
	      *
	      * <uml>
	      * start
	      * :getAccessToken;
	      * :check the local storage;
	      * :if token exists, it is validated agains expiration;
	      * :if valid the token is returned otherwise an empty token;
	      * end
	      * </uml>
	      *
	    */
	    AdobeIMS.prototype.getAccessToken = function () {
	        var tokenFields = this.tokenService.getTokenFieldsFromStorage();
	        if (!tokenFields) {
	            return null;
	        }
	        var token = tokenFields.tokenValue, expire = tokenFields.expire, sid = tokenFields.sid;
	        return { token: token, expire: expire, sid: sid };
	    };
	    /**
	     *
	     * Returns the reauth access token value from the local storage
	     *
	     * <uml>
	     * start
	     * :getReauthAccessToken;
	     * :check the local storage;
	     * :if token exists, it is validated agains expiration;
	     * :if valid the token is returned otherwise an empty token;
	     * end
	     * </uml>
	     *
	   */
	    AdobeIMS.prototype.getReauthAccessToken = function () {
	        var tokenFields = this.tokenService.getTokenFieldsFromStorage(true);
	        if (!tokenFields) {
	            return null;
	        }
	        var token = tokenFields.tokenValue, expire = tokenFields.expire, sid = tokenFields.sid;
	        return { token: token, expire: expire, sid: sid };
	    };
	    /**
	     * method used to get the social providers.
	     * returns Promise - can be used to determine when the call has been ended and read the social providers response
	     */
	    AdobeIMS.prototype.listSocialProviders = function () {
	        var _this = this;
	        return new Promise(function (resolve, reject) {
	            var client_id = _this.adobeIdData.client_id;
	            _this.imsApis.listSocialProviders({
	                client_id: client_id,
	            }).then(function (response) {
	                resolve(response);
	            })
	                .catch(function (ex) {
	                reject(ex);
	            });
	        });
	    };
	    /**
	     *
	     * @param token {string} represents the access token
	     * @param expire {Date} the date when the token will expire
	     */
	    AdobeIMS.prototype.tokenReceived = function (tokenInfo) {
	        var handlers = this.adobeIdData.handlers;
	        handlers.triggerOnAccessToken(tokenInfo);
	        TokenAutoRefresh$1.startAutoRefreshFlow({
	            expire: tokenInfo.expire,
	            refreshTokenMethod: this.refreshToken,
	        });
	    };
	    /**
	     * method used to process the token and profile
	     * @param tokenResponse {IRefreshTokenResponse} represents the token and profile received from back-end
	     */
	    AdobeIMS.prototype.onTokenProfileReceived = function (tokenResponse) {
	        var tokenInfo = tokenResponse.tokenInfo, profile = tokenResponse.profile;
	        Log$1.info('token', tokenInfo);
	        this.tokenReceived(tokenInfo);
	        this.profileService.saveProfileToStorage(profile);
	        return Promise.resolve(tokenResponse);
	    };
	    /**
	     * @returns a promise which is resolved as true in case the token is valid otherwise false
	     * validate the existing token;
	     */
	    AdobeIMS.prototype.validateToken = function () {
	        var _this = this;
	        return this.tokenService.validateToken().then(function () {
	            return Promise.resolve(true);
	        })
	            .catch(function (ex) {
	            Log$1.warn('validate token exception', ex);
	            if (ex instanceof HttpErrorResponse) {
	                return Promise.reject(false);
	            }
	            _this.profileService.removeProfile();
	            return Promise.reject(false);
	        });
	    };
	    /**
	     * method used in case the existent token has expired
	     */
	    AdobeIMS.prototype.onTokenExpired = function () {
	        var handlers = this.adobeIdData.handlers;
	        this.tokenService.purge();
	        handlers.triggerOnAccessTokenHasExpired();
	    };
	    /**
	     * set a new token into the local storage
	     * @param tokenInfo {tokenInfo} represents the token/ expire information used by library
	     */
	    AdobeIMS.prototype.setStandAloneToken = function (standaloneToken) {
	        return this.tokenService.setStandAloneToken(standaloneToken);
	    };
	    /**
	     * Method called on library initialization or page reloading
	     * <uml>
	     * start
	     * :initialize method;
	     * :get token;
	     * if (fragment) then (yes)
	     * :returns the token from fragment;
	     * else (check local storage)
	     * :returns the token from local storage;
	     * endif
	     * :if no token: return triggerOnAccessTokenHasExpired;
	     * :triggerOnAccessToken;
	     * :back-end: calls getProfile ;
	     * :triggerOnReady ;
	     * end
	     * </uml>
	     *
	     * Note: this method is automatically called on every page reload;
	    */
	    AdobeIMS.prototype.initialize = function () {
	        var _this = this;
	        var _a = this.adobeIdData, handlers = _a.handlers, standalone = _a.standalone, ijt = _a.ijt;
	        var state = null;
	        if (standalone) {
	            this.setStandAloneToken(standalone);
	        }
	        var initializationMethod = ijt ? this.exchangeIjt : this.tokenService.getTokenAndProfile;
	        return initializationMethod()
	            .then(this.processTokenResponse, function (ex) { return _this.processInitializeException(ex)
	            .catch(function (ex) { return _this.verifyRideErrorException(ex); })
	            .catch(function (ex) { return _this.verifyCsrfException(ex)
	            .catch(function (ex) { return Log$1.info('initialize exception ended', ex); }); }); })
	            .then(function (stateValue) {
	            state = stateValue;
	        })
	            .finally(function () {
	            Log$1.info('onReady initialization');
	            window.addEventListener(ASK_FOR_IMSLIB_INSTANCE_DOM_EVENT_NAME, function () {
	                _this.triggerOnImsInstance(_this);
	            }, false);
	            handlers.triggerOnReady(state ? state.context : null);
	            _this.triggerOnImsInstance(_this);
	            _this.initialized = true;
	            return Promise.resolve(state);
	        });
	    };
	    /**
	     * pass the redirect url from the popup window to parent
	     * @param modalSignInEvent {ModalSignInEvent} represents the redirect url after user has signed in
	     */
	    AdobeIMS.prototype.notifyParentAboutModalSignIn = function (modalSignInEvent) {
	        var href = window.location.href.replace('imslibmodal', 'wasmodal');
	        if (window.opener) {
	            window.opener.postMessage(href, '*');
	            window.close();
	        }
	        else {
	            window["" + modalSignInEvent.wndRedirectPropName] = href;
	        }
	        return Promise.reject('popup');
	    };
	    /**
	     * restore the window hash value to the initial one
	     */
	    AdobeIMS.prototype.restoreHash = function () {
	        var fragmentValues = FragmentHelper$1.fragmentToObject();
	        if (!fragmentValues || !fragmentValues.from_ims) {
	            return;
	        }
	        UrlHelper$1.setHash(fragmentValues.old_hash || '');
	    };
	    /**
	     * Exchange the user's access_token for a Transitory Access Code (TAC) for target client and scope
	     * @see {@link https://wiki.corp.adobe.com/display/ims/Transitory+Authorization+Codes |Transitory Authorization Codes}
	     * @param tacRequest {ITransitoryAuthorizationRequest}
	     * @param externalParameters {IDictionary} object used in order to update the default api values
	     */
	    AdobeIMS.prototype.getTransitoryAuthorizationCode = function (tacRequest, externalParameters) {
	        if (externalParameters === void 0) { externalParameters = {}; }
	        tacRequest = tacRequest || {};
	        tacRequest.response_type = tacRequest.response_type || 'code';
	        tacRequest.target_client_id = tacRequest.target_client_id || this.adobeIdData.client_id;
	        tacRequest.target_scope = tacRequest.target_scope || this.adobeIdData.scope;
	        return this.imsApis.getTransitoryAuthorizationCode(tacRequest, externalParameters, this.adobeIdData.client_id);
	    };
	    /**
	     * Allows a client to launch a system-browser and arrive at another IMS-integrated application
	     * https://wiki.corp.adobe.com/pages/viewpage.action?spaceKey=ims&title=IMS+API+-+jumptoken
	     * @param jumpTokenRequest {IJumpTokenRequest}
	     * @param externalParameters {object} object used to override the default request values
	     * @returns IJumpTokenResponse
	     */
	    AdobeIMS.prototype.jumpToken = function (jumpTokenRequest, externalParameters) {
	        if (externalParameters === void 0) { externalParameters = {}; }
	        jumpTokenRequest.target_client_id = jumpTokenRequest.target_client_id || this.adobeIdData.client_id;
	        jumpTokenRequest.target_scope = jumpTokenRequest.target_scope || this.adobeIdData.scope;
	        return this.imsApis.jumpToken(jumpTokenRequest, externalParameters, this.adobeIdData.client_id);
	    };
	    return AdobeIMS;
	}());

	/**
	 * singleton class which is created on the same time when library is injected into the page.
	 * it is used to provide the possibility to an external library to create a new instance of AdobeIMS
	 * also, if the window contains a value for adobeId, it will create a new instance of AdobeIMS
	 */
	var ImsInitialization = /** @class */ (function () {
	    function ImsInitialization() {
	        /**
	         *
	         * @param adobeData represents the custom adobeData
	         * @returns a new instance of the AdobeIms library based on input adobeIdData
	         */
	        this.createIMSLib = function (adobeData, adobeImsWindowKey) {
	            if (adobeData === void 0) { adobeData = null; }
	            if (adobeImsWindowKey === void 0) { adobeImsWindowKey = AdobeIMSKey; }
	            var adobeIMS = new AdobeIMS(adobeData);
	            window[adobeImsWindowKey] = adobeIMS;
	            return adobeIMS;
	        };
	    }
	    /**
	   * create a new instance of ims lib based on adobe id data
	   */
	    ImsInitialization.prototype.initAdobeIms = function () {
	        window[AdobeImsFactory] = {
	            createIMSLib: this.createIMSLib
	        };
	        var adobeIMS = window[AdobeIMSKey] || null;
	        if (!adobeIMS) {
	            var adobeIdData = window[AdobeIdKey];
	            if (!adobeIdData) {
	                return;
	            }
	            adobeIMS = this.createIMSLib(adobeIdData, AdobeIMSKey);
	            adobeIMS.initialize();
	        }
	    };
	    return ImsInitialization;
	}());
	var ImsInitialization$1 = new ImsInitialization();

	/**
	 * singleton class which is created on the same time when library is injected into the page.
	 * it is used to provide the possibility to an external library to create a new instance of AdobeIMS
	 * also, if the window contains a value for adobeId, it will create a new instance of AdobeIMS
	 */
	var MainPolyfill = /** @class */ (function () {
	    function MainPolyfill() {
	        ImsInitialization$1.initAdobeIms();
	    }
	    /**
	   * method used only for testing in order to ensure the libray is initialized
	   */
	    MainPolyfill.prototype.initialize = function () {
	        return true;
	    };
	    return MainPolyfill;
	}());
	var MainPolyfill$1 = new MainPolyfill();

	return MainPolyfill$1;

}());
