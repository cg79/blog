var roll = (function () {
	var commonjsGlobal = typeof globalThis !== 'undefined' ? globalThis : typeof window !== 'undefined' ? window : typeof global !== 'undefined' ? global : typeof self !== 'undefined' ? self : {};

	function unwrapExports (x) {
		return x && x.__esModule && Object.prototype.hasOwnProperty.call(x, 'default') ? x['default'] : x;
	}

	function createCommonjsModule(fn, module) {
		return module = { exports: {} }, fn(module, module.exports), module.exports;
	}

	var check = function (it) {
	  return it && it.Math == Math && it;
	};

	// https://github.com/zloirock/core-js/issues/86#issuecomment-115759028
	var global_1 =
	  // eslint-disable-next-line no-undef
	  check(typeof globalThis == 'object' && globalThis) ||
	  check(typeof window == 'object' && window) ||
	  check(typeof self == 'object' && self) ||
	  check(typeof commonjsGlobal == 'object' && commonjsGlobal) ||
	  // eslint-disable-next-line no-new-func
	  Function('return this')();

	var fails = function (exec) {
	  try {
	    return !!exec();
	  } catch (error) {
	    return true;
	  }
	};

	// Thank's IE8 for his funny defineProperty
	var descriptors = !fails(function () {
	  return Object.defineProperty({}, 1, { get: function () { return 7; } })[1] != 7;
	});

	var nativePropertyIsEnumerable = {}.propertyIsEnumerable;
	var getOwnPropertyDescriptor = Object.getOwnPropertyDescriptor;

	// Nashorn ~ JDK8 bug
	var NASHORN_BUG = getOwnPropertyDescriptor && !nativePropertyIsEnumerable.call({ 1: 2 }, 1);

	// `Object.prototype.propertyIsEnumerable` method implementation
	// https://tc39.github.io/ecma262/#sec-object.prototype.propertyisenumerable
	var f = NASHORN_BUG ? function propertyIsEnumerable(V) {
	  var descriptor = getOwnPropertyDescriptor(this, V);
	  return !!descriptor && descriptor.enumerable;
	} : nativePropertyIsEnumerable;

	var objectPropertyIsEnumerable = {
		f: f
	};

	var createPropertyDescriptor = function (bitmap, value) {
	  return {
	    enumerable: !(bitmap & 1),
	    configurable: !(bitmap & 2),
	    writable: !(bitmap & 4),
	    value: value
	  };
	};

	var toString = {}.toString;

	var classofRaw = function (it) {
	  return toString.call(it).slice(8, -1);
	};

	var split = ''.split;

	// fallback for non-array-like ES3 and non-enumerable old V8 strings
	var indexedObject = fails(function () {
	  // throws an error in rhino, see https://github.com/mozilla/rhino/issues/346
	  // eslint-disable-next-line no-prototype-builtins
	  return !Object('z').propertyIsEnumerable(0);
	}) ? function (it) {
	  return classofRaw(it) == 'String' ? split.call(it, '') : Object(it);
	} : Object;

	// `RequireObjectCoercible` abstract operation
	// https://tc39.github.io/ecma262/#sec-requireobjectcoercible
	var requireObjectCoercible = function (it) {
	  if (it == undefined) throw TypeError("Can't call method on " + it);
	  return it;
	};

	// toObject with fallback for non-array-like ES3 strings



	var toIndexedObject = function (it) {
	  return indexedObject(requireObjectCoercible(it));
	};

	var isObject = function (it) {
	  return typeof it === 'object' ? it !== null : typeof it === 'function';
	};

	// `ToPrimitive` abstract operation
	// https://tc39.github.io/ecma262/#sec-toprimitive
	// instead of the ES6 spec version, we didn't implement @@toPrimitive case
	// and the second argument - flag - preferred type is a string
	var toPrimitive = function (input, PREFERRED_STRING) {
	  if (!isObject(input)) return input;
	  var fn, val;
	  if (PREFERRED_STRING && typeof (fn = input.toString) == 'function' && !isObject(val = fn.call(input))) return val;
	  if (typeof (fn = input.valueOf) == 'function' && !isObject(val = fn.call(input))) return val;
	  if (!PREFERRED_STRING && typeof (fn = input.toString) == 'function' && !isObject(val = fn.call(input))) return val;
	  throw TypeError("Can't convert object to primitive value");
	};

	var hasOwnProperty = {}.hasOwnProperty;

	var has = function (it, key) {
	  return hasOwnProperty.call(it, key);
	};

	var document$1 = global_1.document;
	// typeof document.createElement is 'object' in old IE
	var EXISTS = isObject(document$1) && isObject(document$1.createElement);

	var documentCreateElement = function (it) {
	  return EXISTS ? document$1.createElement(it) : {};
	};

	// Thank's IE8 for his funny defineProperty
	var ie8DomDefine = !descriptors && !fails(function () {
	  return Object.defineProperty(documentCreateElement('div'), 'a', {
	    get: function () { return 7; }
	  }).a != 7;
	});

	var nativeGetOwnPropertyDescriptor = Object.getOwnPropertyDescriptor;

	// `Object.getOwnPropertyDescriptor` method
	// https://tc39.github.io/ecma262/#sec-object.getownpropertydescriptor
	var f$1 = descriptors ? nativeGetOwnPropertyDescriptor : function getOwnPropertyDescriptor(O, P) {
	  O = toIndexedObject(O);
	  P = toPrimitive(P, true);
	  if (ie8DomDefine) try {
	    return nativeGetOwnPropertyDescriptor(O, P);
	  } catch (error) { /* empty */ }
	  if (has(O, P)) return createPropertyDescriptor(!objectPropertyIsEnumerable.f.call(O, P), O[P]);
	};

	var objectGetOwnPropertyDescriptor = {
		f: f$1
	};

	var anObject = function (it) {
	  if (!isObject(it)) {
	    throw TypeError(String(it) + ' is not an object');
	  } return it;
	};

	var nativeDefineProperty = Object.defineProperty;

	// `Object.defineProperty` method
	// https://tc39.github.io/ecma262/#sec-object.defineproperty
	var f$2 = descriptors ? nativeDefineProperty : function defineProperty(O, P, Attributes) {
	  anObject(O);
	  P = toPrimitive(P, true);
	  anObject(Attributes);
	  if (ie8DomDefine) try {
	    return nativeDefineProperty(O, P, Attributes);
	  } catch (error) { /* empty */ }
	  if ('get' in Attributes || 'set' in Attributes) throw TypeError('Accessors not supported');
	  if ('value' in Attributes) O[P] = Attributes.value;
	  return O;
	};

	var objectDefineProperty = {
		f: f$2
	};

	var createNonEnumerableProperty = descriptors ? function (object, key, value) {
	  return objectDefineProperty.f(object, key, createPropertyDescriptor(1, value));
	} : function (object, key, value) {
	  object[key] = value;
	  return object;
	};

	var setGlobal = function (key, value) {
	  try {
	    createNonEnumerableProperty(global_1, key, value);
	  } catch (error) {
	    global_1[key] = value;
	  } return value;
	};

	var SHARED = '__core-js_shared__';
	var store = global_1[SHARED] || setGlobal(SHARED, {});

	var sharedStore = store;

	var functionToString = Function.toString;

	// this helper broken in `3.4.1-3.4.4`, so we can't use `shared` helper
	if (typeof sharedStore.inspectSource != 'function') {
	  sharedStore.inspectSource = function (it) {
	    return functionToString.call(it);
	  };
	}

	var inspectSource = sharedStore.inspectSource;

	var WeakMap = global_1.WeakMap;

	var nativeWeakMap = typeof WeakMap === 'function' && /native code/.test(inspectSource(WeakMap));

	var shared = createCommonjsModule(function (module) {
	(module.exports = function (key, value) {
	  return sharedStore[key] || (sharedStore[key] = value !== undefined ? value : {});
	})('versions', []).push({
	  version: '3.6.4',
	  mode:  'global',
	  copyright: '© 2020 Denis Pushkarev (zloirock.ru)'
	});
	});

	var id = 0;
	var postfix = Math.random();

	var uid = function (key) {
	  return 'Symbol(' + String(key === undefined ? '' : key) + ')_' + (++id + postfix).toString(36);
	};

	var keys = shared('keys');

	var sharedKey = function (key) {
	  return keys[key] || (keys[key] = uid(key));
	};

	var hiddenKeys = {};

	var WeakMap$1 = global_1.WeakMap;
	var set, get, has$1;

	var enforce = function (it) {
	  return has$1(it) ? get(it) : set(it, {});
	};

	var getterFor = function (TYPE) {
	  return function (it) {
	    var state;
	    if (!isObject(it) || (state = get(it)).type !== TYPE) {
	      throw TypeError('Incompatible receiver, ' + TYPE + ' required');
	    } return state;
	  };
	};

	if (nativeWeakMap) {
	  var store$1 = new WeakMap$1();
	  var wmget = store$1.get;
	  var wmhas = store$1.has;
	  var wmset = store$1.set;
	  set = function (it, metadata) {
	    wmset.call(store$1, it, metadata);
	    return metadata;
	  };
	  get = function (it) {
	    return wmget.call(store$1, it) || {};
	  };
	  has$1 = function (it) {
	    return wmhas.call(store$1, it);
	  };
	} else {
	  var STATE = sharedKey('state');
	  hiddenKeys[STATE] = true;
	  set = function (it, metadata) {
	    createNonEnumerableProperty(it, STATE, metadata);
	    return metadata;
	  };
	  get = function (it) {
	    return has(it, STATE) ? it[STATE] : {};
	  };
	  has$1 = function (it) {
	    return has(it, STATE);
	  };
	}

	var internalState = {
	  set: set,
	  get: get,
	  has: has$1,
	  enforce: enforce,
	  getterFor: getterFor
	};

	var redefine = createCommonjsModule(function (module) {
	var getInternalState = internalState.get;
	var enforceInternalState = internalState.enforce;
	var TEMPLATE = String(String).split('String');

	(module.exports = function (O, key, value, options) {
	  var unsafe = options ? !!options.unsafe : false;
	  var simple = options ? !!options.enumerable : false;
	  var noTargetGet = options ? !!options.noTargetGet : false;
	  if (typeof value == 'function') {
	    if (typeof key == 'string' && !has(value, 'name')) createNonEnumerableProperty(value, 'name', key);
	    enforceInternalState(value).source = TEMPLATE.join(typeof key == 'string' ? key : '');
	  }
	  if (O === global_1) {
	    if (simple) O[key] = value;
	    else setGlobal(key, value);
	    return;
	  } else if (!unsafe) {
	    delete O[key];
	  } else if (!noTargetGet && O[key]) {
	    simple = true;
	  }
	  if (simple) O[key] = value;
	  else createNonEnumerableProperty(O, key, value);
	// add fake Function#toString for correct work wrapped methods / constructors with methods like LoDash isNative
	})(Function.prototype, 'toString', function toString() {
	  return typeof this == 'function' && getInternalState(this).source || inspectSource(this);
	});
	});

	var path = global_1;

	var aFunction = function (variable) {
	  return typeof variable == 'function' ? variable : undefined;
	};

	var getBuiltIn = function (namespace, method) {
	  return arguments.length < 2 ? aFunction(path[namespace]) || aFunction(global_1[namespace])
	    : path[namespace] && path[namespace][method] || global_1[namespace] && global_1[namespace][method];
	};

	var ceil = Math.ceil;
	var floor = Math.floor;

	// `ToInteger` abstract operation
	// https://tc39.github.io/ecma262/#sec-tointeger
	var toInteger = function (argument) {
	  return isNaN(argument = +argument) ? 0 : (argument > 0 ? floor : ceil)(argument);
	};

	var min = Math.min;

	// `ToLength` abstract operation
	// https://tc39.github.io/ecma262/#sec-tolength
	var toLength = function (argument) {
	  return argument > 0 ? min(toInteger(argument), 0x1FFFFFFFFFFFFF) : 0; // 2 ** 53 - 1 == 9007199254740991
	};

	var max = Math.max;
	var min$1 = Math.min;

	// Helper for a popular repeating case of the spec:
	// Let integer be ? ToInteger(index).
	// If integer < 0, let result be max((length + integer), 0); else let result be min(integer, length).
	var toAbsoluteIndex = function (index, length) {
	  var integer = toInteger(index);
	  return integer < 0 ? max(integer + length, 0) : min$1(integer, length);
	};

	// `Array.prototype.{ indexOf, includes }` methods implementation
	var createMethod = function (IS_INCLUDES) {
	  return function ($this, el, fromIndex) {
	    var O = toIndexedObject($this);
	    var length = toLength(O.length);
	    var index = toAbsoluteIndex(fromIndex, length);
	    var value;
	    // Array#includes uses SameValueZero equality algorithm
	    // eslint-disable-next-line no-self-compare
	    if (IS_INCLUDES && el != el) while (length > index) {
	      value = O[index++];
	      // eslint-disable-next-line no-self-compare
	      if (value != value) return true;
	    // Array#indexOf ignores holes, Array#includes - not
	    } else for (;length > index; index++) {
	      if ((IS_INCLUDES || index in O) && O[index] === el) return IS_INCLUDES || index || 0;
	    } return !IS_INCLUDES && -1;
	  };
	};

	var arrayIncludes = {
	  // `Array.prototype.includes` method
	  // https://tc39.github.io/ecma262/#sec-array.prototype.includes
	  includes: createMethod(true),
	  // `Array.prototype.indexOf` method
	  // https://tc39.github.io/ecma262/#sec-array.prototype.indexof
	  indexOf: createMethod(false)
	};

	var indexOf = arrayIncludes.indexOf;


	var objectKeysInternal = function (object, names) {
	  var O = toIndexedObject(object);
	  var i = 0;
	  var result = [];
	  var key;
	  for (key in O) !has(hiddenKeys, key) && has(O, key) && result.push(key);
	  // Don't enum bug & hidden keys
	  while (names.length > i) if (has(O, key = names[i++])) {
	    ~indexOf(result, key) || result.push(key);
	  }
	  return result;
	};

	// IE8- don't enum bug keys
	var enumBugKeys = [
	  'constructor',
	  'hasOwnProperty',
	  'isPrototypeOf',
	  'propertyIsEnumerable',
	  'toLocaleString',
	  'toString',
	  'valueOf'
	];

	var hiddenKeys$1 = enumBugKeys.concat('length', 'prototype');

	// `Object.getOwnPropertyNames` method
	// https://tc39.github.io/ecma262/#sec-object.getownpropertynames
	var f$3 = Object.getOwnPropertyNames || function getOwnPropertyNames(O) {
	  return objectKeysInternal(O, hiddenKeys$1);
	};

	var objectGetOwnPropertyNames = {
		f: f$3
	};

	var f$4 = Object.getOwnPropertySymbols;

	var objectGetOwnPropertySymbols = {
		f: f$4
	};

	// all object keys, includes non-enumerable and symbols
	var ownKeys = getBuiltIn('Reflect', 'ownKeys') || function ownKeys(it) {
	  var keys = objectGetOwnPropertyNames.f(anObject(it));
	  var getOwnPropertySymbols = objectGetOwnPropertySymbols.f;
	  return getOwnPropertySymbols ? keys.concat(getOwnPropertySymbols(it)) : keys;
	};

	var copyConstructorProperties = function (target, source) {
	  var keys = ownKeys(source);
	  var defineProperty = objectDefineProperty.f;
	  var getOwnPropertyDescriptor = objectGetOwnPropertyDescriptor.f;
	  for (var i = 0; i < keys.length; i++) {
	    var key = keys[i];
	    if (!has(target, key)) defineProperty(target, key, getOwnPropertyDescriptor(source, key));
	  }
	};

	var replacement = /#|\.prototype\./;

	var isForced = function (feature, detection) {
	  var value = data[normalize(feature)];
	  return value == POLYFILL ? true
	    : value == NATIVE ? false
	    : typeof detection == 'function' ? fails(detection)
	    : !!detection;
	};

	var normalize = isForced.normalize = function (string) {
	  return String(string).replace(replacement, '.').toLowerCase();
	};

	var data = isForced.data = {};
	var NATIVE = isForced.NATIVE = 'N';
	var POLYFILL = isForced.POLYFILL = 'P';

	var isForced_1 = isForced;

	var getOwnPropertyDescriptor$1 = objectGetOwnPropertyDescriptor.f;






	/*
	  options.target      - name of the target object
	  options.global      - target is the global object
	  options.stat        - export as static methods of target
	  options.proto       - export as prototype methods of target
	  options.real        - real prototype method for the `pure` version
	  options.forced      - export even if the native feature is available
	  options.bind        - bind methods to the target, required for the `pure` version
	  options.wrap        - wrap constructors to preventing global pollution, required for the `pure` version
	  options.unsafe      - use the simple assignment of property instead of delete + defineProperty
	  options.sham        - add a flag to not completely full polyfills
	  options.enumerable  - export as enumerable property
	  options.noTargetGet - prevent calling a getter on target
	*/
	var _export = function (options, source) {
	  var TARGET = options.target;
	  var GLOBAL = options.global;
	  var STATIC = options.stat;
	  var FORCED, target, key, targetProperty, sourceProperty, descriptor;
	  if (GLOBAL) {
	    target = global_1;
	  } else if (STATIC) {
	    target = global_1[TARGET] || setGlobal(TARGET, {});
	  } else {
	    target = (global_1[TARGET] || {}).prototype;
	  }
	  if (target) for (key in source) {
	    sourceProperty = source[key];
	    if (options.noTargetGet) {
	      descriptor = getOwnPropertyDescriptor$1(target, key);
	      targetProperty = descriptor && descriptor.value;
	    } else targetProperty = target[key];
	    FORCED = isForced_1(GLOBAL ? key : TARGET + (STATIC ? '.' : '#') + key, options.forced);
	    // contained in target
	    if (!FORCED && targetProperty !== undefined) {
	      if (typeof sourceProperty === typeof targetProperty) continue;
	      copyConstructorProperties(sourceProperty, targetProperty);
	    }
	    // add a flag to not completely full polyfills
	    if (options.sham || (targetProperty && targetProperty.sham)) {
	      createNonEnumerableProperty(sourceProperty, 'sham', true);
	    }
	    // extend global
	    redefine(target, key, sourceProperty, options);
	  }
	};

	var nativePromiseConstructor = global_1.Promise;

	var redefineAll = function (target, src, options) {
	  for (var key in src) redefine(target, key, src[key], options);
	  return target;
	};

	var nativeSymbol = !!Object.getOwnPropertySymbols && !fails(function () {
	  // Chrome 38 Symbol has incorrect toString conversion
	  // eslint-disable-next-line no-undef
	  return !String(Symbol());
	});

	var useSymbolAsUid = nativeSymbol
	  // eslint-disable-next-line no-undef
	  && !Symbol.sham
	  // eslint-disable-next-line no-undef
	  && typeof Symbol.iterator == 'symbol';

	var WellKnownSymbolsStore = shared('wks');
	var Symbol$1 = global_1.Symbol;
	var createWellKnownSymbol = useSymbolAsUid ? Symbol$1 : Symbol$1 && Symbol$1.withoutSetter || uid;

	var wellKnownSymbol = function (name) {
	  if (!has(WellKnownSymbolsStore, name)) {
	    if (nativeSymbol && has(Symbol$1, name)) WellKnownSymbolsStore[name] = Symbol$1[name];
	    else WellKnownSymbolsStore[name] = createWellKnownSymbol('Symbol.' + name);
	  } return WellKnownSymbolsStore[name];
	};

	var defineProperty = objectDefineProperty.f;



	var TO_STRING_TAG = wellKnownSymbol('toStringTag');

	var setToStringTag = function (it, TAG, STATIC) {
	  if (it && !has(it = STATIC ? it : it.prototype, TO_STRING_TAG)) {
	    defineProperty(it, TO_STRING_TAG, { configurable: true, value: TAG });
	  }
	};

	var SPECIES = wellKnownSymbol('species');

	var setSpecies = function (CONSTRUCTOR_NAME) {
	  var Constructor = getBuiltIn(CONSTRUCTOR_NAME);
	  var defineProperty = objectDefineProperty.f;

	  if (descriptors && Constructor && !Constructor[SPECIES]) {
	    defineProperty(Constructor, SPECIES, {
	      configurable: true,
	      get: function () { return this; }
	    });
	  }
	};

	var aFunction$1 = function (it) {
	  if (typeof it != 'function') {
	    throw TypeError(String(it) + ' is not a function');
	  } return it;
	};

	var anInstance = function (it, Constructor, name) {
	  if (!(it instanceof Constructor)) {
	    throw TypeError('Incorrect ' + (name ? name + ' ' : '') + 'invocation');
	  } return it;
	};

	var iterators = {};

	var ITERATOR = wellKnownSymbol('iterator');
	var ArrayPrototype = Array.prototype;

	// check on default Array iterator
	var isArrayIteratorMethod = function (it) {
	  return it !== undefined && (iterators.Array === it || ArrayPrototype[ITERATOR] === it);
	};

	// optional / simple context binding
	var functionBindContext = function (fn, that, length) {
	  aFunction$1(fn);
	  if (that === undefined) return fn;
	  switch (length) {
	    case 0: return function () {
	      return fn.call(that);
	    };
	    case 1: return function (a) {
	      return fn.call(that, a);
	    };
	    case 2: return function (a, b) {
	      return fn.call(that, a, b);
	    };
	    case 3: return function (a, b, c) {
	      return fn.call(that, a, b, c);
	    };
	  }
	  return function (/* ...args */) {
	    return fn.apply(that, arguments);
	  };
	};

	var TO_STRING_TAG$1 = wellKnownSymbol('toStringTag');
	var test = {};

	test[TO_STRING_TAG$1] = 'z';

	var toStringTagSupport = String(test) === '[object z]';

	var TO_STRING_TAG$2 = wellKnownSymbol('toStringTag');
	// ES3 wrong here
	var CORRECT_ARGUMENTS = classofRaw(function () { return arguments; }()) == 'Arguments';

	// fallback for IE11 Script Access Denied error
	var tryGet = function (it, key) {
	  try {
	    return it[key];
	  } catch (error) { /* empty */ }
	};

	// getting tag from ES6+ `Object.prototype.toString`
	var classof = toStringTagSupport ? classofRaw : function (it) {
	  var O, tag, result;
	  return it === undefined ? 'Undefined' : it === null ? 'Null'
	    // @@toStringTag case
	    : typeof (tag = tryGet(O = Object(it), TO_STRING_TAG$2)) == 'string' ? tag
	    // builtinTag case
	    : CORRECT_ARGUMENTS ? classofRaw(O)
	    // ES3 arguments fallback
	    : (result = classofRaw(O)) == 'Object' && typeof O.callee == 'function' ? 'Arguments' : result;
	};

	var ITERATOR$1 = wellKnownSymbol('iterator');

	var getIteratorMethod = function (it) {
	  if (it != undefined) return it[ITERATOR$1]
	    || it['@@iterator']
	    || iterators[classof(it)];
	};

	// call something on iterator step with safe closing on error
	var callWithSafeIterationClosing = function (iterator, fn, value, ENTRIES) {
	  try {
	    return ENTRIES ? fn(anObject(value)[0], value[1]) : fn(value);
	  // 7.4.6 IteratorClose(iterator, completion)
	  } catch (error) {
	    var returnMethod = iterator['return'];
	    if (returnMethod !== undefined) anObject(returnMethod.call(iterator));
	    throw error;
	  }
	};

	var iterate_1 = createCommonjsModule(function (module) {
	var Result = function (stopped, result) {
	  this.stopped = stopped;
	  this.result = result;
	};

	var iterate = module.exports = function (iterable, fn, that, AS_ENTRIES, IS_ITERATOR) {
	  var boundFunction = functionBindContext(fn, that, AS_ENTRIES ? 2 : 1);
	  var iterator, iterFn, index, length, result, next, step;

	  if (IS_ITERATOR) {
	    iterator = iterable;
	  } else {
	    iterFn = getIteratorMethod(iterable);
	    if (typeof iterFn != 'function') throw TypeError('Target is not iterable');
	    // optimisation for array iterators
	    if (isArrayIteratorMethod(iterFn)) {
	      for (index = 0, length = toLength(iterable.length); length > index; index++) {
	        result = AS_ENTRIES
	          ? boundFunction(anObject(step = iterable[index])[0], step[1])
	          : boundFunction(iterable[index]);
	        if (result && result instanceof Result) return result;
	      } return new Result(false);
	    }
	    iterator = iterFn.call(iterable);
	  }

	  next = iterator.next;
	  while (!(step = next.call(iterator)).done) {
	    result = callWithSafeIterationClosing(iterator, boundFunction, step.value, AS_ENTRIES);
	    if (typeof result == 'object' && result && result instanceof Result) return result;
	  } return new Result(false);
	};

	iterate.stop = function (result) {
	  return new Result(true, result);
	};
	});

	var ITERATOR$2 = wellKnownSymbol('iterator');
	var SAFE_CLOSING = false;

	try {
	  var called = 0;
	  var iteratorWithReturn = {
	    next: function () {
	      return { done: !!called++ };
	    },
	    'return': function () {
	      SAFE_CLOSING = true;
	    }
	  };
	  iteratorWithReturn[ITERATOR$2] = function () {
	    return this;
	  };
	  // eslint-disable-next-line no-throw-literal
	  Array.from(iteratorWithReturn, function () { throw 2; });
	} catch (error) { /* empty */ }

	var checkCorrectnessOfIteration = function (exec, SKIP_CLOSING) {
	  if (!SKIP_CLOSING && !SAFE_CLOSING) return false;
	  var ITERATION_SUPPORT = false;
	  try {
	    var object = {};
	    object[ITERATOR$2] = function () {
	      return {
	        next: function () {
	          return { done: ITERATION_SUPPORT = true };
	        }
	      };
	    };
	    exec(object);
	  } catch (error) { /* empty */ }
	  return ITERATION_SUPPORT;
	};

	var SPECIES$1 = wellKnownSymbol('species');

	// `SpeciesConstructor` abstract operation
	// https://tc39.github.io/ecma262/#sec-speciesconstructor
	var speciesConstructor = function (O, defaultConstructor) {
	  var C = anObject(O).constructor;
	  var S;
	  return C === undefined || (S = anObject(C)[SPECIES$1]) == undefined ? defaultConstructor : aFunction$1(S);
	};

	var html = getBuiltIn('document', 'documentElement');

	var engineUserAgent = getBuiltIn('navigator', 'userAgent') || '';

	var engineIsIos = /(iphone|ipod|ipad).*applewebkit/i.test(engineUserAgent);

	var location = global_1.location;
	var set$1 = global_1.setImmediate;
	var clear = global_1.clearImmediate;
	var process = global_1.process;
	var MessageChannel = global_1.MessageChannel;
	var Dispatch = global_1.Dispatch;
	var counter = 0;
	var queue = {};
	var ONREADYSTATECHANGE = 'onreadystatechange';
	var defer, channel, port;

	var run = function (id) {
	  // eslint-disable-next-line no-prototype-builtins
	  if (queue.hasOwnProperty(id)) {
	    var fn = queue[id];
	    delete queue[id];
	    fn();
	  }
	};

	var runner = function (id) {
	  return function () {
	    run(id);
	  };
	};

	var listener = function (event) {
	  run(event.data);
	};

	var post = function (id) {
	  // old engines have not location.origin
	  global_1.postMessage(id + '', location.protocol + '//' + location.host);
	};

	// Node.js 0.9+ & IE10+ has setImmediate, otherwise:
	if (!set$1 || !clear) {
	  set$1 = function setImmediate(fn) {
	    var args = [];
	    var i = 1;
	    while (arguments.length > i) args.push(arguments[i++]);
	    queue[++counter] = function () {
	      // eslint-disable-next-line no-new-func
	      (typeof fn == 'function' ? fn : Function(fn)).apply(undefined, args);
	    };
	    defer(counter);
	    return counter;
	  };
	  clear = function clearImmediate(id) {
	    delete queue[id];
	  };
	  // Node.js 0.8-
	  if (classofRaw(process) == 'process') {
	    defer = function (id) {
	      process.nextTick(runner(id));
	    };
	  // Sphere (JS game engine) Dispatch API
	  } else if (Dispatch && Dispatch.now) {
	    defer = function (id) {
	      Dispatch.now(runner(id));
	    };
	  // Browsers with MessageChannel, includes WebWorkers
	  // except iOS - https://github.com/zloirock/core-js/issues/624
	  } else if (MessageChannel && !engineIsIos) {
	    channel = new MessageChannel();
	    port = channel.port2;
	    channel.port1.onmessage = listener;
	    defer = functionBindContext(port.postMessage, port, 1);
	  // Browsers with postMessage, skip WebWorkers
	  // IE8 has postMessage, but it's sync & typeof its postMessage is 'object'
	  } else if (global_1.addEventListener && typeof postMessage == 'function' && !global_1.importScripts && !fails(post)) {
	    defer = post;
	    global_1.addEventListener('message', listener, false);
	  // IE8-
	  } else if (ONREADYSTATECHANGE in documentCreateElement('script')) {
	    defer = function (id) {
	      html.appendChild(documentCreateElement('script'))[ONREADYSTATECHANGE] = function () {
	        html.removeChild(this);
	        run(id);
	      };
	    };
	  // Rest old browsers
	  } else {
	    defer = function (id) {
	      setTimeout(runner(id), 0);
	    };
	  }
	}

	var task = {
	  set: set$1,
	  clear: clear
	};

	var getOwnPropertyDescriptor$2 = objectGetOwnPropertyDescriptor.f;

	var macrotask = task.set;


	var MutationObserver = global_1.MutationObserver || global_1.WebKitMutationObserver;
	var process$1 = global_1.process;
	var Promise$1 = global_1.Promise;
	var IS_NODE = classofRaw(process$1) == 'process';
	// Node.js 11 shows ExperimentalWarning on getting `queueMicrotask`
	var queueMicrotaskDescriptor = getOwnPropertyDescriptor$2(global_1, 'queueMicrotask');
	var queueMicrotask = queueMicrotaskDescriptor && queueMicrotaskDescriptor.value;

	var flush, head, last, notify, toggle, node, promise, then;

	// modern engines have queueMicrotask method
	if (!queueMicrotask) {
	  flush = function () {
	    var parent, fn;
	    if (IS_NODE && (parent = process$1.domain)) parent.exit();
	    while (head) {
	      fn = head.fn;
	      head = head.next;
	      try {
	        fn();
	      } catch (error) {
	        if (head) notify();
	        else last = undefined;
	        throw error;
	      }
	    } last = undefined;
	    if (parent) parent.enter();
	  };

	  // Node.js
	  if (IS_NODE) {
	    notify = function () {
	      process$1.nextTick(flush);
	    };
	  // browsers with MutationObserver, except iOS - https://github.com/zloirock/core-js/issues/339
	  } else if (MutationObserver && !engineIsIos) {
	    toggle = true;
	    node = document.createTextNode('');
	    new MutationObserver(flush).observe(node, { characterData: true });
	    notify = function () {
	      node.data = toggle = !toggle;
	    };
	  // environments with maybe non-completely correct, but existent Promise
	  } else if (Promise$1 && Promise$1.resolve) {
	    // Promise.resolve without an argument throws an error in LG WebOS 2
	    promise = Promise$1.resolve(undefined);
	    then = promise.then;
	    notify = function () {
	      then.call(promise, flush);
	    };
	  // for other environments - macrotask based on:
	  // - setImmediate
	  // - MessageChannel
	  // - window.postMessag
	  // - onreadystatechange
	  // - setTimeout
	  } else {
	    notify = function () {
	      // strange IE + webpack dev server bug - use .call(global)
	      macrotask.call(global_1, flush);
	    };
	  }
	}

	var microtask = queueMicrotask || function (fn) {
	  var task = { fn: fn, next: undefined };
	  if (last) last.next = task;
	  if (!head) {
	    head = task;
	    notify();
	  } last = task;
	};

	var PromiseCapability = function (C) {
	  var resolve, reject;
	  this.promise = new C(function ($$resolve, $$reject) {
	    if (resolve !== undefined || reject !== undefined) throw TypeError('Bad Promise constructor');
	    resolve = $$resolve;
	    reject = $$reject;
	  });
	  this.resolve = aFunction$1(resolve);
	  this.reject = aFunction$1(reject);
	};

	// 25.4.1.5 NewPromiseCapability(C)
	var f$5 = function (C) {
	  return new PromiseCapability(C);
	};

	var newPromiseCapability = {
		f: f$5
	};

	var promiseResolve = function (C, x) {
	  anObject(C);
	  if (isObject(x) && x.constructor === C) return x;
	  var promiseCapability = newPromiseCapability.f(C);
	  var resolve = promiseCapability.resolve;
	  resolve(x);
	  return promiseCapability.promise;
	};

	var hostReportErrors = function (a, b) {
	  var console = global_1.console;
	  if (console && console.error) {
	    arguments.length === 1 ? console.error(a) : console.error(a, b);
	  }
	};

	var perform = function (exec) {
	  try {
	    return { error: false, value: exec() };
	  } catch (error) {
	    return { error: true, value: error };
	  }
	};

	var process$2 = global_1.process;
	var versions = process$2 && process$2.versions;
	var v8 = versions && versions.v8;
	var match, version;

	if (v8) {
	  match = v8.split('.');
	  version = match[0] + match[1];
	} else if (engineUserAgent) {
	  match = engineUserAgent.match(/Edge\/(\d+)/);
	  if (!match || match[1] >= 74) {
	    match = engineUserAgent.match(/Chrome\/(\d+)/);
	    if (match) version = match[1];
	  }
	}

	var engineV8Version = version && +version;

	var task$1 = task.set;










	var SPECIES$2 = wellKnownSymbol('species');
	var PROMISE = 'Promise';
	var getInternalState = internalState.get;
	var setInternalState = internalState.set;
	var getInternalPromiseState = internalState.getterFor(PROMISE);
	var PromiseConstructor = nativePromiseConstructor;
	var TypeError$1 = global_1.TypeError;
	var document$2 = global_1.document;
	var process$3 = global_1.process;
	var $fetch = getBuiltIn('fetch');
	var newPromiseCapability$1 = newPromiseCapability.f;
	var newGenericPromiseCapability = newPromiseCapability$1;
	var IS_NODE$1 = classofRaw(process$3) == 'process';
	var DISPATCH_EVENT = !!(document$2 && document$2.createEvent && global_1.dispatchEvent);
	var UNHANDLED_REJECTION = 'unhandledrejection';
	var REJECTION_HANDLED = 'rejectionhandled';
	var PENDING = 0;
	var FULFILLED = 1;
	var REJECTED = 2;
	var HANDLED = 1;
	var UNHANDLED = 2;
	var Internal, OwnPromiseCapability, PromiseWrapper, nativeThen;

	var FORCED = isForced_1(PROMISE, function () {
	  var GLOBAL_CORE_JS_PROMISE = inspectSource(PromiseConstructor) !== String(PromiseConstructor);
	  if (!GLOBAL_CORE_JS_PROMISE) {
	    // V8 6.6 (Node 10 and Chrome 66) have a bug with resolving custom thenables
	    // https://bugs.chromium.org/p/chromium/issues/detail?id=830565
	    // We can't detect it synchronously, so just check versions
	    if (engineV8Version === 66) return true;
	    // Unhandled rejections tracking support, NodeJS Promise without it fails @@species test
	    if (!IS_NODE$1 && typeof PromiseRejectionEvent != 'function') return true;
	  }
	  // We can't use @@species feature detection in V8 since it causes
	  // deoptimization and performance degradation
	  // https://github.com/zloirock/core-js/issues/679
	  if (engineV8Version >= 51 && /native code/.test(PromiseConstructor)) return false;
	  // Detect correctness of subclassing with @@species support
	  var promise = PromiseConstructor.resolve(1);
	  var FakePromise = function (exec) {
	    exec(function () { /* empty */ }, function () { /* empty */ });
	  };
	  var constructor = promise.constructor = {};
	  constructor[SPECIES$2] = FakePromise;
	  return !(promise.then(function () { /* empty */ }) instanceof FakePromise);
	});

	var INCORRECT_ITERATION = FORCED || !checkCorrectnessOfIteration(function (iterable) {
	  PromiseConstructor.all(iterable)['catch'](function () { /* empty */ });
	});

	// helpers
	var isThenable = function (it) {
	  var then;
	  return isObject(it) && typeof (then = it.then) == 'function' ? then : false;
	};

	var notify$1 = function (promise, state, isReject) {
	  if (state.notified) return;
	  state.notified = true;
	  var chain = state.reactions;
	  microtask(function () {
	    var value = state.value;
	    var ok = state.state == FULFILLED;
	    var index = 0;
	    // variable length - can't use forEach
	    while (chain.length > index) {
	      var reaction = chain[index++];
	      var handler = ok ? reaction.ok : reaction.fail;
	      var resolve = reaction.resolve;
	      var reject = reaction.reject;
	      var domain = reaction.domain;
	      var result, then, exited;
	      try {
	        if (handler) {
	          if (!ok) {
	            if (state.rejection === UNHANDLED) onHandleUnhandled(promise, state);
	            state.rejection = HANDLED;
	          }
	          if (handler === true) result = value;
	          else {
	            if (domain) domain.enter();
	            result = handler(value); // can throw
	            if (domain) {
	              domain.exit();
	              exited = true;
	            }
	          }
	          if (result === reaction.promise) {
	            reject(TypeError$1('Promise-chain cycle'));
	          } else if (then = isThenable(result)) {
	            then.call(result, resolve, reject);
	          } else resolve(result);
	        } else reject(value);
	      } catch (error) {
	        if (domain && !exited) domain.exit();
	        reject(error);
	      }
	    }
	    state.reactions = [];
	    state.notified = false;
	    if (isReject && !state.rejection) onUnhandled(promise, state);
	  });
	};

	var dispatchEvent = function (name, promise, reason) {
	  var event, handler;
	  if (DISPATCH_EVENT) {
	    event = document$2.createEvent('Event');
	    event.promise = promise;
	    event.reason = reason;
	    event.initEvent(name, false, true);
	    global_1.dispatchEvent(event);
	  } else event = { promise: promise, reason: reason };
	  if (handler = global_1['on' + name]) handler(event);
	  else if (name === UNHANDLED_REJECTION) hostReportErrors('Unhandled promise rejection', reason);
	};

	var onUnhandled = function (promise, state) {
	  task$1.call(global_1, function () {
	    var value = state.value;
	    var IS_UNHANDLED = isUnhandled(state);
	    var result;
	    if (IS_UNHANDLED) {
	      result = perform(function () {
	        if (IS_NODE$1) {
	          process$3.emit('unhandledRejection', value, promise);
	        } else dispatchEvent(UNHANDLED_REJECTION, promise, value);
	      });
	      // Browsers should not trigger `rejectionHandled` event if it was handled here, NodeJS - should
	      state.rejection = IS_NODE$1 || isUnhandled(state) ? UNHANDLED : HANDLED;
	      if (result.error) throw result.value;
	    }
	  });
	};

	var isUnhandled = function (state) {
	  return state.rejection !== HANDLED && !state.parent;
	};

	var onHandleUnhandled = function (promise, state) {
	  task$1.call(global_1, function () {
	    if (IS_NODE$1) {
	      process$3.emit('rejectionHandled', promise);
	    } else dispatchEvent(REJECTION_HANDLED, promise, state.value);
	  });
	};

	var bind = function (fn, promise, state, unwrap) {
	  return function (value) {
	    fn(promise, state, value, unwrap);
	  };
	};

	var internalReject = function (promise, state, value, unwrap) {
	  if (state.done) return;
	  state.done = true;
	  if (unwrap) state = unwrap;
	  state.value = value;
	  state.state = REJECTED;
	  notify$1(promise, state, true);
	};

	var internalResolve = function (promise, state, value, unwrap) {
	  if (state.done) return;
	  state.done = true;
	  if (unwrap) state = unwrap;
	  try {
	    if (promise === value) throw TypeError$1("Promise can't be resolved itself");
	    var then = isThenable(value);
	    if (then) {
	      microtask(function () {
	        var wrapper = { done: false };
	        try {
	          then.call(value,
	            bind(internalResolve, promise, wrapper, state),
	            bind(internalReject, promise, wrapper, state)
	          );
	        } catch (error) {
	          internalReject(promise, wrapper, error, state);
	        }
	      });
	    } else {
	      state.value = value;
	      state.state = FULFILLED;
	      notify$1(promise, state, false);
	    }
	  } catch (error) {
	    internalReject(promise, { done: false }, error, state);
	  }
	};

	// constructor polyfill
	if (FORCED) {
	  // 25.4.3.1 Promise(executor)
	  PromiseConstructor = function Promise(executor) {
	    anInstance(this, PromiseConstructor, PROMISE);
	    aFunction$1(executor);
	    Internal.call(this);
	    var state = getInternalState(this);
	    try {
	      executor(bind(internalResolve, this, state), bind(internalReject, this, state));
	    } catch (error) {
	      internalReject(this, state, error);
	    }
	  };
	  // eslint-disable-next-line no-unused-vars
	  Internal = function Promise(executor) {
	    setInternalState(this, {
	      type: PROMISE,
	      done: false,
	      notified: false,
	      parent: false,
	      reactions: [],
	      rejection: false,
	      state: PENDING,
	      value: undefined
	    });
	  };
	  Internal.prototype = redefineAll(PromiseConstructor.prototype, {
	    // `Promise.prototype.then` method
	    // https://tc39.github.io/ecma262/#sec-promise.prototype.then
	    then: function then(onFulfilled, onRejected) {
	      var state = getInternalPromiseState(this);
	      var reaction = newPromiseCapability$1(speciesConstructor(this, PromiseConstructor));
	      reaction.ok = typeof onFulfilled == 'function' ? onFulfilled : true;
	      reaction.fail = typeof onRejected == 'function' && onRejected;
	      reaction.domain = IS_NODE$1 ? process$3.domain : undefined;
	      state.parent = true;
	      state.reactions.push(reaction);
	      if (state.state != PENDING) notify$1(this, state, false);
	      return reaction.promise;
	    },
	    // `Promise.prototype.catch` method
	    // https://tc39.github.io/ecma262/#sec-promise.prototype.catch
	    'catch': function (onRejected) {
	      return this.then(undefined, onRejected);
	    }
	  });
	  OwnPromiseCapability = function () {
	    var promise = new Internal();
	    var state = getInternalState(promise);
	    this.promise = promise;
	    this.resolve = bind(internalResolve, promise, state);
	    this.reject = bind(internalReject, promise, state);
	  };
	  newPromiseCapability.f = newPromiseCapability$1 = function (C) {
	    return C === PromiseConstructor || C === PromiseWrapper
	      ? new OwnPromiseCapability(C)
	      : newGenericPromiseCapability(C);
	  };

	  if ( typeof nativePromiseConstructor == 'function') {
	    nativeThen = nativePromiseConstructor.prototype.then;

	    // wrap native Promise#then for native async functions
	    redefine(nativePromiseConstructor.prototype, 'then', function then(onFulfilled, onRejected) {
	      var that = this;
	      return new PromiseConstructor(function (resolve, reject) {
	        nativeThen.call(that, resolve, reject);
	      }).then(onFulfilled, onRejected);
	    // https://github.com/zloirock/core-js/issues/640
	    }, { unsafe: true });

	    // wrap fetch result
	    if (typeof $fetch == 'function') _export({ global: true, enumerable: true, forced: true }, {
	      // eslint-disable-next-line no-unused-vars
	      fetch: function fetch(input /* , init */) {
	        return promiseResolve(PromiseConstructor, $fetch.apply(global_1, arguments));
	      }
	    });
	  }
	}

	_export({ global: true, wrap: true, forced: FORCED }, {
	  Promise: PromiseConstructor
	});

	setToStringTag(PromiseConstructor, PROMISE, false);
	setSpecies(PROMISE);

	PromiseWrapper = getBuiltIn(PROMISE);

	// statics
	_export({ target: PROMISE, stat: true, forced: FORCED }, {
	  // `Promise.reject` method
	  // https://tc39.github.io/ecma262/#sec-promise.reject
	  reject: function reject(r) {
	    var capability = newPromiseCapability$1(this);
	    capability.reject.call(undefined, r);
	    return capability.promise;
	  }
	});

	_export({ target: PROMISE, stat: true, forced:  FORCED }, {
	  // `Promise.resolve` method
	  // https://tc39.github.io/ecma262/#sec-promise.resolve
	  resolve: function resolve(x) {
	    return promiseResolve( this, x);
	  }
	});

	_export({ target: PROMISE, stat: true, forced: INCORRECT_ITERATION }, {
	  // `Promise.all` method
	  // https://tc39.github.io/ecma262/#sec-promise.all
	  all: function all(iterable) {
	    var C = this;
	    var capability = newPromiseCapability$1(C);
	    var resolve = capability.resolve;
	    var reject = capability.reject;
	    var result = perform(function () {
	      var $promiseResolve = aFunction$1(C.resolve);
	      var values = [];
	      var counter = 0;
	      var remaining = 1;
	      iterate_1(iterable, function (promise) {
	        var index = counter++;
	        var alreadyCalled = false;
	        values.push(undefined);
	        remaining++;
	        $promiseResolve.call(C, promise).then(function (value) {
	          if (alreadyCalled) return;
	          alreadyCalled = true;
	          values[index] = value;
	          --remaining || resolve(values);
	        }, reject);
	      });
	      --remaining || resolve(values);
	    });
	    if (result.error) reject(result.value);
	    return capability.promise;
	  },
	  // `Promise.race` method
	  // https://tc39.github.io/ecma262/#sec-promise.race
	  race: function race(iterable) {
	    var C = this;
	    var capability = newPromiseCapability$1(C);
	    var reject = capability.reject;
	    var result = perform(function () {
	      var $promiseResolve = aFunction$1(C.resolve);
	      iterate_1(iterable, function (promise) {
	        $promiseResolve.call(C, promise).then(capability.resolve, reject);
	      });
	    });
	    if (result.error) reject(result.value);
	    return capability.promise;
	  }
	});

	// Safari bug https://bugs.webkit.org/show_bug.cgi?id=200829
	var NON_GENERIC = !!nativePromiseConstructor && fails(function () {
	  nativePromiseConstructor.prototype['finally'].call({ then: function () { /* empty */ } }, function () { /* empty */ });
	});

	// `Promise.prototype.finally` method
	// https://tc39.github.io/ecma262/#sec-promise.prototype.finally
	_export({ target: 'Promise', proto: true, real: true, forced: NON_GENERIC }, {
	  'finally': function (onFinally) {
	    var C = speciesConstructor(this, getBuiltIn('Promise'));
	    var isFunction = typeof onFinally == 'function';
	    return this.then(
	      isFunction ? function (x) {
	        return promiseResolve(C, onFinally()).then(function () { return x; });
	      } : onFinally,
	      isFunction ? function (e) {
	        return promiseResolve(C, onFinally()).then(function () { throw e; });
	      } : onFinally
	    );
	  }
	});

	// patch native Promise.prototype for native async functions
	if ( typeof nativePromiseConstructor == 'function' && !nativePromiseConstructor.prototype['finally']) {
	  redefine(nativePromiseConstructor.prototype, 'finally', getBuiltIn('Promise').prototype['finally']);
	}

	var call = Function.call;

	var entryUnbind = function (CONSTRUCTOR, METHOD, length) {
	  return functionBindContext(call, global_1[CONSTRUCTOR].prototype[METHOD], length);
	};

	var _finally = entryUnbind('Promise', 'finally');

	var es2018Promise = createCommonjsModule(function (module, exports) {
	Object.defineProperty(exports, "__esModule", { value: true });
	});

	unwrapExports(es2018Promise);

	var AdobeIdKey = 'adobeid';
	var AdobeIMSKey = 'adobeIMS';
	var AdobeImsFactory = 'adobeImsFactory';
	var DEFAULT_LANGUAGE = 'en_US';
	var STORAGE_MODE;
	(function (STORAGE_MODE) {
	    STORAGE_MODE["LocalStorage"] = "local";
	    STORAGE_MODE["SessionStorage"] = "session";
	    STORAGE_MODE["MemoryStorage"] = "memory";
	})(STORAGE_MODE || (STORAGE_MODE = {}));

	/*! *****************************************************************************
	Copyright (c) Microsoft Corporation. All rights reserved.
	Licensed under the Apache License, Version 2.0 (the "License"); you may not use
	this file except in compliance with the License. You may obtain a copy of the
	License at http://www.apache.org/licenses/LICENSE-2.0

	THIS CODE IS PROVIDED ON AN *AS IS* BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
	KIND, EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT LIMITATION ANY IMPLIED
	WARRANTIES OR CONDITIONS OF TITLE, FITNESS FOR A PARTICULAR PURPOSE,
	MERCHANTABLITY OR NON-INFRINGEMENT.

	See the Apache Version 2.0 License for specific language governing permissions
	and limitations under the License.
	***************************************************************************** */
	/* global Reflect, Promise */

	var extendStatics = function(d, b) {
	    extendStatics = Object.setPrototypeOf ||
	        ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
	        function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
	    return extendStatics(d, b);
	};

	function __extends(d, b) {
	    extendStatics(d, b);
	    function __() { this.constructor = d; }
	    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
	}

	var __assign = function() {
	    __assign = Object.assign || function __assign(t) {
	        for (var s, i = 1, n = arguments.length; i < n; i++) {
	            s = arguments[i];
	            for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
	        }
	        return t;
	    };
	    return __assign.apply(this, arguments);
	};

	function __read(o, n) {
	    var m = typeof Symbol === "function" && o[Symbol.iterator];
	    if (!m) return o;
	    var i = m.call(o), r, ar = [], e;
	    try {
	        while ((n === void 0 || n-- > 0) && !(r = i.next()).done) ar.push(r.value);
	    }
	    catch (error) { e = { error: error }; }
	    finally {
	        try {
	            if (r && !r.done && (m = i["return"])) m.call(i);
	        }
	        finally { if (e) throw e.error; }
	    }
	    return ar;
	}

	function __spread() {
	    for (var ar = [], i = 0; i < arguments.length; i++)
	        ar = ar.concat(__read(arguments[i]));
	    return ar;
	}

	/**
	 * class used to implement the main functions used for query strings
	 */
	var UrlHelper = /** @class */ (function () {
	    function UrlHelper() {
	    }
	    /**
	   * Encodes data as a query string.
	   * @param {Object} data - The data.
	   * @returns {string} - The encoded string.
	    * @example
	    * encoded = uriEncodeData({
	    *   first: true,
	    *   foo: {
	    *     bar: 'foobar'
	    *   }
	    * }) // -> first=true&foo=%7B%22bar%22%3A%22foobar%22%7D
	    */
	    UrlHelper.prototype.uriEncodeData = function (data) {
	        if (typeof data !== 'object') {
	            return '';
	        }
	        var encodings = [];
	        var encodedValue = '';
	        var keyValue;
	        for (var key in data) {
	            keyValue = data[key];
	            if (keyValue === undefined) {
	                continue;
	            }
	            encodedValue = this.encodeValue(keyValue);
	            encodings.push(encodeURIComponent(key) + "=" + encodedValue);
	        }
	        return encodings.join("&");
	    };
	    /**
	   * @param value : any; represents the value which will be encoded
	   * @returns string.
	   */
	    UrlHelper.prototype.encodeValue = function (value) {
	        if (value === null) {
	            return 'null';
	        }
	        if (typeof value === 'object') {
	            return encodeURIComponent(JSON.stringify(value));
	        }
	        return encodeURIComponent(value);
	    };
	    /**
	   * Opens the URL in the current page
	   *
	   * @param {!string} url
	   */
	    UrlHelper.prototype.replaceUrl = function (url) {
	        if (!url) {
	            return;
	        }
	        window.location.replace(url);
	    };
	    /**
	   * Opens the URL in the current page
	   * @param {!string} url
	   */
	    UrlHelper.prototype.setHrefUrl = function (url) {
	        if (!url) {
	            return;
	        }
	        window.location.href = url;
	    };
	    /**
	  * Change the hash from url to a new value without reloading the page
	  * @param hash {String} represents the new hash value
	  *
	  */
	    UrlHelper.prototype.setHash = function (hash) {
	        if (hash === void 0) { hash = ''; }
	        window.location.hash = hash;
	    };
	    return UrlHelper;
	}());
	var UrlHelper$1 = new UrlHelper();

	/**
	 * Enumeration values for available environments
	 */
	var IEnvironment;
	(function (IEnvironment) {
	    /**
	     * Stage environment
	     */
	    IEnvironment["STAGE"] = "stg1";
	    /**
	     * Prod environment
	     */
	    IEnvironment["PROD"] = "prod";
	})(IEnvironment || (IEnvironment = {}));

	/**
	 * class used to store the variables used for ims flow
	 */
	var Environment = /** @class */ (function () {
	    function Environment() {
	        /**
	       * @property {String} Represents the base url used on api (back-end) call in case of getProfile, getUserInfo and validateToken;
	       */
	        this.baseUrlAdobe = '';
	        /**
	       * @property {string} Represents the base url used on api (back-end) call in case of logoutToken, checkStatus checkToken,listSocialProviders and exchangeIjt;
	       */
	        this.baseUrlServices = '';
	        /**
	       * @property {string} this parameter is passed to redirect uri during a sign in or sign out operation
	       */
	        this.jslibver = 'v2-v0.17.0-35-gdd2e891';
	    }
	    Environment.prototype.loadEnvironment = function (environment) {
	        if (environment === IEnvironment.STAGE) {
	            this.baseUrlAdobe = 'https://ims-na1-stg1.adobelogin.com';
	            this.baseUrlServices = 'https://adobeid-na1-stg1.services.adobe.com';
	            return;
	        }
	        this.baseUrlAdobe = 'https://ims-na1.adobelogin.com';
	        this.baseUrlServices = 'https://adobeid-na1.services.adobe.com';
	    };
	    return Environment;
	}());
	var Environment$1 = new Environment();

	/**
	 * class used to store the helper functions
	 */
	var ApiHelpers = /** @class */ (function () {
	    function ApiHelpers() {
	        /**
	       * Checks [adobeid.api_parameters]{@link adobeid} for custom parameters for an API.
	       * @param apiName - represents the used api name
	       * @param apiParameters - represents the parameters set from outside for api endpoints read from adobeId
	       * @returns {!Object}
	       */
	        this.getCustomApiParameters = function (apiParameters, apiName) {
	            return Object.keys(apiParameters).reduce(function (acumulator, key) {
	                if (key.indexOf(apiName) > -1) {
	                    acumulator[key] = apiParameters[key] || null;
	                }
	                return acumulator;
	            }, {});
	        };
	    }
	    /**
	     *
	     * @param externalParameters external parameters received outside of the library
	     * @param apiParameters the api parameters from AdobeId data
	     * @param apiName api name
	     * @returns IDictionary representing the merged properties
	     */
	    ApiHelpers.prototype.mergeExternalParameters = function (externalParameters, apiParameters, apiName) {
	        return __assign(__assign({}, this.getCustomApiParameters(apiParameters, apiName)), externalParameters);
	    };
	    /***
	     * @param value {String} represents the
	     */
	    ApiHelpers.prototype.toJson = function (value) {
	        try {
	            if (typeof value !== 'string') {
	                return value;
	            }
	            return JSON.parse(value);
	        }
	        catch (_a) {
	            return null;
	        }
	    };
	    return ApiHelpers;
	}());
	var ApiHelpers$1 = new ApiHelpers();

	var RedirectHelper = /** @class */ (function () {
	    function RedirectHelper() {
	    }
	    /**
	    * returns the initial redirect url; the priority value is redirect_uri from external parameters, adobeId and finally the href value from browsers
	    * @param externalParameters
	    * @param adobeIdRedirectUri
	    */
	    RedirectHelper.getInitialRedirectUri = function (externalParameters, adobeIdRedirectUri) {
	        var redirectValue = externalParameters["redirect_uri"] || (adobeIdRedirectUri || window.location.href);
	        var fromImsIndex = redirectValue.indexOf('from_ims');
	        if (fromImsIndex === -1) {
	            return redirectValue;
	        }
	        if (redirectValue[fromImsIndex - 1] === '#') {
	            fromImsIndex--;
	        }
	        return redirectValue.substr(0, fromImsIndex);
	    };
	    /**
	    * create the return url which it will be passed to authorize or logout endpoint
	    * @param adobeIdRedirectUri {string} - represents the redirect_uri? set on AdobeId;
	    * @param clientId {string} - represents the client id from AdobeId
	    * @param externalParameters {Object} external parameters passed to library
	    * @param apiName {string} api name
	    *
	    * @returns {string} final redirect url used for sign-in or reauth (authorize) or logout
	    */
	    RedirectHelper.createDefaultRedirectUrl = function (adobeIdRedirectUri, clientId, externalParameters, apiName) {
	        var initialRedirectUri = this.getInitialRedirectUri(externalParameters, adobeIdRedirectUri);
	        //encode the hash in case that exists
	        var redirectUri = this.createOldHash(initialRedirectUri);
	        return redirectUri.indexOf('?') > 0 ?
	            redirectUri + "&client_id=" + clientId + "&api=" + apiName :
	            redirectUri + "?client_id=" + clientId + "&api=" + apiName;
	    };
	    /**
	     * <uml>
	     * start
	     * :CreateDefaultRedirectUrl ;
	     * :merge api parameters with external parameters
	     * :encode the merged parameters and call the /ims/authorize/v1/${encodedParameters} url
	     * end
	     * </uml>
	     *
	     * create the return url which it will be passed to authorization endpoint
	     * @param redirectUri {string} - represents the base url href value
	     * @param clientId {string} - represents the client id
	     * @param externalParameters {Object} external parameters passed to library
	     * @param apiName {string} api name
	     * @parm scope {string} scope of sign in
	     * @returns {string} final redirect url used for sign in
	     */
	    RedirectHelper.createRedirectUrl = function (adobeIdRedirectUri, clientId, externalParameters, apiName, scope) {
	        if (scope === void 0) { scope = ''; }
	        var redirectUri = this.createDefaultRedirectUrl(adobeIdRedirectUri, clientId, externalParameters, apiName);
	        scope = scope || externalParameters["scope"] || '';
	        if (scope) {
	            redirectUri = redirectUri + "&scope=" + encodeURIComponent(scope);
	        }
	        var reauth = externalParameters["reauth"] || '';
	        if (reauth) {
	            redirectUri = redirectUri + "&reauth=" + encodeURIComponent(reauth);
	        }
	        return redirectUri;
	    };
	    /**
	     * @param source {string} represent the url value with hash which will be encoded
	     * @returns {string} the same url but the hash is encoded
	     */
	    RedirectHelper.createOldHash = function (source) {
	        var index = source.indexOf("#");
	        if (index < 0) {
	            return source + "#old_hash=&from_ims=true";
	        }
	        var baseUrl = source.substring(0, index);
	        var hash = source.substring(index + 1);
	        return baseUrl + "#old_hash=" + encodeURIComponent(hash) + "&from_ims=true";
	    };
	    RedirectHelper.mergeApiParamsWithExternalParams = function (apiParameters, externalParameters, apiName) {
	        return __assign(__assign({}, ApiHelpers$1.getCustomApiParameters(apiParameters, apiName)), externalParameters);
	    };
	    return RedirectHelper;
	}());

	/**
	 * command responsable for user sign in
	 */
	var BaseSignInService = /** @class */ (function () {
	    function BaseSignInService() {
	        var _this = this;
	        /**
	         * execute the sign in method which redirects the user to the login page
	         * <uml>
	         * start
	         * :CreateRedirectUrl;
	         * :merge api parameters with external parameters
	         * :encode the merged parameters and call the /ims/authorize/v1/${encodedParameters} url
	         * end
	         * </uml>
	         *
	         * @param {IRedirectRequest} redirectRequest. contains all the adobeId necessary properties necessary for sign in
	         */
	        this.composeRedirectUrl = function (redirectRequest) {
	            var apiName = "authorize";
	            var apiParameters = redirectRequest.apiParameters, _a = redirectRequest.externalParameters, externalParameters = _a === void 0 ? {} : _a, _b = redirectRequest.adobeIdRedirectUri, adobeIdRedirectUri = _b === void 0 ? "" : _b, clientId = redirectRequest.clientId, localeAdobeId = redirectRequest.locale, _c = redirectRequest.state, state = _c === void 0 ? {} : _c;
	            var _d = redirectRequest.scope, scope = _d === void 0 ? externalParameters["scope"] || apiParameters["scope"] || "" : _d;
	            var apiExternalParams = RedirectHelper.mergeApiParamsWithExternalParams(apiParameters, externalParameters, apiName);
	            var redirectUrl = RedirectHelper.createRedirectUrl(adobeIdRedirectUri, clientId, apiExternalParams, apiName, scope);
	            var locale = externalParameters.locale || localeAdobeId || '';
	            var 
	            // eslint-disable-next-line @typescript-eslint/camelcase
	            _e = redirectRequest.response_type, 
	            // eslint-disable-next-line @typescript-eslint/camelcase
	            response_type = _e === void 0 ? apiExternalParams["response_type"] || '' : _e;
	            var parameters = __assign(__assign({}, apiExternalParams), { client_id: clientId, scope: scope,
	                locale: locale,
	                response_type: response_type, jslVersion: Environment$1.jslibver, redirect_uri: redirectUrl });
	            if (state) {
	                parameters["state"] = state;
	            }
	            return parameters;
	        };
	        /**
	         * execute the sign in method which redirects the user to the login page
	         * <uml>
	         * start
	         * :CreateRedirectUrl;
	         * :merge api parameters with external parameters
	         * :encode the merged parameters and call the /ims/authorize/v1/${encodedParameters} url
	         * end
	         * </uml>
	         *
	         * @param {IRedirectRequest} redirectRequest. contains all the adobeId necessary properties necessary for sign in
	         */
	        this.createRedirectUrl = function (redirectRequest) {
	            var parameters = _this.composeRedirectUrl(redirectRequest);
	            var queryStrings = UrlHelper$1.uriEncodeData(parameters);
	            var url = Environment$1.baseUrlAdobe + "/ims/authorize/v1?" + queryStrings;
	            return url;
	        };
	    }
	    return BaseSignInService;
	}());

	/**
	 * command responsable for user sign in
	 */
	var SignInService = /** @class */ (function (_super) {
	    __extends(SignInService, _super);
	    function SignInService() {
	        var _this = _super !== null && _super.apply(this, arguments) || this;
	        /**
	         * execute the sign in method which redirects the user to the login page
	         * <uml>
	         * start
	         * :CreateRedirectUrl;
	         * :merge api parameters with external parameters
	         * :encode the merged parameters and call the /ims/authorize/v1/${encodedParameters} url
	         * end
	         * </uml>
	         *
	         * @param {IRedirectRequest} redirectRequest. contains all the adobeId necessary properties necessary for sign in
	         */
	        _this.signIn = function (redirectRequest) {
	            var url = _this.createRedirectUrl(redirectRequest);
	            UrlHelper$1.setHrefUrl(url);
	        };
	        /**
	         *
	         * @param token { String } value used to authorize a user based on this token value
	         * @param redirectRequest { IRedirectRequest } contains the object properties which are passed to the authorize api
	         */
	        _this.authorizeToken = function (token, redirectRequest) {
	            var parameters = _this.composeRedirectUrl(redirectRequest);
	            if (token) {
	                parameters.user_assertion = token;
	                parameters.user_assertion_type = 'urn:ietf:params:oauth:client-assertion-type:jwt-bearer';
	            }
	            var postForm = _this.createAuthorizeForm(parameters);
	            postForm.submit();
	        };
	        return _this;
	    }
	    /**
	     * returns a html form containing all the properties from the parameter object
	     * @param parameters {object} contains the properties which will be passed to authorize api (as form submit post action)
	     */
	    SignInService.prototype.createAuthorizeForm = function (parameters) {
	        var formAction = Environment$1.baseUrlAdobe + "/ims/authorize/v1";
	        var form = document.createElement("form");
	        form.setAttribute("method", "post");
	        form.setAttribute("action", formAction);
	        var formEl = null;
	        var paramValue = null;
	        var paramValueAsString = '';
	        for (var propertyName in parameters) {
	            paramValue = parameters[propertyName];
	            if (typeof paramValue === 'object') {
	                if (Object.keys(paramValue).length === 0) {
	                    continue;
	                }
	                paramValueAsString = JSON.stringify(paramValue);
	            }
	            else {
	                paramValueAsString = paramValue;
	            }
	            if (paramValueAsString !== '') {
	                formEl = this.createFormElement('input', 'text', propertyName, paramValueAsString);
	                form.appendChild(formEl);
	            }
	        }
	        document.getElementsByTagName("body")[0]
	            .appendChild(form);
	        return form;
	    };
	    /**
	     * create a new html form element; this element will be added to the form
	     * @param inputType {String} input html element type
	     * @param type {String} type of the input element
	     * @param name {String} name of the input element
	     * @param value {String} value for the element
	     */
	    SignInService.prototype.createFormElement = function (inputType, type, name, value) {
	        var formElement = document.createElement(inputType);
	        formElement.setAttribute("type", type);
	        formElement.setAttribute("name", name);
	        formElement.setAttribute("value", value);
	        return formElement;
	    };
	    return SignInService;
	}(BaseSignInService));

	/**
	 * command responsable for user sign out
	 */
	var SignOutService = /** @class */ (function () {
	    function SignOutService() {
	        /**
	         * @param {IRedirectRequest} redirectRequest. contains all the necessary properties necessary for sign out
	         */
	        this.signOut = function (redirectRequest) {
	            var apiName = 'logout';
	            // eslint-disable-next-line @typescript-eslint/camelcase
	            var apiParameters = redirectRequest.apiParameters, externalParameters = redirectRequest.externalParameters, _a = redirectRequest.adobeIdRedirectUri, adobeIdRedirectUri = _a === void 0 ? '' : _a, clientId = redirectRequest.clientId;
	            var apiExternalParams = RedirectHelper.mergeApiParamsWithExternalParams(apiParameters, externalParameters, apiName);
	            var redirectUrl = RedirectHelper.createDefaultRedirectUrl(adobeIdRedirectUri, clientId, apiExternalParams, apiName);
	            var parameters = __assign(__assign({}, apiExternalParams), { client_id: clientId, redirect_uri: redirectUrl, jslVersion: Environment$1.jslibver });
	            var queryStrings = UrlHelper$1.uriEncodeData(parameters);
	            var url = Environment$1.baseUrlAdobe + "/ims/logout/v1?" + queryStrings;
	            UrlHelper$1.replaceUrl(url);
	        };
	    }
	    return SignOutService;
	}());

	/**
	 * class used to store the analytics parameters
	 */
	var AnalyticsParameters = /** @class */ (function () {
	    function AnalyticsParameters() {
	        /**
	        * represents the application code value;
	        * this value (if exists) will be sent to the server.
	        */
	        this.appCode = '';
	        /**
	         * represents the application version value;
	         * this value (if exists) will be sent to the server.
	         */
	        this.appVersion = '';
	    }
	    return AnalyticsParameters;
	}());

	/**
	 * Wrapper for <code>console</code>. Checks <code>console</code> is available and <code>debug</code> Mode is enabled.
	 *
	 * @exports log
	 *
	 */
	var Log = /** @class */ (function () {
	    function Log() {
	        var _this = this;
	        this.logEnabled = false;
	        /**
	         * Wrapper function.
	         *
	         * @param {String} method - Which <code>console</code> method to use.
	         * @param {*} args - Arguments object
	         *
	         * @private
	         */
	        this.print = function (method, args) {
	            if (!_this.logEnabled) {
	                return;
	            }
	            method.apply(void 0, __spread(args));
	        };
	        /**
	         * Writes an error to the console when the evaluated expression is false.
	         *
	         * @example
	         * log.assert(1 == 2, "Counting is hard.");
	         *
	         * @param {Boolean} expression - Expression to evaluate.
	         * @param {String} message - Message to print if <code>epxression</code> is <code>false</code>.
	         *
	         * @static
	         */
	        this.assert = function (val, message) {
	            _this.print(console.assert, [val, message]);
	        };
	        /**
	         * Writes an error to the console when the evaluated expression is false.
	         *
	         * @example
	         * log.assert(1 == 2, "Counting is hard.");
	         *
	         * @param {Boolean} expression - Expression to evaluate.
	         * @param {String} message - Message to print if <code>epxression</code> is <code>false</code>.
	         *
	         * @static
	         */
	        this.assertCondition = function (condition, message) {
	            if (!condition()) {
	                _this.print(console.error, [message]);
	            }
	        };
	        /**
	         * Prints a message similar to <code>console.log()</code>, styles the message like an error, and includes a stack
	         * trace from where the method wasval, called.
	         *
	         * @see {@link https://developers.google.com/web/tools/chrome-devtools/console/#filtering_the_console_output | Filtering the Console output}
	         *
	         * @example
	         * log.error("Define window.adobeid", "would you?!");
	         * @param {String} message - Message to print.
	         */
	        this.error = function () {
	            var args = [];
	            for (var _i = 0; _i < arguments.length; _i++) {
	                args[_i] = arguments[_i];
	            }
	            _this.print(console.error, args);
	        };
	        /**
	         * logs a warnig message
	         */
	        this.warn = function () {
	            var args = [];
	            for (var _i = 0; _i < arguments.length; _i++) {
	                args[_i] = arguments[_i];
	            }
	            _this.print(console.warn, args);
	        };
	        /**
	         * Prints a message like <code>console.log()</code> but also shows an icon (blue circle with white "i") next to the
	         * output.
	         *
	         * <code>console.info()</code> can be filtered in the Console, whereas <code>console.log()</code> can not.
	         *
	         * @example
	         * log.info("Imslib.js Ready", "to Rumble");
	         *
	         * @param {String} message - Message to print.
	         *
	         * @static
	         */
	        this.info = function () {
	            var args = [];
	            for (var _i = 0; _i < arguments.length; _i++) {
	                args[_i] = arguments[_i];
	            }
	            _this.print(console.info, args);
	        };
	    }
	    Log.prototype.enableLogging = function () {
	        this.logEnabled = true;
	    };
	    Log.prototype.disableLogging = function () {
	        this.logEnabled = false;
	    };
	    return Log;
	}());
	var Log$1 = new Log();

	/**
	 * Enumeration values used for reAuthenticate method
	 *
	 * Default value is check
	 */
	var IReauth;
	(function (IReauth) {
	    /**
	     * Forces the reauth process to show the credentials screen to the user
	     */
	    IReauth["force"] = "force";
	    /**
	     * Starts the reauthentication check flow. Which won't prompt the user for reauthentication if the user already performed an authentication in a period of time configured on the client id.
	     */
	    IReauth["check"] = "check";
	})(IReauth || (IReauth = {}));

	/**
	 * Enumeration values used for available grant types
	 *
	 * Default value is token
	 */
	var IGrantTypes;
	(function (IGrantTypes) {
	    /**
	     * token
	     */
	    IGrantTypes["token"] = "token";
	    /**
	     * authorization code
	     */
	    IGrantTypes["code"] = "code";
	})(IGrantTypes || (IGrantTypes = {}));

	/**
	 * In-Memory polyFill for localStorage and sessionStorage.
	 *
	 * @constructor
	 * @description Needed for Mac and iOS Safari (v <= 10) in Private Mode. Note that this object doesn't actually
	 * persist data across refresh, it just implements the [Storage]{@link external:Storage} interface.
	 * @exports memoryStorage
	 */
	var MemoryStorage = /** @class */ (function () {
	    function MemoryStorage() {
	        /**
	         * @type {!Object}
	         */
	        this.data = {};
	        /**
	         * property added in order to be compatible with Storage class
	         */
	        this.length = 0;
	    }
	    /**
	     * clear the memory data
	     */
	    MemoryStorage.prototype.clear = function () {
	        this.data = {};
	        this.length = 0;
	    };
	    /**
	     * @param key {String} represents the used key to get a value
	     * @returns {Object} the value associated with the input key
	     */
	    MemoryStorage.prototype.getItem = function (key) {
	        var value = this.data[key];
	        return value ? value : null;
	    };
	    /**
	     *
	     * @param key {string} represent the key which will be removed from memory
	     * @returns {boolean} true if the key is removed otherwise false
	     */
	    MemoryStorage.prototype.removeItem = function (key) {
	        if (!this.data[key]) {
	            return false;
	        }
	        delete this.data[key];
	        --this.length;
	        return true;
	    };
	    /**
	     * @key {String} - the used key to store a value into memory
	     * @value {any} - value associated with the input key
	     */
	    MemoryStorage.prototype.setItem = function (key, value) {
	        if (!this.data[key]) {
	            ++this.length;
	        }
	        this.data[key] = value;
	    };
	    MemoryStorage.prototype.key = function (index) {
	        throw new Error("Method not implemented. " + index);
	    };
	    return MemoryStorage;
	}());

	/**
	 * A cross-browser way to use `sessionStorage`
	 *
	 * @exports storage
	 * @requires MemoryStorage
	 */
	var StorageFactory = /** @class */ (function () {
	    function StorageFactory() {
	        this.memoryStorageInstance = null;
	    }
	    Object.defineProperty(StorageFactory.prototype, "memoryStorage", {
	        get: function () {
	            if (!this.memoryStorageInstance) {
	                this.memoryStorageInstance = new MemoryStorage();
	            }
	            return this.memoryStorageInstance;
	        },
	        enumerable: true,
	        configurable: true
	    });
	    /**
	    *
	    * @param storageName represents the storage name
	    * @returns the local or session storage; in case there is a problem with storage, the memory storage is returned
	    */
	    StorageFactory.prototype.getStorageByName = function (storageName) {
	        var storageInstance = this.getStorageInstanceByName(storageName);
	        if (!storageInstance) {
	            return this.memoryStorage;
	        }
	        return this.verifyStorage(storageInstance) ? storageInstance : this.memoryStorage;
	    };
	    /**
	     * method used to get the avilable storage and to give the possibility to mock the behaviour
	     * @param storageName the storage name used to get the storage
	     * @returns Storage or null
	     */
	    StorageFactory.prototype.getStorageInstanceByName = function (storageName) {
	        if (storageName === STORAGE_MODE.MemoryStorage) {
	            return this.memoryStorage;
	        }
	        try {
	            return storageName === STORAGE_MODE.LocalStorage ? window.localStorage : window.sessionStorage;
	        }
	        catch (ex) {
	            Log$1.warn('Please change your cookies settings in order to allow local data to be set');
	            return null;
	        }
	    };
	    /**
	     * returns the available storage; the priority is local storage and after that the session storage
	     * if no local or session storage is available, the Memory Storage is returned
	     */
	    StorageFactory.prototype.getAvailableStorage = function () {
	        var storage = this.getStorageByName(STORAGE_MODE.LocalStorage);
	        if (storage instanceof MemoryStorage) {
	            return this.getStorageByName(STORAGE_MODE.SessionStorage);
	        }
	        return storage;
	    };
	    /**
	     *
	     * @param storage represents the storage instance
	     * @returns true if storage is working as expected otherwise false
	     */
	    StorageFactory.prototype.verifyStorage = function (storage) {
	        var storageKey = 'test';
	        try {
	            storage.setItem(storageKey, 'true');
	            var storageValue = storage.getItem(storageKey);
	            if (storageValue !== 'true') {
	                return false;
	            }
	            storage.removeItem(storageKey);
	            return true;
	        }
	        catch (ex) {
	            return false;
	        }
	    };
	    return StorageFactory;
	}());
	var StorageFactory$1 = new StorageFactory();

	var ONE_HOUR = 60 * 60 * 3600;
	var CodeChallenge = /** @class */ (function () {
	    function CodeChallenge() {
	        this.storage = StorageFactory$1.getAvailableStorage();
	    }
	    CodeChallenge.prototype.b64Uri = function (r) {
	        return btoa(r).replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/, "");
	    };
	    /**
	     *
	     * @param nonce {String} represents the key used to store the code verifier
	     * @param verifierLength {number} represents the verifier length
	     * @returns {ICodeChallenge} verifier and challenge codes
	     */
	    CodeChallenge.prototype.createCodeChallenge = function (nonce, verifierLength) {
	        var _this = this;
	        if (verifierLength === void 0) { verifierLength = 43; }
	        var cryptoObj = window['msCrypto'] || window.crypto;
	        var verifier = this.b64Uri(Array.prototype.map.call(cryptoObj.getRandomValues(new Uint8Array(verifierLength)), function (r) {
	            return String.fromCharCode(r);
	        }).join("")).substring(0, verifierLength);
	        var uintVerifierArr = new Uint8Array(verifier.length);
	        for (var i = 0; i < verifier.length; i++)
	            uintVerifierArr[i] = verifier.charCodeAt(i);
	        var cryptoDigest = cryptoObj.subtle.digest('SHA-256', uintVerifierArr);
	        return new Promise(function (resolve, reject) {
	            if (window['CryptoOperation']) {
	                cryptoDigest.onerror = function (err) { return reject(err); };
	                cryptoDigest.oncomplete = function (response) {
	                    var uintArr = new Uint8Array(response.target.result);
	                    var challenge = _this.b64Uri(String.fromCharCode.apply(String, __spread(uintArr)));
	                    return resolve(_this.saveVerifierAndReturn(nonce, {
	                        verifier: verifier,
	                        challenge: challenge,
	                    }));
	                };
	            }
	            else {
	                cryptoDigest.then(function (response) {
	                    var uintArr = new Uint8Array(response);
	                    var challenge = _this.b64Uri(String.fromCharCode.apply(String, __spread(uintArr)));
	                    return resolve(_this.saveVerifierAndReturn(nonce, {
	                        verifier: verifier,
	                        challenge: challenge,
	                    }));
	                });
	            }
	        });
	    };
	    /**
	     *
	     * @param nonce {String} represents the key used to store the code verifier
	     * @param challengeAndVerifier {ICodeChallenge} represents the code challenge and code verifier
	     * @returns ICodeChallenge
	     */
	    CodeChallenge.prototype.saveVerifierAndReturn = function (nonce, challengeAndVerifier) {
	        var verifiers = this.getVerifierValuesFromStorage();
	        var storageValue = {
	            verifier: challengeAndVerifier.verifier || '',
	            expiry: new Date().getTime().toString()
	        };
	        verifiers[nonce] = storageValue;
	        this.storage.setItem('verifiers', JSON.stringify(verifiers));
	        return Promise.resolve(challengeAndVerifier);
	    };
	    /**
	   * Returns the nonce values from storage as an Object or null
	   * @returns {IDictionary | null}
	   */
	    CodeChallenge.prototype.getVerifierValuesFromStorage = function () {
	        var storageVerifiers = this.storage.getItem('verifiers');
	        var verifiers = storageVerifiers ? JSON.parse(storageVerifiers) : {};
	        return this.clearOlderVerifiers(verifiers);
	    };
	    CodeChallenge.prototype.clearOlderVerifiers = function (verifiers, olderThan) {
	        if (olderThan === void 0) { olderThan = ONE_HOUR; }
	        var oneHourAgo = Date.now() - olderThan;
	        var expiry = 0;
	        Object.keys(verifiers).forEach(function (key) {
	            expiry = parseInt(verifiers[key]);
	            if (expiry < oneHourAgo) {
	                delete verifiers[key];
	            }
	        });
	        return verifiers;
	    };
	    /**
	     * rerturns the verifier from storage
	     * @param key {String} represents the key used to stora the verfier
	     */
	    CodeChallenge.prototype.getVerifierByKey = function (key) {
	        var verifiers = this.getVerifierValuesFromStorage();
	        var verifierObj = verifiers ? verifiers[key] : {};
	        delete verifiers[key];
	        this.storage.setItem('verifiers', JSON.stringify(verifiers));
	        return verifierObj ? verifierObj['verifier'] : '';
	    };
	    return CodeChallenge;
	}());

	/**
	 *  Class used to store the adobe data values.
	 *
	 *  Ims library will use these values for all operations
	 */
	var AdobeIdThinData = /** @class */ (function () {
	    /**
	     * @constructor Create the adobeIdData object with all necessary properties from adobeData input paramater
	     *
	     * It uses the input adobeData parameter or the object stored in window.adobeid
	     */
	    function AdobeIdThinData(adobeData) {
	        if (adobeData === void 0) { adobeData = null; }
	        /**
	         * represents the class used to store the analytics parameters
	         */
	        this.analyticsParameters = new AnalyticsParameters();
	        /**
	          @property Object containing various custom parameters for IMS.
	          This object is used in case a custom API parameter is desired to be sent to the back-end.
	      
	          E.G. { logout: 'your_custom_value' }
	      
	          The list of api's which can be customized are: authorize, validate_token, profile, userinfo, logout, logout_token, check, providers, ijt
	        */
	        this.api_parameters = {};
	        /**
	          @property {string} Localization value used by ims library.
	          
	          Default value is `en_US`
	        */
	        this.locale = "";
	        /**
	         * @property {string} - The scopes used to acquire access tokens. A comma separated list of client scopes.
	         * No whitespace.
	         * Default scopes: AdobeID
	         */
	        this.scope = "AdobeID";
	        /**
	         * @property {string} - The client id used by ims library
	         */
	        this.client_id = "";
	        /**
	         * represents the used environment; default is prod and in case the value is stg1, the stage environment is used
	         */
	        this.environment = IEnvironment.PROD;
	        /**
	         *  use the local storage for token management; default value is false;
	         */
	        this.useLocalStorage = false;
	        /** @function {adobeid.onReady} [onReady] - Function to be executed once imslib.js has been fully
	         * initialized.
	         */
	        this.onReady = null;
	        var adobeid = adobeData ? adobeData : window[AdobeIdKey];
	        if (!adobeid) {
	            throw new Error("Please provide adobeId information");
	        }
	        var api_parameters = adobeid.api_parameters, client_id = adobeid.client_id, locale = adobeid.locale, scope = adobeid.scope, ijt = adobeid.ijt, _a = adobeid.environment, environment = _a === void 0 ? IEnvironment.PROD : _a, redirect_uri = adobeid.redirect_uri, useLocalStorage = adobeid.useLocalStorage, logsEnabled = adobeid.logsEnabled, onReady = adobeid.onReady;
	        this.environment = environment;
	        this.api_parameters = api_parameters ? api_parameters : {};
	        this.client_id = client_id;
	        this.locale = locale || DEFAULT_LANGUAGE;
	        this.scope = scope ? scope.replace(/\s/gi, '') : '';
	        this.redirect_uri = redirect_uri;
	        this.ijt = ijt;
	        this.useLocalStorage = useLocalStorage;
	        if (logsEnabled) {
	            Log$1.enableLogging();
	        }
	        else {
	            Log$1.disableLogging();
	        }
	        this.onReady = onReady ? onReady : null;
	        this.fillAnalityticsParameters(adobeid);
	        Environment$1.loadEnvironment(environment);
	    }
	    /**
	     * fill the analytic parameters with the values provided by adobeid data
	     * @param adobeid represents the adobeid data provided to library
	     */
	    AdobeIdThinData.prototype.fillAnalityticsParameters = function (adobeid) {
	        var _a = adobeid.analytics, _b = _a === void 0 ? {} : _a, _c = _b.appCode, appCode = _c === void 0 ? "" : _c, _d = _b.appVersion, appVersion = _d === void 0 ? "" : _d;
	        var analyticsParameters = this.analyticsParameters;
	        analyticsParameters.appCode = appCode;
	        analyticsParameters.appVersion = appVersion;
	    };
	    /**
	     * Function used by IMSLib to use only the neccesarry properties from AdobeIdData for social provider
	     * @param providerName provider name used for sign in
	     * @param requestedParameters {Object} the external parameters used for signin and reauth methods
	     * @param contextToBePassedOnRedirect {any | undefined} represents the context which is passed during redirect
	     */
	    AdobeIdThinData.prototype.createSocialProviderRedirectRequest = function (providerName, requestedParameters, contextToBePassedOnRedirect, nonce, grantType) {
	        var params = {
	            idp_flow: "social.deep_link.web",
	            provider_id: providerName,
	        };
	        var signInParams = __assign(__assign({}, requestedParameters), params);
	        return this.createRedirectRequest(signInParams, contextToBePassedOnRedirect, nonce, grantType);
	    };
	    /**
	     * Function used by ims to use only the neccesarry properties from AdobeIdData on sign in and reauth methods
	     * @param requestedParameters {Object} the external parameters used for signin and reauth methods
	     * @param contextToBePassedOnRedirect {any | undefined} represents the context which is passed during redirect
	     * @param nonce {string} - string representing the nonce value used for CSRF
	     * @param reauth {string}; represents the re authenticate value. available values are: check and force. default value is "check"
	     */
	    AdobeIdThinData.prototype.createReAuthenticateRedirectRequest = function (requestedParameters, contextToBePassedOnRedirect, nonce, reauth, grantType) {
	        if (reauth === void 0) { reauth = IReauth.check; }
	        if (grantType === void 0) { grantType = IGrantTypes.token; }
	        var params = {
	            reauth: reauth,
	        };
	        var reauthParams = __assign(__assign({}, requestedParameters), params);
	        return this.createRedirectRequest(reauthParams, contextToBePassedOnRedirect, nonce, grantType);
	    };
	    /**
	     * Function used by ims to use only the neccesarry properties from AdobeIdData on sign in and reauth methods
	     * @param requestedParameters {Object} the external parameters used for signin and reauth methods
	     * @param contextToBePassedOnRedirect {any | undefined} represents the context which is passed during redirect
	     */
	    AdobeIdThinData.prototype.createSignUpRedirectRequest = function (requestedParameters, contextToBePassedOnRedirect, nonce) {
	        var signupParams = __assign(__assign({}, requestedParameters), { idp_flow: "create_account" });
	        return this.createRedirectRequest(signupParams, contextToBePassedOnRedirect, nonce, IGrantTypes.token);
	    };
	    /**
	     * Function used by ims to use only the neccesarry properties from AdobeIdData on sign in and reauth methods
	     * @param externalParameters {Object} the external parameters used for signin and reauth methods
	     * @param contextToBePassedOnRedirect {any | undefined} represents the context which is passed during redirect
	     * @param nonce {string} - string representing the nonce value used for CSRF
	     * @param grantType {IGrantTypes} represents the grant type used for sign in flow
	     */
	    AdobeIdThinData.prototype.createRedirectRequest = function (externalParameters, contextToBePassedOnRedirect, nonce, grantType) {
	        var _this = this;
	        var _a = this, _b = _a.api_parameters, apiParameters = _b === void 0 ? {} : _b, clientId = _a.client_id, _c = _a.redirect_uri, adobeIdRedirectUri = _c === void 0 ? '' : _c, scope = _a.scope, locale = _a.locale;
	        var state = this.createRedirectState(contextToBePassedOnRedirect, nonce);
	        var redirectRequest = {
	            adobeIdRedirectUri: adobeIdRedirectUri,
	            apiParameters: apiParameters,
	            clientId: clientId,
	            externalParameters: externalParameters,
	            scope: scope,
	            locale: locale,
	            response_type: grantType,
	            state: state,
	        };
	        if (grantType === IGrantTypes.token) {
	            return Promise.resolve(redirectRequest);
	        }
	        var codeChallenge = new CodeChallenge();
	        return codeChallenge.createCodeChallenge(nonce).then(function (challengeResponse) {
	            externalParameters.code_challenge = challengeResponse.challenge;
	            externalParameters.code_challenge_method = 'S256';
	            var codeState = _this.createRedirectState(contextToBePassedOnRedirect, nonce);
	            redirectRequest.state = codeState;
	            return Promise.resolve(redirectRequest);
	        });
	    };
	    /**
	     * create the stae object used during redirect; if the adobeid.context is empty and no analytics parameters, the state will ne null
	     * @param context represents the external parameters
	     */
	    AdobeIdThinData.prototype.createRedirectState = function (context, nonce) {
	        var _a = this.analyticsParameters, _b = _a.appCode, appCode = _b === void 0 ? "" : _b, _c = _a.appVersion, appVersion = _c === void 0 ? "" : _c;
	        var state = context === undefined
	            ? {}
	            : {
	                context: context,
	            };
	        if (appCode) {
	            state["ac"] = appCode;
	        }
	        if (appVersion) {
	            state["av"] = appVersion;
	        }
	        state["jslibver"] = Environment$1.jslibver;
	        state["nonce"] = nonce;
	        return Object.keys(state).length ? state : null;
	    };
	    AdobeIdThinData.prototype.triggerOnReady = function () {
	        this.onReady && this.onReady(undefined);
	    };
	    return AdobeIdThinData;
	}());

	/**
	 * class used to implement the main functions used for fragment
	 */
	var FragmentHelper = /** @class */ (function () {
	    function FragmentHelper() {
	    }
	    FragmentHelper.prototype.fragmentToObject = function () {
	        var currentHash = this.getHashFromURL();
	        if (!currentHash) {
	            return null;
	        }
	        var url = this.processHashUrl(currentHash);
	        var oldHash = this.getOldHash(url);
	        // fragment values should contain only values starting with old_hash
	        //this is in case when hash route is used: e.g.: https://localhost.corp.adobe.com:9000/#/cdn#old_hash=...
	        //#/cdn# should be ignored when getQueryParamsAsMap is called;
	        var urlWithoutRoute = oldHash ? url.slice(url.indexOf('old_hash')) : url;
	        var urlWithoutOldHash = this.removeOldHash(urlWithoutRoute);
	        var imsResponseAsMap = this.getQueryParamsAsMap(urlWithoutOldHash);
	        if (oldHash) {
	            imsResponseAsMap['old_hash'] = oldHash;
	        }
	        var stateAsString = imsResponseAsMap['state'];
	        if (stateAsString) {
	            imsResponseAsMap['state'] = ApiHelpers$1.toJson(stateAsString);
	        }
	        return imsResponseAsMap;
	    };
	    /**
	     * function used to determine the old_hash value contained into the source
	     * @param source {String} represents the input source used to determine the old_hash
	     * @returns {String}
	     */
	    FragmentHelper.prototype.getOldHash = function (source) {
	        if (!source) {
	            return '';
	        }
	        var match = source.match('old_hash=(.*?)&from_ims=true');
	        if (!match) {
	            return '';
	        }
	        return match[1];
	    };
	    /**
	     * remove the old hash value from the input string
	     * @param source {String} represents the input source
	     */
	    FragmentHelper.prototype.removeOldHash = function (source) {
	        if (!source) {
	            return source;
	        }
	        return source.replace(/old_hash=(.*?)&from_ims=true/gi, 'from_ims=true');
	    };
	    /**
	   * Gets the hash from an url.
	   * @param {string=} url The URL from which to get the hash.
	   *                      If missing use the current page's URL.
	   * @Note: the # is not returned from url
	   * @returns {string}
	   */
	    FragmentHelper.prototype.getHashFromURL = function (url) {
	        if (url === void 0) { url = window.location.href; }
	        var index = url.indexOf("#");
	        return index !== -1 ? url.substring(index + 1) : "";
	    };
	    /**
	   * Parses a query string to a JSON.
	   * @NOTE Sometimes, the query string is actually a hash, due to inconsistent servers
	   * @param source {String}; represents the inpt strring value wich will be transformed to object
	   * @returns {!Object}
	   */
	    FragmentHelper.prototype.getQueryParamsAsMap = function (source) {
	        if (!source) {
	            return {};
	        }
	        var paramMap = {};
	        //in case the source starts with #, ? or &, the first character is removed. 
	        source = source.replace(/^(#\/|\/|#|\?|&)/, "");
	        source.split("&").forEach(function (keyValuePair) {
	            if (keyValuePair.length) {
	                var arr = keyValuePair.split("=");
	                paramMap[arr[0]] = decodeURIComponent(arr[1]);
	            }
	        });
	        return paramMap;
	    };
	    /**
	   * @param source {string} represent the input source wich will be processed
	   * The backend appends a second "#" sign to redirect_uri, even if it already contains one.
	   * @see https://jira.corp.adobe.com/browse/IMSB-4107554
	   */
	    FragmentHelper.prototype.processHashUrl = function (source) {
	        return decodeURIComponent(source)
	            .replace("?error", "#error")
	            .replace(/#/gi, '&')
	            .replace('from_ims=true?', 'from_ims=true&');
	    };
	    return FragmentHelper;
	}());
	var FragmentHelper$1 = new FragmentHelper();

	/**
	 * Class used as a facade for ims library in order to provide public access only to a part of the main library functionalities
	 *
	 */
	var AdobeIMSThin = /** @class */ (function () {
	    /**
	     *
	     * @param adobeData {IAdobeData} if not null, the adobeIdData instance will be created based on this values
	     */
	    function AdobeIMSThin(adobeIdThinData) {
	        var _this = this;
	        if (adobeIdThinData === void 0) { adobeIdThinData = null; }
	        /**
	         * AdobeIdData
	         * the values for adobeId are read from window.adobeid or passed by using the constructor
	         */
	        this.adobeIdThinData = null;
	        /**
	       * Method used to redirect the user to signin url
	       *
	       * <uml>
	       * start
	       * :SignIn;
	       * :Create the redirect url;
	       * :user must enter the credentials and after that is redirected to initial uri;
	       * :developer should use the fragmentValues method and implement the token mangement;
	       * end
	       * </uml>
	       * @param externalParameters {Object} object sent from outside in order to have the possibility to override the default values when the redirect uri is created
	       * @param nonce {string} string value used for csrf
	       * @param contextToBePassedOnRedirect {any | undefined} represents the context which is passed during redirect
	       * @param grantType {IGrantTypes} represents the grant type used for sign in flow
	       *
	      */
	        this.signIn = function (externalParameters, nonce, contextToBePassedOnRedirect, grantType) {
	            if (externalParameters === void 0) { externalParameters = {}; }
	            if (nonce === void 0) { nonce = ''; }
	            if (contextToBePassedOnRedirect === void 0) { contextToBePassedOnRedirect = {}; }
	            if (grantType === void 0) { grantType = IGrantTypes.token; }
	            var adobeIdThinData = _this.adobeIdThinData;
	            if (!adobeIdThinData) {
	                throw new Error('no adobeId on sign in');
	            }
	            return adobeIdThinData.createRedirectRequest(externalParameters, contextToBePassedOnRedirect, nonce, grantType)
	                .then(function (authorizeRequestData) {
	                new SignInService().signIn(authorizeRequestData);
	                return Promise.resolve();
	            });
	        };
	        /**
	         * Method used to return the authorization url;
	         *
	         * @param externalParameters {Object} object sent from outside in order to have the possibility to override the default values when the redirect uri is created
	         * @param contextToBePassedOnRedirect {any | undefined} represents the context which is passed during redirect
	         *
	        */
	        this.getAuthorizationUrl = function (externalParameters, contextToBePassedOnRedirect, grantType) {
	            if (externalParameters === void 0) { externalParameters = {}; }
	            if (grantType === void 0) { grantType = IGrantTypes.token; }
	            var adobeIdThinData = _this.adobeIdThinData;
	            if (!adobeIdThinData) {
	                throw new Error('no adobeId on sign in');
	            }
	            return adobeIdThinData.createRedirectRequest(externalParameters, contextToBePassedOnRedirect, '', grantType)
	                .then(function (authorizeRequestData) {
	                var authUrl = new SignInService().createRedirectUrl(authorizeRequestData);
	                return Promise.resolve(authUrl);
	            });
	        };
	        /**
	          * Method used to return the authorization url;
	          *
	          * @param externalParameters {Object} object sent from outside in order to have the possibility to override the default values when the redirect uri is created
	          * @param contextToBePassedOnRedirect {any | undefined} represents the context which is passed during redirect
	          *
	         */
	        this.getSocialProviderAuthorizationUrl = function (providerName, externalParameters, contextToBePassedOnRedirect, grantType) {
	            if (externalParameters === void 0) { externalParameters = {}; }
	            if (grantType === void 0) { grantType = IGrantTypes.token; }
	            var adobeIdThinData = _this.adobeIdThinData;
	            if (!adobeIdThinData) {
	                throw new Error('no adobeId on sign in');
	            }
	            return adobeIdThinData.createSocialProviderRedirectRequest(providerName, externalParameters, contextToBePassedOnRedirect, '', grantType)
	                .then(function (authorizeRequestData) {
	                var url = new SignInService().createRedirectUrl(authorizeRequestData);
	                return Promise.resolve(url);
	            });
	        };
	        /**
	          * Method used to return the authorization url;
	          *
	          * @param reauth {string}; represents the re authenticate value. available values are: check and force. default value is "check"
	          * @param requestedParameters {Object} object sent from outside in order to have the possibility to override the default values when the redirect uri is created
	          * @param contextToBePassedOnRedirect {any | undefined} represents the context which is passed during redirect
	         */
	        this.getReauthenticateAuthorizationUrl = function (reauth, requestedParameters, contextToBePassedOnRedirect, grantType) {
	            if (reauth === void 0) { reauth = IReauth.check; }
	            if (requestedParameters === void 0) { requestedParameters = {}; }
	            if (grantType === void 0) { grantType = IGrantTypes.token; }
	            var adobeIdThinData = _this.adobeIdThinData;
	            if (!adobeIdThinData) {
	                throw new Error('no adobeId on sign in');
	            }
	            return adobeIdThinData.createReAuthenticateRedirectRequest(requestedParameters, contextToBePassedOnRedirect, '', reauth, grantType)
	                .then(function (authorizeRequestData) {
	                var url = new SignInService().createRedirectUrl(authorizeRequestData);
	                return Promise.resolve(url);
	            });
	        };
	        /**
	          * Method used to return the authorization url;
	          *
	          * @param externalParameters {Object} object sent from outside in order to have the possibility to override the default values when the redirect uri is created
	          * @param contextToBePassedOnRedirect {any | undefined} represents the context which is passed during redirect
	          *
	         */
	        this.getSignUpAuthorizationUrl = function (requestedParameters, contextToBePassedOnRedirect) {
	            if (requestedParameters === void 0) { requestedParameters = {}; }
	            var adobeIdThinData = _this.adobeIdThinData;
	            if (!adobeIdThinData) {
	                throw new Error('no adobeId on sign in');
	            }
	            return adobeIdThinData.createSignUpRedirectRequest(requestedParameters, contextToBePassedOnRedirect, '')
	                .then(function (authorizeRequestData) {
	                var signInService = new SignInService();
	                return signInService.createRedirectUrl(authorizeRequestData);
	            });
	        };
	        /**
	         * token {string} represents the token used for sign out
	         * externalParameters {object} - external parameters passed to sign out
	         *
	         * <uml>
	         * start
	         * :Signout;
	         * :Create the redirect url;
	         * :remove the token and profile from storage;
	         * :developer should implement his scenario after signout
	         * end
	         * </uml>
	         */
	        this.signOut = function (externalParameters) {
	            if (externalParameters === void 0) { externalParameters = {}; }
	            var adobeIdData = _this.adobeIdThinData;
	            if (!adobeIdData) {
	                throw new Error('no adobeId on sign out');
	            }
	            var _a = adobeIdData.api_parameters, apiParameters = _a === void 0 ? {} : _a, clientId = adobeIdData.client_id, adobeIdRedirectUri = adobeIdData.redirect_uri;
	            var redirectRequest = {
	                adobeIdRedirectUri: adobeIdRedirectUri,
	                apiParameters: apiParameters,
	                clientId: clientId,
	                externalParameters: externalParameters,
	            };
	            var signOutService = new SignOutService();
	            signOutService.signOut(redirectRequest);
	        };
	        this.adobeIdThinData = new AdobeIdThinData(adobeIdThinData);
	    }
	    /**
	     * method used to notify that the library has been initialized
	     */
	    AdobeIMSThin.prototype.initialize = function () {
	        var adobeIdThinData = this.adobeIdThinData;
	        if (!adobeIdThinData) {
	            throw new Error('Please provide the adobe Id data');
	        }
	        adobeIdThinData.triggerOnReady();
	    };
	    /**
	     * Helper function used to transform fragment values into a json object
	     */
	    AdobeIMSThin.prototype.fragmentValues = function () {
	        return FragmentHelper$1.fragmentToObject();
	    };
	    /**
	     * Helper function used to return the nonce value from fragment
	     */
	    AdobeIMSThin.prototype.getNonce = function () {
	        var fragment = this.fragmentValues();
	        if (!fragment) {
	            return null;
	        }
	        var _a = fragment.redirectParams, redirectParams = _a === void 0 ? {} : _a;
	        return redirectParams ? redirectParams["nonce"] || null : null;
	    };
	    return AdobeIMSThin;
	}());

	/**
	 * singleton class which is created on the same time when library is injected into the page.
	 * it is used to provide the possibility to an external library to create a new instance of AdobeIMS
	 * also, if the window contains a value for adobeId, it will create a new instance of AdobeIMS
	 */
	var ImsThinInitialization = /** @class */ (function () {
	    function ImsThinInitialization() {
	        /**
	         *
	         * @param adobeData represents the custom adobeData
	         * @returns a new instance of the AdobeIms library based on input adobeIdData
	         */
	        this.createIMSThinLib = function (adobeData, adobeImsWindowKey) {
	            if (adobeData === void 0) { adobeData = null; }
	            if (adobeImsWindowKey === void 0) { adobeImsWindowKey = AdobeIMSKey; }
	            var adobeIMSThin = new AdobeIMSThin(adobeData);
	            window[adobeImsWindowKey] = adobeIMSThin;
	            return adobeIMSThin;
	        };
	    }
	    /**
	   * create a new instance of ims lib based on adobe id data
	   */
	    ImsThinInitialization.prototype.initAdobeIms = function () {
	        window[AdobeImsFactory] = {
	            createIMSLib: this.createIMSThinLib
	        };
	        var adobeIMS = window[AdobeIMSKey] || null;
	        if (!adobeIMS) {
	            var adobeIdData = window[AdobeIdKey];
	            if (!adobeIdData) {
	                return;
	            }
	            adobeIMS = this.createIMSThinLib(adobeIdData, AdobeIMSKey);
	            adobeIMS.initialize();
	        }
	    };
	    return ImsThinInitialization;
	}());
	var ImsThinInitialization$1 = new ImsThinInitialization();

	/**
	 * class used during the bundle process for the thin library with polyfill
	 */
	var MainThinPolyfill = /** @class */ (function () {
	    function MainThinPolyfill() {
	        ImsThinInitialization$1.initAdobeIms();
	    }
	    /**
	   * method used only for testing in order to ensure the libray is initialized
	   */
	    MainThinPolyfill.prototype.initialize = function () {
	        return true;
	    };
	    return MainThinPolyfill;
	}());
	var MainThinPolyfill$1 = new MainThinPolyfill();

	return MainThinPolyfill$1;

}());
